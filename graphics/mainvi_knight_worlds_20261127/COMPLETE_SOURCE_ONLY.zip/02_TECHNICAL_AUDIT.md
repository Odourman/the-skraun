# Technical audit – ORIGINAL TIA F6/NTSC / PR76/C

## Evidence classes
- `PR76/C` ROM+video are *existing developer-observed* artifacts. They do not verify the new graphics.
- All new ASM/JSON/GIF/PNG, AABB and navigation results here are **SOURCE_ONLY**.
- No fresh DASM, Stella, debugger trace, measured beam deadline, stack high-water or actual P1 multiplex/sword hitbox test.

## 6507/TIA scanline contract
`Visible` in bank3 writes `PF1` once on the first physical row of each two-row pair; `WorldPFIndex` encodes 2 physical scanlines/byte. There are **8 stages × 96 PF1 bytes = 768 bytes**, occupying `$FA00..$FCFF`; source table order is *bottom-first*, not screen top-first. Visible 186 rows read indices 93..1; untouched non-visible padding is retained.

The left PF1 eight bits (bit7 first) cover horizontal TIA color-clocks `x=16..47` (4 clocks/bit). For odd stages, reflecting the half-screen gives matching right-side PF1 pixels around x112..143; for even stages, repeated PF1 occupies x96..127, NOT the reflected location. In all even-stage new masks, bit7 is unlit so the visible left obstacle stays x20..47 and the second copy x100..127, matching the source `WorldRects` horizontal envelopes.

Rendering does not require new TIA writes or RAM in the design. It preserves `CTRLPF` value, `WorldPFPtr`, `WorldPFLo/Hi`, `WorldPFIndex`, existing halo technique, actor selection and interrupt/beam assumptions. Source table replacement alone does not prove production timing or asset fit after DASM linking.

## Knight data contract
P1 sprite source is 8 bits/row x16 rows, bottom-first byte order; the 17th guard byte must remain `0`. The current bank3 `SelectEnemyArtImpl` switches existing three knight labels and three Ranger labels. `REFP1` can mirror the same 8-bit candidate. VDEL stays as in the original kernel. The new three K1 records are 51 bytes total, same size as original. The Ranger's 51 byte source remains unchanged. P0 is Skraun, BL is orb, M1 is projectile, and P1 also participates in level-3 aura presentation; neither additional sprite nor missile is assumed. Current warning and strike selection code remains wholly untouched.

The 8-bit strike silhouette cannot show a long separate blade past the P1 box. Sword collision range is unchanged; visually legible reach vs actual hit range requires gameplay observation. Optional walking B frame cannot be added for free.

## Geometry & world safety
The supplied `GEOMETRY_SOURCE_ONLY.json` contains full PR76/C AABB rectangles as raw gameplay coordinates and source-only 4-neighbor BFS. All eight current rectangular AABBs were preserved. Mapping visual row to gameplay Y uses +10 offset discovered by source occupancy minimization against all 8 worlds, not independent emulator geometry. Every stage has zero new painted PF1 pixels outside its existing rectangle envelopes. Both PR76/C potential orb centers at (22,68) and (138,68) were reachable in the conservative L3 center-grid test from (80,88). In-game orb placements/actual collisions remain untested with new bitmap data.

Note: rendering scenic shapes inside a rectangular collider necessarily can make black negative spaces solid (e.g. arch openings and spiral cut-outs). This existed in the baseline and cannot be fixed by a source-only sprite replacement without a separate collision decision; do not imply hollow portal openings are passable.

## Source-only preview limitations
The overview images use source-correct 160×186 PF1 pixels and an approximate 640×480 NTSC TV scaling. Some actor-scale composites interpolate the **unchanged** U1-LEG1 original bitmap to existing ROM level sizes 8×12, 16×20, 32×30, but do not reconstruct the full P0 kernel pixel-for-pixel; not a Stella claim. The composites explicitly show 2 knights, Ranger, and one orb as scale references, not proof of concurrent hardware rendering. Colors are illustrative RGB mapped to the current world's palette; active halo keeps existing whole-PF gold behavior. Source-only images are not a physical halo performance check.

## Integration instructions (only after separate MAIN ROM authorization)
1. Freeze the exact PR76/C starting files and verify ROM hash and `bank3` blob.
2. In `bank3.asm`, replace only `K1NeutralBytes`, `K1WarningBytes`, and `K1StrikeBytes` 17-byte `dc.b` records using `art/KNIGHT_P1_DROPIN_SOURCE_ONLY.asm`; leave existing `R1...` source tables, `SelectKnightPose`, `VDEL`, `REFP1`, address guards and all code untouched.
3. Replace only `PlayPF1` table under `ORG $FA00` with all 768 bytes in `art/WORLD_PF1_DROPIN_SOURCE_ONLY.asm`; keep `ORG $FD00`, `WorldPFIndex`, `WorldPFLo/Hi`, current CTRLPF and collision `WorldRects` unchanged initially.
4. Rebuild with repository's exact DASM flow. Report link addresses/ROM SHA bank-by-bank and address overlap. If the data's byte count or linker layout changes, STOP. Do not modify the hardware technique under this graphics order.
5. Run Stella stage 1–8 raster captures and native pixel check for K1 neutral/warn/strike on real P1 positions, including same-Y overlap/multiplex. Verify 262 scanlines, measured VDEL/REFP1, relevant TIA beam deadlines, sword wind-up and active hit window, and collisions at L3 plus both potential orb positions, all separately ordered by MAIN.

**GRAPHICS II supplies no executable ROM and does not itself authorize integration.**
