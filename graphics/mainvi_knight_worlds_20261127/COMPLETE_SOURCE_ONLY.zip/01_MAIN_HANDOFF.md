# GRAPHICS II → MAIN VI: Knight Redesign & World Graphics Refinement

2026-11-27 | SOURCE_ONLY | User review requested | No ROM modifications

## Baseline revalidated
- [PR76/C](https://github.com/Odourman/the-skraun/pull/76), HEAD `bd499a0736a8ed09c9e733e90387188176870039`, draft/open at read time.
- ROM from complete MAIN VI delivery: original 16384 bytes, SHA-256 `1170604965d062916b71b48335f5ffef089bf89b8eec0418f6b17b9582d82dc1` verified against extracted bytes.
- `bank3.asm` exact Git blob `8d839fee0eb4ec4ef9708490a25672b5a4819b13`; our bundled file's Git blob independently matches. Real 120s gameplay MP4 sampled in `baseline/PR76_C_GENUINE_VIDEO_FRAME_CONTACT_SHEET.png`.
- Gameplay baseline sprites K1Neutral/Warning/Strike and R1Neutral/Draw/Release read as exactly 17 bytes each (16 rows + 0 guard); map 768 bytes; `WorldRects` 4 AABBs per stage, 16 bytes per stage.

## Recommended knight
**K1_T_VISOR**, 8×16, one-color P1, top-first for artwork, bottom-first in ROM, `$00` seventeenth byte guard, direct replacement of existing three K1 byte records. Flat-topped medieval helmet, dark T-visor as holes in the monochrome silhouette, broader armor shoulders/torso, paired feet consistently anchored, distinguishable upright warning blade and short horizontal active slash. `REFP1` mirrors the masks, so no independent mirrored ROM table needed.

**K2_BARREL_HELM** is the only alternative (narrower tapered helmet, wider body). Its legs are visually heavier; it is less clearly identifiable at native 8×16 resolution. Recommend K1 for an actual ROM/stella visual trial.

**Sword reach caveat:** The entire strike still fits within P1's eight-bit width. No separate M1 sword sprite is requested/created (M1 is the arrow). The hitbox remains the existing logical sword rule; verify visual range vs logical ray in a later authorized ROM test. If insufficient, MAIN must explicitly decide whether gameplay/renderer work is justified. Do NOT silently change hitbox or use M1.

Optional K1 A/B walk is supplied purely for comparison and *requires* additional ROM data/selection/timing changes; not authorized in this delivery and should not be inserted automatically.

## World visual revision
All eight stages are individually updated within their existing 96 byte PF1 slot. More legible conifers, round trees, mountain slopes, static square spirals, arched dream portals, crenellated walls and irregular ruins. Alternate-stage forms are specifically designed for **CTRLPF repeated** layout; they do not assume a mirror. Stage 1/3/5/7 reflected. Stage 2/4/6/8 repeated. Present existing source rather than inventing additional colors or sprites.

## Navigation and geometry
- Source-only test compares current PR76 `WorldRects` and visual occupancy: **0 proposed PF1 pixels outside existing four collision envelopes per stage** in the source-derived 160×186 coordinate mapping (`screenY = gameplayY + 10`). The geometric rectangles themselves remain unchanged.
- Conservative, four-direction BFS for the **actual PR76 L3 rectangle** (half 16×15, X=20..140, Y=19..157) from center (80,88) reaches both possible stage-orb centers (22,68) and (138,68), all eight worlds. No original joystick, renderer, or live collider test has been performed.
- The source-only test assumes the existing `CandidateValid` AABB logic and does not establish collision fairness at shape boundaries or prove growth pickup motion, fixed-point drift, enemies and halo never obstruct travel.

## Deliverable and stop
The complete package contains exact `art/KNIGHT_P1_DROPIN_SOURCE_ONLY.asm`, `art/WORLD_PF1_DROPIN_SOURCE_ONLY.asm`, `art/GRAPHICS_AND_GEOMETRY_DATA.json`, `art/GEOMETRY_SOURCE_ONLY.json`, all masks, GIFs, all eight scenes at multiple scales, 16 isolated motifs, source comparisons and overlays, a baseline gameplay contact sheet, deterministic generator, and SHA256SUMS.

MAIN VI may select/reject K1 and the eight arenas. **GRAPHICS II STOP**: no merge, ROM edit, gameplay balancing, independent Verification, extra world family or new physics work.
