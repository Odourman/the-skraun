# THE SKRAUN – GRAPHICS II / MAIN VI / 2026-11-27

**Status:** SOURCE_ONLY candidate. MAIN VI authorized graphics only. Do not merge or run implementation without a separate order.

**Best candidates:** K1_T_VISOR (knight), WORLD_PF1_DROPIN_SOURCE_ONLY.asm (all eight worlds). K2_BARREL_HELM is an alternative; optional K1 walk_B needs extra animation-selection code and is NOT a drop-in.

**Review order:** `art/ALL_EIGHT_WORLDS_MAIN_VI_SOURCE_ONLY.png`, `art/KNIGHT_PR76_VS_K1_SOURCE_ONLY.png`, `art/K1_T_VISOR_SWORD_CYCLE_SOURCE_ONLY.gif`, `art/EVEN_STAGES_2_4_6_8_SOURCE_ONLY.png`, `01_MAIN_HANDOFF.md`, `02_TECHNICAL_AUDIT.md`.

**Source:** EXACT PR76/C commit `bd499a0736a8ed09c9e733e90387188176870039`; ROM SHA256 `1170604965d062916b71b48335f5ffef089bf89b8eec0418f6b17b9582d82dc1`. No fresh ROM or Stella run. The `baseline/` directory includes three unchanged assembler files and a contact sheet extracted from the supplied real gameplay MP4, not re-created artwork.

**Use:** new PF1 table replaces ONLY `PlayPF1` data at `$FA00..$FCFF`; K1 masks replace ONLY the existing 3 x 17 byte table records at `$F7A8`, leaving Ranger, P0, audio, HUD, orb, M1, code and timing untouched. This is a proposed integration, not an implemented modification.

Run `python tools/generate.py` from the ZIP root (requires Pillow) to regenerate every file in `art/` from the baseline code and manual source pixels embedded in the generator. Compare with `SHA256SUMS.txt`.
