# SOURCE REGISTER – GRAPHICS II 2026-11-27

## Live source anchors
- Exact PR76/C: https://github.com/Odourman/the-skraun/pull/76 ; `bd499a0736a8ed09c9e733e90387188176870039`.
- Source bank3: `experiments/fullgame1_arrow_halo_20261125/bank3.asm`, Git blob `8d839fee0eb4ec4ef9708490a25672b5a4819b13`.
- Existing ROM: 16384 bytes, SHA-256 `1170604965d062916b71b48335f5ffef089bf89b8eec0418f6b17b9582d82dc1`.
- Source-only graphics and canon: `docs/DESIGN_DECISIONS_01-60_2026-11-16.md`, `docs/SKRAUN_VISUAL_DIRECTION_2026-11-16.md` on GitHub main, exact U1-LEG1 source Git blob `48332690d58aecf70d986eeee075dd3156bbf102`.
- Original PR76 gameplay package on Google Drive: https://drive.google.com/file/d/11KhE9wMZlJQ5aXHPD3BiBOTO5AfU-8eU/view
- User role authorization: MAIN VI KNIGHT REDESIGN & WORLD GRAPHICS REFINEMENT (current chat).

## Evidence distinction
`baseline/PR76_C_GENUINE_VIDEO_FRAME_CONTACT_SHEET.png` consists of actual frames from the existing delivered 120-second gameplay video (not screenshots of new art). The 120 new art/ASM/JSON generated files are marked SOURCE_ONLY. There is no new native DASM/Stella execution.

## Visual references
The previously approved world directions have been preserved as classes: conifer/round tree, pointed/rounded mountain, static spiral/portal, battlement/ruin. The existing even/odd render modes and all source WorldRects are preserved; specific bitmaps are proposed not approved.

## Scope boundary
No modification to `main`, current PR76 branch, ROM bytes, hardware mapper, or sprites for Skraun/Ranger. Colliders remain the PR76 code's raw rectangles in this package; only source-only recommendation/overlay is produced.
