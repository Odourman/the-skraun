#!/usr/bin/env python3
"""The Skraun / MAIN VI GRAPHICS II source-only art generator.
Requires Pillow; no game code is executed and no emulator is simulated.
All visual previews generated from same P1/PF1 byte arrays as output ASM.
Run: python tools/generate.py [package_directory]; default inferred from script.
"""
from pathlib import Path
from hashlib import sha256
from collections import deque
import json, re, sys, math
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
ROOT.mkdir(parents=True,exist_ok=True)
OUT=ROOT/'art'; OUT.mkdir(exist_ok=True)
BASE=ROOT/'baseline'/'PR76_C_BANK3_UNMODIFIED.asm'
SRC=BASE.read_text()
def extract(name,amount=None):
    m=re.search(r'(?m)^'+re.escape(name)+r':\s*\n',SRC)
    if not m:raise RuntimeError(f'not found {name}')
    s=SRC[m.end():]
    b=[]
    for line in s.splitlines():
        if not line.strip().startswith('dc.b'):break
        line=line.split(';')[0].split('dc.b',1)[1]
        b.extend(int(x.strip()[1:],16) if x.strip().startswith('$') else int(x.strip(),10) for x in line.split(',') if x.strip())
    if amount is not None and len(b)!=amount: raise ValueError((name,len(b),amount))
    return b
# Grab sprite tables from exact PR76/C source; verify entire 6*17+9B ROM allocation.
oldkn={n:extract(n,17) for n in ['K1NeutralBytes','K1WarningBytes','K1StrikeBytes','R1NeutralBytes','R1DrawBytes','R1ReleaseBytes']}
raw=extract('PlayPF1',768)
worlds=[raw[i*96:(i+1)*96] for i in range(8)]
# WorldRects are from PR76/C bank0, separate from what the PF bytes can change.
b0=(ROOT/'baseline'/'PR76_C_BANK0_UNMODIFIED.asm').read_text()
rectsection=b0.split('WorldRects:',1)[1].split('RangerCheckTimer:',1)[0]
rects=[]
for line in rectsection.splitlines():
    if 'dc.b' in line:
        ss=line.split(';')[0].split('dc.b',1)[1]
        vals=[int(v.strip().replace('$','0x'),0) for v in ss.split(',') if v.strip()]
        if len(vals)==16:rects.append([vals[k:k+4] for k in range(0,16,4)])
assert len(rects)==8
# NOTE: sources use these exact band index ranges. Never widen outside existing AABB rectangles.
def bands(data):
    active=[i for i,v in enumerate(data) if v!=0]
    groups=[]
    for i in active:
        if not groups or i-groups[-1][-1]>1:groups.append([i])
        else: groups[-1].append(i)
    assert len(groups)==2,(len(groups),[(g[0],g[-1]) for g in groups])
    # ascending index == bottom->top, so top group is last group
    return [(groups[-1][0],groups[-1][-1]),(groups[0][0],groups[0][-1])]
# 8-bit patterns, bit 7 = leftmost. Entries are top-first source rows; rows mapped to native two-line table resolution.
# Even stages intentionally avoid leftmost bit (x=16..20) because actual repetition shifts right-side obstacle to x=96..128.
patterns={
'1_top_pine':[
'...##...','..####..','..####..','.######.','.######.','..####..','########','########','.######.',
'..####..','.######.','########','########','...##...','...##...','...##...','...##...','...##...','...##...'],
'1_bottom_round':[
'..####..','.######.','.######.','########','########','########','########','.######.','.######.',
'..####..','..####..','...##...','...##...','...##...','...##...','...##...','...##...'],
'2_top_round':[
'...###..','..#####.','.#######','.#######','.#######','.#######','.#######','.#######',
'..#####.','..#####.','...###..','...##...','...##...','...##...','...##...','...##...',
'...##...','...##...'],
'2_bottom_pine':[
'....#...','...###..','...###..','..#####.','..#####.','...###..','.#######','.#######',
'..#####.','...###..','..#####.','.#######','.#######','...##...','...##...','...##...',
'...##...','...##...'],
'3_top_peak':[
'...##...','..####..','..####..','.######.','.######.','########','########',
'########','########','########','########','########','########'],
'3_bottom_rock':[
'..####..','..####..','.######.','.######.','########','########','########','########','########',
'########','########','########'],
'4_top_peak':[
'....#...','...###..','...###..','..#####.','..#####.','.#######','.#######',
'.#######','.#######','.#######','.#######','.#######','.#######'],
'4_bottom_rock':[
'...###..','..#####.','..#####.','.#######','.#######','.#######','.#######',
'.#######','.#######','.#######','.#######','.#######'],
'5_top_spiral':[
'#######.','#.....#.','#.#####.','#.#.....','#.#.###.','#.#.#.#.','#...#.#.',
'#####.#.','#.....#.','#######.'],
'5_bottom_portal':[
'..####..','.######.','########','########','##....##','##....##','##....##','##....##',
'##....##','##....##','##....##','##....##'],
'6_top_portal':[
'...##...','..####..','.######.','.######.','.##..##.','.##..##.','.##..##.',
'.##..##.','.##..##.','.##..##.','.##..##.','.##..##.'],
'6_bottom_spiral':[
'.#######','.1.....1', # corrected immediately below using dotted rows
'.#######','.##...##','.###..##','.####.##','.##.#.##','.##...##','.#######'],
'7_top_wall':[
'##.##.##','##.##.##','##.##.##','########','########','########','########','########',
'########','########','########','########'],
'7_bottom_ruin':[
'##....##','##...###','###..###','###.####','########','########','########','########',
'########','########','########'],
'8_top_ruin':[
'.##....#','.##...##','.###..##','.###.###','.#######','.#######','.#######',
'.#######','.#######','.#######','.#######'],
'8_bottom_wall':[
'.##.##.#','.##.##.#','.##.##.#','.#######','.#######','.#######','.#######',
'.#######','.#######','.#######','.#######']
}
patterns['6_bottom_spiral']=[
'.#######','.##....#','.######.','.....#.#','.#####.#','.##..#.#','.##.##.#',
'.##....#','.#######'
]
# Explicit stage-specific motifs, not merely reusing identical masks between even and odd stage.
assign=[('1_top_pine','1_bottom_round'),('2_top_round','2_bottom_pine'),('3_top_peak','3_bottom_rock'),('4_top_peak','4_bottom_rock'),('5_top_spiral','5_bottom_portal'),('6_top_portal','6_bottom_spiral'),('7_top_wall','7_bottom_ruin'),('8_top_ruin','8_bottom_wall')]
# Ensure ASCII patterns are individually valid and even stages stay in their narrower hardware footprint.
for name,rows in patterns.items():
    assert all(len(r)==8 and set(r)<={'.','#'} for r in rows),(name,rows)
    if int(name[0])%2==0: assert all(r[0]=='.' for r in rows),name

def genband(source,bounds,pattern):
    lo,hi=bounds; length=hi-lo+1
    # Generate top-first native rows, resample to existing exact band height.
    templ=patterns[pattern]
    tops=[templ[min(len(templ)-1,(j*len(templ))//length)] for j in range(length)]
    arr=source.copy()
    for n,idx in enumerate(range(hi,lo-1,-1)):
        arr[idx]=int(tops[n].replace('#','1').replace('.','0'),2)
    return arr
proposed=[]
for stage,arr in enumerate(worlds):
    top,bot=bands(arr)
    out=genband(arr,top,assign[stage][0]);out=genband(out,bot,assign[stage][1]);
    # No previously empty PF1 cell outside two established vertical bands.
    for idx in range(96):
        if arr[idx]==0 and not(top[0]<=idx<=top[1] or bot[0]<=idx<=bot[1]):assert out[idx]==0
    proposed.append(out)
assert len(proposed)==8 and all(len(x)==96 for x in proposed)
# Knight candidate masks top-first; all 16 rows, feet and torso held stationary across poses.
K1={
'neutral':[
'..####..','.######.','.#....#.','.###.##.','.###.##.','..####..',
'.######.','#######.','.#####..','..####..','..###..#','..###..#',
'..#.#...','.##.##..','.##.##..','##...##.'],
'warning':[
'..####.#','.######.','.#....##','.###.###','.###.###','..####.#',
'.######.','#######.','.#####.#','..####.#','..###..#','..###...',
'..#.#...','.##.##..','.##.##..','##...##.'],
'strike':[
'..####..','.######.','.#....#.','.###.##.','.###.##.','..####..',
'.######.','#######.','.#######','..######','..###...', '..###...',
'..#.#...','.##.##..','.##.##..','##...##.'],
'walk_B':[
'..####..','.######.','.#....#.','.###.##.','.###.##.','..####..',
'.######.','#######.','.#####..','..####..','..###..#','..###..#',
'..#.##..','.##.##..','##..##..','..##...#']}
K2={
'neutral':[
'...##...','..####..','.######.','.#....#.','.###.##.','.######.',
'########','##.##.##','.######.','.######.','..####.#','..####.#',
'..#..#..','.##..##.','.##..##.','##....##'],
'warning':[
'...##..#','..####.#','.######.', '.#....##','.###.###','.######.',
'########','##.##.##','.######.','.######.', '..####.#','..####.#',
'..#..#..','.##..##.','.##..##.','##....##'],
'strike':[
'...##...','..####..','.######.','.#....#.','.###.##.','.######.',
'########','##.#####','########','.#######','..####..','..####..',
'..#..#..','.##..##.','.##..##.','##....##']}
for family,poses in [('K1',K1),('K2',K2)]:
    for name,rows in poses.items(): assert len(rows)==16 and all(len(r)==8 and set(r)<={'.','#'} for r in rows),(family,name)
for p in ('neutral','warning','strike'):
    assert K1[p][-4:]==K1['neutral'][-4:] and K2[p][-4:]==K2['neutral'][-4:]
hexrow=lambda x:[int(row.replace('#','1').replace('.','0'),2) for row in x]
knight={fam:{pose:{'top_first_binary':[r.replace('#','1').replace('.','0') for r in rows], 'rom_bottom_first_hex':[f'${v:02X}' for v in hexrow(rows)[::-1]]+['$00'], 'mirror_top_first_binary':[r.replace('#','1').replace('.','0')[::-1] for r in rows]} for pose,rows in poses.items()} for fam,poses in [('K1_T_VISOR',K1),('K2_BARREL_HELM',K2)]}
# Old reference and source bytes. Do not alter R1 tables in assembler output.
original_knight={n:oldkn[n] for n in ('K1NeutralBytes','K1WarningBytes','K1StrikeBytes')}
# TIA active PF1 geometry. WorldPFIndex from X=186 through X=2 inclusive is 93..1, one lookup per pair.
# Start with row 0 (top), 186 rows. PF0=0, PF2 = separate aura, preview is PF1 geometry only.
def matrix(data,stage):
    pic=Image.new('RGB',(160,186),(0,0,0));pix=pic.load();
    for pair in range(93):
        b=data[93-pair]
        for v in range(8):
            if b&(0x80>>v):
                for dy in range(2):
                    for dx in range(4):
                        x=16+4*v+dx;pix[x,2*pair+dy]=(255,255,255)
                        if stage%2==1: # reflected: right half = 160-(left + 1)
                            pix[159-x,2*pair+dy]=(255,255,255)
                        else: # repeated: right half starts +80 clocks
                            pix[x+80,2*pair+dy]=(255,255,255)
    return pic
# NTSC approximate palette based on source register values, concept, not Stella color calibration.
COLORS=[(100,162,78),(109,178,85),(111,127,154),(125,145,172),(166,95,186),(178,108,198),(88,115,183),(100,126,199)]
BACKS=[(7,16,10),(7,16,10),(20,20,24),(20,20,24),(19,11,27),(19,11,27),(4,8,18),(4,8,18)]
GOLD=(225,183,64); BLUE=(151,202,249); RANGER=[(93,181,91),(93,181,91),(113,140,157),(113,140,157),(150,99,178),(150,99,178),(116,132,185),(116,132,185)]
GRAY=(207,207,208)
# Native 160x186 pixel canvases: PF1 field occupies only a fixed subset of the screen.
def render(data,stage,gold=False):
    m=matrix(data,stage+1); c=GOLD if gold else COLORS[stage]
    bg=BACKS[stage]
    o=Image.new('RGB',m.size,bg)
    o.paste(c,(0,0,160,186),m.convert('L'))
    return o
# for bitmap sprite draw P0/P1 exactly one logical pixel wide, preview only.
U1_A=['00100100','01111110','01011010','01100110','00111110','01111111','10111100','00111100','00111100','00100110','00100011','01100000']
def blit_sprite(im,rows,x,y,color,sx=1,sy=1):
    p=im.load()
    for j,row in enumerate(rows):
        for i,b in enumerate(row):
            if b=='1' or b=='#':
                for ay in range(sy):
                    for ax in range(sx):
                        px=x+i*sx+ax; py=y+j*sy+ay
                        if 0<=px<im.width and 0<=py<im.height:p[px,py]=color
# Renderer screenshot-like sources are not real emulator; optional actors are spatial exemplars only.
def actor_scene(data,stage,level):
    o=render(data,stage)
    dims={1:(1,12),2:(2,20),3:(4,30)}; sx,h=dims[level]
    # preserve U1-LEG1 source mask; height equals actual PR76 L1/L2/L3 (12/20/30).
    # nearest row allocation is SOURCE_ONLY, not a claim of ROM P0 row-exactness.
    ub=Image.new('RGB',(8,12),(0,0,0))
    blit_sprite(ub,U1_A,0,0,GRAY)
    rowscaled=ub.resize((8*sx,h),Image.Resampling.NEAREST)
    black=(0,0,0); dest=o.load(); srcpix=rowscaled.load()
    for j in range(h):
        for k in range(8*sx):
            if srcpix[k,j]!=black:
                xx=80-4*sx+k; yy=91-h//2+j
                if 0<=xx<160 and 0<=yy<186:dest[xx,yy]=GRAY
    blit_sprite(o,K1['neutral'],53,88,BLUE,1,1)
    blit_sprite(o,K1['neutral'],118,96,BLUE,1,1)
    r0=oldkn['R1NeutralBytes'][:16][::-1]
    blit_sprite(o,[f'{x:08b}' for x in r0],138,74,RANGER[stage],1,1)
    dr=ImageDraw.Draw(o)
    px=(22 if stage%2==0 else 138)  # ONE orb displayed, other candidate tested separately
    dr.ellipse((px-2,68-2,px+2,68+2),fill=GOLD)
    return o
# Geometric AABB model precisely follows CurrentPR76 CandidateValid x/y comparisons.
MINX,MAXX,MINY,MAXY=20,141,19,158
HALFW,HALFH=16,15
OBX=(22,138); OBY=68; start=(80,88)
def valid(x,y,stage):
    if not(MINX<=x<MAXX and MINY<=y<MAXY):return False
    for a,b,c,d in rects[stage]:
        if x+HALFW>=a and x-HALFW<b and y+HALFH>=c and y-HALFH<d:return False
    return True
# Enumerate 4 cardinal moves only as a conservative reachability lower bound,
# actual game supports eight dirs / axis sliding.
def reach(stage):
    assert valid(*start,stage),(stage,'center blocked')
    todo=deque([start]);visited={start}
    while todo:
        x,y=todo.popleft()
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
            p=(x+dx,y+dy)
            if p not in visited and valid(*p,stage):visited.add(p);todo.append(p)
    targets={str(x):((x,OBY) in visited) for x in OBX}
    return len(visited),targets
# Model visual occupancy boundaries and whether each white pixel lies inside candidate collider.
def coverage(stage,dat):
    mask=matrix(dat,stage+1).convert('L'); p=mask.load(); inside=0;outside=0
    # overlay bounding rectangle x/y screen extents: game y = image y -10
    for y in range(186):
        for x in range(160):
            if p[x,y]:
                if any(a<=x<b and c+10<=y<d+10 for a,b,c,d in rects[stage]):inside+=1
                else:outside+=1
    return {'in_pixels':inside,'outside_collision_envelopes_pixels':outside}
# Note collision y +9 baseline is documented offset from previous graphical PR; keep separate from runtime proof.
metrics=[]
for stage in range(8):
    count,targets=reach(stage)
    metric={'stage':stage+1,'source_bytes_changed':sum(a!=b for a,b in zip(worlds[stage],proposed[stage])),
            'active_old':sum(v!=0 for v in worlds[stage]),'active_new':sum(v!=0 for v in proposed[stage]),
            'reflect_or_repeat':'reflect' if stage%2==0 else 'repeat',
            'L3_4way_connected_centers':count,'orb_candidates_22_138_y68_reachable_from_80_88':targets,
            'visual_coverage':coverage(stage,proposed[stage]),
            'baseline_visual_coverage':coverage(stage,worlds[stage])}
    metrics.append(metric)
# Build exact DASM replacement tables with preserved symbol names; no ROM implementation performed.
def da(b):return '$'+format(b,'02X')
knasm='; THE SKRAUN MAIN VI / GRAPHICS II : SOURCE_ONLY P1 REPLACEMENT, NOT BUILT\n'
knasm+='; Only replace 3 K1 17-byte data rows within the existing F7A8 block.\n'
knasm+='; Data order is bottom-first for ROM: index 0 is physical bottom. Index 16 is zero guard.\n'
knasm+='; Do not change Ranger R1 rows, pointer tables, REFP1, VDEL, or code.\n'
for nm,pose in (('K1NeutralBytes','neutral'),('K1WarningBytes','warning'),('K1StrikeBytes','strike')):
    knasm+=f'{nm}:\n    dc.b '+','.join(map(da,hexrow(K1[pose])[::-1]+[0]))+'\n'
(OUT/'KNIGHT_P1_DROPIN_SOURCE_ONLY.asm').write_text(knasm)
pfasm='; THE SKRAUN MAIN VI / GRAPHICS II : SOURCE_ONLY PF1 REPLACEMENT, NOT BUILT\n'
pfasm+='; 8 x 96 = 768 bytes, expected ORG $FA00..$FD00; no extra TIA writes.\n'
pfasm+='; Even stages have CTRLPF repeat: right PF1 at x96..128. Odd reflect: x112..144.\n'
pfasm+='        ORG $FA00\nPlayPF1:\n'
for i,world in enumerate(proposed):
    pfasm+=f'; Stage {i+1} {assign[i][0]} / {assign[i][1]} / '+('REFLECT' if i%2==0 else 'REPEAT')+'\n'
    for j in range(0,96,16):pfasm+='    dc.b '+','.join(map(da,world[j:j+16]))+'\n'
pfasm+='        ORG $FD00\n'
(OUT/'WORLD_PF1_DROPIN_SOURCE_ONLY.asm').write_text(pfasm)
# Ready for exact base bank3 copy/paste. No code/ROM edit in this generator.
fullro=[x for a in proposed for x in a]
rom_kn=''.join(f'{h:02x}' for p in ('neutral','warning','strike') for h in hexrow(K1[p])[::-1]+[0])
metadata={'status':'SOURCE_ONLY, USER REVIEW REQUIRED','baseline':{'pr':76,'commit':'bd499a0736a8ed09c9e733e90387188176870039','rom_sha256':'1170604965d062916b71b48335f5ffef089bf89b8eec0418f6b17b9582d82dc1'},
'scope':'only K1 sprites, PF1 and prospective collision notes; unchanged other actor bitmaps and code',
'world_pf1':{'bytes':768,'byte_order':'world0+0..95 sequential; Y 0 bottom; screen pair row top index93','bytes_hex':[f'{b:02X}' for b in fullro],
'sha256':sha256(bytes(fullro)).hexdigest(),'old_sha256':sha256(bytes(raw)).hexdigest(),
'stages':[{'number':i+1,'mode':'reflect' if i%2==0 else 'repeat','top_motif':assign[i][0],'bottom_motif':assign[i][1],
'motif_source_top_first':{n:patterns[n] for n in assign[i]},'PF1_bytes_bottom_first_hex':[f'{b:02X}' for b in proposed[i]],
'original_collision_rectangles_game_y':[{'x0':a,'x1_exclusive':b,'y0':c,'y1_exclusive':d} for a,b,c,d in rects[i]],'metrics':metrics[i]} for i in range(8)]},
'knights':knight,'old_pr76_knights_bottom_first_hex':{k:[f'{v:02X}' for v in arr] for k,arr in original_knight.items()},
'Ranger_blobs_unmodified_sha256':sha256(bytes(sum([oldkn[x] for x in ('R1NeutralBytes','R1DrawBytes','R1ReleaseBytes')],[]))).hexdigest(),
'not_proven':'No DASM/Stella on new graphics; source-only BFS does not prove runtime motion/timing/collision; P1 multiplex flicker and sword logical reach not reverified.'}
(OUT/'GRAPHICS_AND_GEOMETRY_DATA.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
(OUT/'GEOMETRY_SOURCE_ONLY.json').write_text(json.dumps({'rects_unchanged':True,'stage_rects':rects,'L3_half_width':16,'L3_half_height':15,'L3_domain':{'x':[20,141],'y':[19,158]},'orb_centers':[(x,68) for x in OBX],
'metrics':metrics},indent=2)+'\n')
# Graphics source pixel previews
font=ImageFont.load_default()
def heading(im,text,ys=28):
    v=Image.new('RGB',(im.width,im.height+ys),(19,20,26));v.paste(im,(0,ys));ImageDraw.Draw(v).text((8,8),text,fill=(235,235,235),font=font);return v

def maskimg(rows,s=14,box=True,fg=BLUE,bg=(14,20,29)):
    p=Image.new('RGB',(8*s,len(rows)*s),bg);d=ImageDraw.Draw(p)
    for y,row in enumerate(rows):
        for x,ch in enumerate(row):
            if ch in ('#','1'):d.rectangle((x*s,y*s,(x+1)*s-1,(y+1)*s-1),fill=fg)
            if box:d.rectangle((x*s,y*s,(x+1)*s-1,(y+1)*s-1),outline=(43,54,66),width=1)
    return p
# Sprite comparison and GIF
for fam,poses in [('K1_T_VISOR',K1),('K2_BARREL_HELM',K2)]:
    for pose,rows in poses.items():
        im=maskimg(rows,s=18); heading(im,f'{fam} {pose} 8x16 SOURCE_ONLY').save(OUT/f'{fam}_{pose.upper()}_PIXELGRID.png')
        maskimg(rows,s=1,box=False).save(OUT/f'{fam}_{pose.upper()}_NATIVE_8x16.png')
        mirrored=[r[::-1] for r in rows];maskimg(mirrored,s=18).save(OUT/f'{fam}_{pose.upper()}_MIRRORED.png')
oldtop=[[f'{v:08b}' for v in oldkn[label][:16][::-1]] for label in ('K1NeutralBytes','K1WarningBytes','K1StrikeBytes')]
compare=Image.new('RGB',(3*184,480),(18,18,25));d=ImageDraw.Draw(compare)
for j,name in enumerate(['NEUTRAL','WARNING','STRIKE']):
    compare.paste(maskimg(oldtop[j],s=14),((184*j)+8,22));compare.paste(maskimg(K1[name.lower()],s=14),((184*j)+8,250))
    d.text((184*j+8,2),f'PR76 {name}',fill=(228,228,228),font=font)
    d.text((184*j+8,236),'MAIN VI K1 SOURCE_ONLY',fill=(228,228,228),font=font)
compare.save(OUT/'KNIGHT_PR76_VS_K1_SOURCE_ONLY.png')
# Review K1 and K2 on native background and as enlarged 4x/TV approx.
def showfamily(fam,poses):
    a=Image.new('RGB',(3*240,400),(21,21,26));d=ImageDraw.Draw(a)
    for j,pose in enumerate(('neutral','warning','strike')):
        a.paste(maskimg(poses[pose],s=14),(j*240+28,30))
        d.text((j*240+28,8),f'{fam} / {pose}',fill=(228,228,228),font=font)
        native=maskimg(poses[pose],s=1,box=False);a.paste(native.resize((16,32),Image.Resampling.NEAREST),(j*240+28,304))
        d.text((j*240+28,342),'8x16 source (2x shown)',fill=(210,210,210),font=font)
    a.save(OUT/f'{fam}_THREE_POSES_SOURCE_ONLY.png')
showfamily('K1_T_VISOR',K1);showfamily('K2_BARREL_HELM',K2)
framerate=[('neutral',300),('warning',200),('warning',200),('strike',110),('neutral',300)]
frames=[];dur=[]
for pose,ms in framerate:
    p=maskimg(K1[pose],s=20);p=heading(p,f'K1 {pose.upper()} | SOURCE_ONLY | {ms}ms',30);frames.append(p);dur.append(ms)
frames[0].save(OUT/'K1_T_VISOR_SWORD_CYCLE_SOURCE_ONLY.gif',save_all=True,append_images=frames[1:],duration=dur,loop=0,disposal=2)
wframes=[heading(maskimg(K1[pose],s=20),f'K1 WALK {pose} SOURCE_ONLY') for pose in ('neutral','walk_B')];wframes[0].save(OUT/'K1_OPTIONAL_WALK_AB_SOURCE_ONLY.gif',save_all=True,append_images=wframes[1:],duration=[170,170],loop=0)
# Draw all 8 stages in native 160x186, 640x480 approximate display, halo, actor reference and collision overlays.
for i in range(8):
    curr=render(proposed[i],i); prev=render(worlds[i],i)
    curr.save(OUT/f'WORLD_{i+1}_NATIVE_160x186_SOURCE_ONLY.png')
    curr.resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_TV_640x480_SOURCE_ONLY.png')
    render(proposed[i],i,True).resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_GOLD_TV_SOURCE_ONLY.png')
    for lev in (1,2,3):actor_scene(proposed[i],i,lev).resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_ACTORS_L{lev}_SOURCE_ONLY.png')
    oldnew=Image.new('RGB',(1280,520),(15,15,20));dr=ImageDraw.Draw(oldnew)
    oldnew.paste(prev.resize((640,480),Image.Resampling.NEAREST),(0,30));oldnew.paste(curr.resize((640,480),Image.Resampling.NEAREST),(640,30))
    dr.text((8,8),f'WORLD {i+1} | PR76 SOURCE RECONSTRUCTION',fill='white',font=font)
    dr.text((648,8),'MAIN VI SOURCE_ONLY REFINEMENT',fill='white',font=font)
    oldnew.save(OUT/f'WORLD_{i+1}_BEFORE_AFTER_SAME_TV_SCALE.png')
    coll=curr.copy();d=ImageDraw.Draw(coll)
    for x0,x1,y0,y1 in rects[i]:d.rectangle((x0,y0+10,x1-1,y1+9),outline=(255,95,90),width=1)
    coll.resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_COLLISION_ENVELOPES_SOURCE_ONLY.png')
    # left/right visualization with original raw byte on left and exact kernel-mode transform on right
    half=curr.copy();dp=ImageDraw.Draw(half);dp.line((80,0,80,185),fill=(246,234,103))
    half.resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_PF1_REFLECT_REPEAT_EXACT_SOURCE_ONLY.png')
# 2x4 overview of eight worlds, stage color names and mode header
names=['SKOG 1','SKOG 2','BERG 1','BERG 2','DROM 1','DROM 2','NATT 1','NATT 2']
allim=Image.new('RGB',(4*320,2*390),(21,22,27));dd=ImageDraw.Draw(allim)
for i in range(8):
    x=i%4*320;y=i//4*390
    dd.text((x+8,y+7),f'{names[i]} - '+('REFLEKTERAD' if i%2==0 else 'UPPREPAD'),fill=(240,240,240),font=font)
    allim.paste(render(proposed[i],i).resize((320,372),Image.Resampling.NEAREST),(x,y+18))
allim.save(OUT/'ALL_EIGHT_WORLDS_MAIN_VI_SOURCE_ONLY.png')
# Montage actual prior frame vs proposed source-only (not implying same game state)
# Show skill-specific one glance for stage 2 and 8.
focus=Image.new('RGB',(2*420,2*510),(16,16,22));d=ImageDraw.Draw(focus)
for i,stage in enumerate((1,3,5,7)):
    x=(i%2)*420;y=(i//2)*510
    focus.paste(render(proposed[stage],stage).resize((400,465),Image.Resampling.NEAREST),(x+10,y+28))
    d.text((x+10,y+8),f'EVEN STAGE {stage+1}: PF1 REPEAT (SOURCE_ONLY)',fill='white')
focus.save(OUT/'EVEN_STAGES_2_4_6_8_SOURCE_ONLY.png')
# Individual motif swatches: isolate band of PF1 for one physical left-hand motif.
for i in range(8):
    for m,(lo,hi) in zip(('TOP','BOTTOM'),bands(worlds[i])):
        data=[0]*96
        for j in range(lo,hi+1):data[j]=proposed[i][j]
        im=render(data,i)
        # left half only: 16..48cc, source match bitmap
        ys=[2*(93-j) for j in range(hi,lo-1,-1)]
        ya=max(0,min(ys)-4); yb=min(186,max(ys)+6)
        crop=im.crop((10,ya,54,yb)); crop.resize((crop.width*8,crop.height*6),Image.Resampling.NEAREST).save(OUT/f'MOTIF_STAGE_{i+1}_{m}_SOURCE_ONLY.png')
print('generated',len(list(OUT.iterdir())),'visual / data files')
print('BYTE_SHA256',metadata['world_pf1']['sha256'],'OLD',metadata['world_pf1']['old_sha256'])
print('METRICS',json.dumps(metrics))
