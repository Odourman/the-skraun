; GRAPHICS II SOURCE_ONLY collision proposal. DO NOT APPLY WITHOUT MAIN/ROM AUTHORIZATION.
WorldRects:
; stage 1 Skog: 4x half-open x0,x1,y0,y1
        dc.b $14,$28,$00,$2B,$78,$8C,$00,$2B,$14,$28,$8B,$BA,$78,$8C,$8B,$BA
; stage 2 Skog: 4x half-open x0,x1,y0,y1
        dc.b $14,$24,$00,$2B,$64,$74,$00,$2B,$14,$2C,$8B,$BA,$64,$7C,$8B,$BA
; stage 3 Berg: 4x half-open x0,x1,y0,y1
        dc.b $14,$2C,$00,$2B,$74,$8C,$00,$2B,$14,$2C,$8B,$BA,$74,$8C,$8B,$BA
; stage 4 Berg: 4x half-open x0,x1,y0,y1
        dc.b $14,$2C,$00,$2B,$64,$7C,$00,$2B,$14,$2C,$8B,$BA,$64,$7C,$8B,$BA
; stage 5 Dröm: 4x half-open x0,x1,y0,y1
        dc.b $14,$2C,$00,$2B,$74,$8C,$00,$2B,$14,$2C,$8B,$BA,$74,$8C,$8B,$BA
; stage 6 Dröm: 4x half-open x0,x1,y0,y1
        dc.b $14,$2C,$00,$2B,$64,$7C,$00,$2B,$14,$2C,$8B,$BA,$64,$7C,$8B,$BA
; stage 7 Natt: 4x half-open x0,x1,y0,y1
        dc.b $14,$2C,$00,$2B,$74,$8C,$00,$2B,$14,$2C,$8B,$BA,$74,$8C,$8B,$BA
; stage 8 Natt: 4x half-open x0,x1,y0,y1
        dc.b $14,$2C,$00,$2B,$64,$7C,$00,$2B,$14,$2C,$8B,$BA,$64,$7C,$8B,$BA
