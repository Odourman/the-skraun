# GRAPHICS II — FINAL WORLD GRAPHICS | MAIN V | 2026-11-25

## Resultat
**Åtta PF1-världar (8×96 bytes), 16 skilda maskmotiv (14 × 8×6 och 2 × 8×12 spiraler), direkt DASM-ready. SOURCE_ONLY.** Designen följer användarens godkända referensbild, förverkligad inom existerande rasterkärna. Totalt ändrade **448 av 768 PF1-databyte** gentemot fryst PR60. Baslinjens 768B SHA256 `f0dff70e062607e32f86000d2d85e0fcf91863d5c2778c168f1b02b2f114acd4`, ny tabell `deba82b22fae37567f885a90e4ea4a862e893d3be1f91653c21c8ef53d3c824e`.

### Käll- och bevisnivå
- PR60 HEAD `2af9855fbe8d3edbe6d01609d3e539547b744aef`; officiellt SHA för befintlig 16KiB-ROM `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647`.
- Lästa Project Sources 00–04, GitHub docs `DESIGN_DECISIONS_01-60_2026-11-16.md`, `SKRAUN_VISUAL_DIRECTION_2026-11-16.md`, PR60 och faktisk PR60 bank0/bank2/bank3 ASM från original-ROM-leverans i Drive. Ursprunglig godkänd bild oförändrad.
- Baslinjefoton i `08_BEFORE_AFTER/*PR60_ACTUAL_STELLA*` kommer ur PR60:s verkliga Stella-delivery ZIP. Alla nya förhandsvisningar är **SOURCE_ONLY**, aldrig kallade Stella.

## Utformning
| Bana | Värld | Överst | Nederst | Horisontell metod |
|---|---|---|---|---|
| 1 | Skog | Barrträd A | Rundkronat träd A | mirror |
| 2 | Skog | Barrträd B | Rundkronat träd B | repeat |
| 3 | Berg | Spetsigt berg A | Rundare berg A | mirror |
| 4 | Berg | Spetsigt berg B | Rundare berg B | repeat |
| 5 | Dröm | Spiral A | Portal A | mirror |
| 6 | Dröm | Spiral B | Portal B | repeat |
| 7 | Natt | Mur A | Ruin A | mirror |
| 8 | Natt | Mur B | Ruin B | repeat |

## Faktiskt original-TIA-dataformat
- **8 bitars PF1** används för miljön; en bit tar 4 av 160 fysiska färgklockor, PF1 ligger på vänster sida i x16..47. Höger kopia är speglad eller upprepad genom befintliga CTRLPF-kodvägar (inga extra skrivningar).
- 14 motiv har **8×6** källbitar och 8 rasterrader per källrad. Spiral A/B har **8×12** källbitar och 4 rasterrader per källrad för mer läsbar fyrkantig spiral; båda utgör likväl exakt 24 PF1-byte och totalt 48 rasterrader var. Mittens 48-byte nollor innebär 96 fysiska tomma rasterlinjer i basdata.
- Tabellen lagras **nedre motiv 24 bytes i omvänd radordning, sedan 48 bytes nollor, översta motiv 24 bytes i omvänd radordning**. Den synliga kärnan kör X=186..1 och läser `WorldPFIndex[x]`, så 2 högsta tabellbyte per bana index94..95 visas inte. Det övre motivets första 8-radersband visas därför bara 4 rasterrader; resten behålls. Inga spegelvända träd eller vertikalt inverterade berg.
- Existerande pekartabell i bank0 `WorldPFLo/Hi` behålls oförändrad. 96 bytes per bana vid $FA00,$FA60,$FAC0,$FB20,$FB80,$FBE0,$FC40,$FCA0. Upptar $FA00..$FCFF, slutar vid $FD00.
- Ingen ändring i Visible/VisibleArrow, WorldPFIndex, CTRLPF, registerfärger eller RAM. Därmed **ingen ny synlig TIA-registreringskostnad från själva grafiken**, men byteinnehållets verkliga läsbarhet/halo/IRQ-fall kräver ROM/Stella.

## Färg
Behåll befintliga TIA-värden i bank2: skog `$C6/$C8`, berg `$36/$38`, dröm `$56/$58`, natt `$06/$08`; exakta skärmfärger varierar med TV och emulatorpalett. SOURCE_ONLY-RGB i JSON är bara illustrativa. Halon gör **hela PF guld** enligt testmodell B, inte individuella objektfärger. Spelets gamla ofullständiga 360-halo är en separat teknisk begränsning, inte löst av detta paket.

## Spelbarhet, kollisionssanning och risk
Fyra markerade miljöobjekt/bana är **inte** fyra godtyckliga spritekopior utan PF1:s två skärmkopior av respektive två olika motiv. Alla varianter behåller ett brett öppet mittfält och y-centrum. Samtliga 8 föreslagna 4×AABB-rektangeluppsättningar testades source-only med samma Level3 centrumgränser och HalfW=16/HalfH=18 som nuvarande `bank3.asm` och alla 8 var sammanhängande från center (80,88). Minsta antal lagliga Level3-centrum: 9085.

**VARNING:** Aktuell PR60 WorldRects blockerar på delvis andra platser än nya PF1-silhuetterna. `05_COLLISION_RECOMMENDATIONS.json` innehåller separata nya 16-byte *kandidater* att granska. De har en rektangel per synlig silhuett (exakt AABB över dess icke-noll PF1-pixlar), alltså kan triangulära berg/spiralhål/portalvalv ha osynlig kollisionsyta inuti sin AABB. Detta är ett källmodellsavsteg, inte en spårad gameplaykollision. Ingen av rektanglarna har införts i ROM. Endast ROM DEVELOPMENT får pröva att ersätta WorldRects efter separat MAIN V-order. Värld 5/6:s portaler förblir **solida, inte teleporters**.

### Försiktighetsgränser
1. 76 CPU-cykler per fysisk rad och verkliga beamdeadlines är inte uppmätta för nya tabellen; den nya grafiken undviker extra registerskrivningar men detta är inte en generell renderer-GO.
2. L3-framkomlighet ovan gäller matematiska sammanhängande centerpositioner under kollisionsförslagen, inte verklig 8-riktnings-Stella-playtest, orb/tillväxt, svärd eller arrow.
3. P0 = fryst U1-LEG1. P1-kandidater/final aktörsuppsättning är orörda; tre fiender samtidigt och slutlig halo är fortfarande tekniska begränsningar.
4. Vissa motivs finform (spiral, portalöppning, bergkant) kan inte beskrivas pixel-perfekt med ett enda axis-aligned kollisionsrektangelobjekt. Inget ingrepp i kollisionsalgoritm auktoriserat.
5. Detta är implementerbar **dataleverans**, inte byggd/visad ROM. Integrationen och fysisk acceptans tillhör ROM DEVELOPMENT efter ny order.

**Rekommendation:** godkänn denna sammanhållna, stilrena, hårdvarunära PF1-kandidat som nästa grafikunderlag, granska kollisionernas hörn/portalhål vid verklig körning och bevara de 8 unika banorna. STOP GRAPHICS II efter leverans.
