# MAIN V → ROM DEVELOPMENT: kort SOURCE_ONLY handoff (INTE implementationstillstånd)

**BASLINJE:** PR60, `2af9855fbe8d3edbe6d01609d3e539547b744aef`, standard F6 16KiB NTSC, ROM-SHA `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647`. Detta paket på separat GRAPHICS-gren.

**När MAIN separat beordrar integration:**
1. I `experiments/fullgame1_arrow_halo_20261125/bank3.asm`: byt den **enda** befintliga `PlayPF1:`-tabellen mellan `ORG $FA00` och `ORG $FD00` mot texten i `03_PLAYFIELD_DATA.asm`. Ändra inte $FD00, WorldPFIndex, WorldPFPtr, Visible, VisibleArrow eller HaloRowPtr.
2. **Behåll** bank0 `WorldPFLo/Hi` oförändrade, och bank2:s `SetWorldColors`/`CTRLPF` och palett. Stadier 1,3,5,7 är `mirror` och 2,4,6,8 `repeat` i originalet.
3. I bank0 `WorldRects:` finns 8×16 bytes för de fyra solida föremålen. **Om MAIN godkänner** kandidaterna: uppdatera endast dessa 128 data-byte med `03_04_05_DATA/05_COLLISION_CANDIDATE_BYTES_NOT_APPLIED.asm`, utan att ändra `CandidateValid`. Avvikelsen mellan synlig spiral/portalöppning och AABB är **avsiktligt synlig risk**; begär designbeslut om solid yta innan patch.
4. Källkontroll: 96 byte per värld = 768 byte; ny PF1-dataström SHA256 `deba82b22fae37567f885a90e4ea4a862e893d3be1f91653c21c8ef53d3c824e`. Enbart source-data, ingen ny ROM med denna hash påstås finnas.
5. Efter separat auktorisation: bygg verklig F6 i DASM, kontrollera bank3 ryms oförändrat, 262 NTSC-rader, beamdeadlines, 128B RAM+stack, riktig Stella pixelordning och verklig input/navigerbarhet L3 samt orb-/växthörn. Kör sedan 8 världar och både inaktiv och aktiv guld-PF. Rapportera bara verkliga PASS.

**VIKTIGT:** inga sprites, ranger, attack eller halologik i detta grafikuppdrag ändrade. Ingen ny ROM, ingen merge, ingen Verification.
