# Källregister

- Användaren 2026-11-25: bifogad `The_Skraun_godkand_grafikreferens(1).png`, kopierad oförändrad under `11_APPROVED_VISUAL_REFERENCE/` (visuell designauktoritet).
- User-supplied arbetsorder: `THE SKRAUN – GRAPHICS II FINAL WORLD GRAPHICS – ALL EIGHT ARENAS`, 2026-11-25. Ursprung finns i användarens inklistrade text.
- Project Sources 00–04 daterade 2026-11-21: navigation, inte permanent live implementation.
- GitHub live PR60 https://github.com/Odourman/the-skraun/pull/60, HEAD `2af9855fbe8d3edbe6d01609d3e539547b744aef` (check at receipt), ROM SHA `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647`.
- Faktiska ASM: `experiments/fullgame1_arrow_halo_20261125/{bank0,bank2,bank3}.asm`, hämtade ur exakt leveranspaket Google Drive `1yhOprGF-PsQ7kPLPNw7bgV_mX3jOb3gn` och matchade live PR60-grenens källinnehåll/relevanta symboler.
- Baseline Stella PNG: `fresh/play_final/visit_01_stage1.png` … `visit_08_stage8.png` från PR60:s utvecklarpaket (verkligt captured, utgör inte nytt test).
- Spelets grafiska beslut: https://github.com/Odourman/the-skraun/blob/main/docs/DESIGN_DECISIONS_01-60_2026-11-16.md ; https://github.com/Odourman/the-skraun/blob/main/docs/SKRAUN_VISUAL_DIRECTION_2026-11-16.md
- Exact frozen player bitmap: https://github.com/Odourman/the-skraun/blob/graphics/u1-leg1-caprine-gait-20261116/graphics/u1_leg1/SOURCE_U1_LEG1.json (kopierad endast för storleksexempel, *inte* ändrad).
- Förhandsvisningar, masktabeller, AABB och navigatorcheckar: ny `SOURCE_ONLY` från deterministiskt genereringsskript. Inte oberoende verifiering och inte ROM.
