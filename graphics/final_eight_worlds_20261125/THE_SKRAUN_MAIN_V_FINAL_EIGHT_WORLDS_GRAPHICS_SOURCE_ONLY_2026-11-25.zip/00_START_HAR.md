# THE SKRAUN — FINAL WORLD GRAPHICS — GRAPHICS II → MAIN V

**2026-11-25 | SOURCE_ONLY | Uppdragsgräns: ENDAST grafik och förslag till kollision.**

Hela leveransen bygger på godkänd bildreferens i `11_APPROVED_VISUAL_REFERENCE/` och exakt PF1-källstruktur i PR #60. De 16 individuella motiven är 14 enkla 8×6-masker och 2 tydligare 8×12-spiraler, utlagda som 32 färgklockor × 48 rasterlinjer (PF1-bitar 4 färgklockor breda; 8 respektive 4 rasterrader per källrad). Varje bana har överst ett eget motiv och nederst ett annat. Horisontell spegling gäller 1/3/5/7, upprepning 2/4/6/8.

- **Rapport:** `01_GRAPHICS_REPORT.md`.
- **Kort integrationshandoff:** `02_HANDOFF_TO_ROM_DEVELOPMENT.md`.
- **Komplett DASM-tabell:** `03_PLAYFIELD_DATA.asm` (8×96 = **768B**, samma storlek som PR60).
- **Maskspecifikationer:** `03_04_05_DATA/04_WORLD_GRAPHICS.json`.
- **Föreslagna kollisionsrektanglar:** `03_04_05_DATA/05_COLLISION_RECOMMENDATIONS.json`.
- **Alla åtta banor:** `06_PREVIEWS/ALL_EIGHT_ARENAS_PF_SOURCE_ONLY.png`.
- **Guldfärg under halo:** `06_PREVIEWS/ALL_EIGHT_GOLD_PF_SOURCE_ONLY.png`.
- **Med oförändrade figurkällor som storleksreferens:** `06_PREVIEWS/ALL_EIGHT_WITH_ACTORS_SIZE_REFERENCE_SOURCE_ONLY.png`.
- **Original-vs-nytt per bana:** `08_BEFORE_AFTER/`.
- **Reproduktion:** `09_GENERATOR/build_worlds.py`.

**Kontrollerat:** 768 byte source data, 8 skilda masker, 16 unika motiv, alla 8 Level3-modeller förenade och spawn (80,88) fri. Ny PF1-tabell SHA256: `deba82b22fae37567f885a90e4ea4a862e893d3be1f91653c21c8ef53d3c824e`. ***Inga nya ROM- eller Stella-prov har utförts på nya grafiken.***

Originalkällor ändras inte. Ingen main-merge. Behåll projektets befintliga spel- och animationskrav.
