#!/usr/bin/env python3
"""THE SKRAUN -- SOURCE_ONLY: deterministic PF1 data & graphical proof generator.
No ROM build, no writes to active game branch. Requires Pillow only.
"""
from __future__ import annotations
import hashlib, io, json, math, re, shutil, sys
from collections import deque
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT
DATA=OUT/'03_04_05_DATA'
PRE=OUT/'06_PREVIEWS'
MOT=OUT/'07_INDIVIDUAL_MOTIFS'
COMPARE=OUT/'08_BEFORE_AFTER'
GEN=OUT/'09_GENERATOR'
REF=OUT/'11_APPROVED_VISUAL_REFERENCE'
for p in (DATA,PRE,MOT,COMPARE,GEN,REF):p.mkdir(parents=True,exist_ok=True)
SRC=ROOT/'09_GENERATOR'/'BANK3_PR60_EXACT_SOURCE.asm'
SCENE_SRC=None
APPROVED=ROOT/'11_APPROVED_VISUAL_REFERENCE'/'The_Skraun_godkand_grafikreferens_UNMODIFIED.png'

# Each character is one native TIA PF1 bit, 4 colour-clocks wide, 8 rasterlines per row (4 for 12-row spiral).
# Only pixels between columns 1 and 6 may be set: preserves an open central corridor in repeat mode.
MOTIFS = {
'01_fir_A': ('00010000','00111000','01111100','01111100','00010000','00010000'),
'01_round_A': ('00111000','01111100','01111100','00111000','00010000','00010000'),
'02_fir_B': ('00100000','01110000','01111000','01111000','00100000','00100000'),
'02_round_B': ('00011100','00111110','01111110','00111110','00011000','00011000'),
'03_peak_A': ('00010000','00111000','01111100','01111110','01111110','01111110'),
'03_hill_A': ('00111100','01111110','01111110','01111110','01111110','01111110'),
'04_peak_B': ('00100000','01110000','01111000','01111100','01111110','01111110'),
'04_hill_B': ('00011100','00111110','00111110','01111110','01111110','01111110'),
'05_spiral_A': ('00000000','01111110','01000010','01000010','01011110','01010000','01010110','01010110','01010010','01011110','01000000','01111110'),
'05_portal_A': ('00111100','01111110','01100110','01100110','01100110','01100110'),
'06_spiral_B': ('00000000','01111110','01000010','01000010','01111010','00001010','01101010','01101010','01001010','01111010','01000010','01111110'),
'06_portal_B': ('00011000','00111100','01111110','01100110','01100110','01100110'),
'07_wall_A': ('01101110','01101110','01111110','01111110','01111110','01111110'),
'07_ruin_A': ('01100010','01100110','01110110','01111110','01111110','01111110'),
'08_wall_B': ('01011010','01011010','01111110','01111110','01111110','01111110'),
'08_ruin_B': ('01000110','01100110','01101110','01111110','01111110','01111110'),
}
WORLD_DESCS=[
('Skog','Barrträd A','Rundkronat träd A','01_fir_A','01_round_A'),
('Skog','Barrträd B','Rundkronat träd B','02_fir_B','02_round_B'),
('Berg','Spetsigt berg A','Rundare berg A','03_peak_A','03_hill_A'),
('Berg','Spetsigt berg B','Rundare berg B','04_peak_B','04_hill_B'),
('Dröm','Spiral A','Portal A','05_spiral_A','05_portal_A'),
('Dröm','Spiral B','Portal B','06_spiral_B','06_portal_B'),
('Natt','Mur A','Ruin A','07_wall_A','07_ruin_A'),
('Natt','Mur B','Ruin B','08_wall_B','08_ruin_B'),
]
# RGBA previews approximate console palette; binding ROM bytes stay unchanged.
COLORS={
'Skog': {'background':'#101b13','world':'#57964c','knight':'#9bd8f3','ranger':'#a0bc78','TIA_world':['$C6','$C8'],'TIA_background':['$00','$00']},
'Berg': {'background':'#11161d','world':'#94a8b4','knight':'#9bd8f3','ranger':'#8d96ad','TIA_world':['$36','$38'],'TIA_background':['$02','$02']},
'Dröm': {'background':'#1b1020','world':'#ae73c5','knight':'#9bd8f3','ranger':'#b7a2c9','TIA_world':['$56','$58'],'TIA_background':['$04','$04']},
'Natt': {'background':'#090d17','world':'#7487b1','knight':'#9bd8f3','ranger':'#7588aa','TIA_world':['$06','$08'],'TIA_background':['$00','$00']},
}
GOLD='#eebd4c'
BG_W,BG_H=160,192
RENDERED_H=186  # Visible loop: X=186..1 => 186 physical lines; row index floor(X/2)

# Exact prior HEAD source table parser, not a transcription from a concept image.
src=SRC.read_text(encoding='utf8')
part=src.split('PlayPF1:',1)[1].split('ORG $FD00',1)[0]
old=[]
for w in range(1,9):
 m=re.search(r'^; World '+str(w)+r':[^\n]*\n(.*?)(?=^; World |\Z)',part,re.S|re.M)
 assert m, f'old world {w} missing'
 values=[int(v,16) for v in re.findall(r'\$([0-9A-Fa-f]{2})',m.group(1))]
 assert len(values)==96,(w,len(values))
 old.append(values)

# Raw U1-LEG1 A data and original P1 candidates for illustrative size refs.
from zipfile import ZipFile
u1=json.loads((ROOT/'09_GENERATOR'/'SOURCE_U1_LEG1.json').read_text())
U1A=u1['one_candidate_U1_LEG1']['A']
assert len(U1A)==12 and all(len(s)==8 for s in U1A)
K1HEX=[]; R1HEX=[]
for needle, dest in [('K1NeutralBytes',K1HEX),('R1NeutralBytes',R1HEX)]:
  m=re.search(r'(?m)^'+needle+r':\s*\n\s*dc\.b ([^\n]+)',src)
  assert m,needle
  dest.extend(int(v,16) for v in re.findall(r'\$([0-9A-Fa-f]{2})',m.group(1))[:16])
assert len(K1HEX)==len(R1HEX)==16
K1_TOP=[format(a,'08b') for a in reversed(K1HEX)]
R1_TOP=[format(a,'08b') for a in reversed(R1HEX)]


def motif_bytes(motif):return [int(s,2) for s in motif]
def world_bytes(top,bottom):
 # In-memory source table for (WorldPFPtr),Y is in reverse screen order.
 # Top of screen indexes 95..72, middle 71..24, bottom 23..0.
 # WorldPFIndex[X]=floor(X/2), so topmost two byte indices 95 and 94 are unobserved at X=186.
 assert 24%len(bottom)==24%len(top)==0
 bottom_data=[v for row in reversed(bottom) for v in [int(row,2)]*(24//len(bottom))]
 top_data=[v for row in reversed(top) for v in [int(row,2)]*(24//len(top))]
 result=bottom_data+[0]*48+top_data
 assert len(result)==96 and all(result[i]==0 for i in range(24,72))
 return result

def line_bytes(data):return [data[(186-y)//2] if y<RENDERED_H else 0 for y in range(BG_H)]

def rects_for_map(values,mode):
 # Occupied-cell AABB separately per corner (TOP L, TOP R, BOTTOM L, BOTTOM R).
 # The bounding envelope (including spiral/portal void) is deliberately SOLID;
 # it cannot be claimed to equal fine-grain PF pixel collision.
 line=line_bytes(values)
 group=[[],[],[],[]]
 for y,value in enumerate(line[:RENDERED_H]):
  if not value:continue
  section=0 if y<90 else 2
  for i in range(8):
   if value & (0x80>>i):
    x=16+4*i
    xr=140-4*i if mode=='mirror' else 96+4*i
    group[section].append((x,y));group[section].append((x+3,y))
    group[section+1].append((xr,y));group[section+1].append((xr+3,y))
 boxes=[]
 for pix in group:
  assert pix
  box=[min(a for a,b in pix),max(a for a,b in pix)+1,min(b for a,b in pix),max(b for a,b in pix)+1]
  assert 0<=box[0]<box[1]<=160 and 0<=box[2]<box[3]<=186,box
  boxes.append(box)
 return boxes

def draw_playfield(vals,world,mode,halo=False):
 palette=COLORS[world]; pic=Image.new('RGB',(BG_W,BG_H),palette['background']); dr=ImageDraw.Draw(pic)
 color=GOLD if halo else palette['world']
 for y,v in enumerate(line_bytes(vals)[:RENDERED_H]):
  for b in range(8):
   if v & (0x80>>b):
    x=16+4*b; xr=(140-4*b if mode=='mirror' else 96+4*b)
    dr.rectangle((x,y,x+3,y),fill=color)
    dr.rectangle((xr,y,xr+3,y),fill=color)
 return pic

def draw_sprite(pic,rows,cx,cy,color):
 d=ImageDraw.Draw(pic)
 for j,r in enumerate(rows):
  for i,c in enumerate(r):
   if c=='1':
    x=cx-4+i; y=cy-len(rows)//2+j
    if 0<=x<160 and 0<=y<192:d.point((x,y),fill=color)


def connected_l3(boxes):
 # Exactly the *current* source CandidateValid bounds, and its halfwidth/height,
 # with proposed raw rectangles. This is mathematical SOURCE_ONLY geometry, not observed joystick use.
 free=set()
 for y in range(22,155):
  for x in range(20,141):
   ok=all((x+16<a or x-16>=b or y+18<c or y-18>=d) for a,b,c,d in boxes)
   if ok:free.add((x,y))
 if (80,88) not in free:return {'error':'spawn blocked', 'free_centers':len(free)}
 dq=deque([(80,88)]);seen={(80,88)}
 while dq:
  x,y=dq.popleft()
  for p in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
   if p in free and p not in seen:seen.add(p);dq.append(p)
 return {'legal_l3_centers':len(free),'connected_from_start':len(seen),'fully_connected':len(free)==len(seen),'start_80_88_safe':True,'central_band_valid':all((80,y) in free for y in range(63,119))}

def font(size,bold=False):
 fn='/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf'
 return ImageFont.truetype(fn,size)

scenes=[]
for idx,(world,topname,bottomname,topkey,bottomkey) in enumerate(WORLD_DESCS,1):
 top=MOTIFS[topkey];bottom=MOTIFS[bottomkey]
 for name,s in ((topname,top),(bottomname,bottom)):
  assert len(s) in (6,12) and all(len(r)==8 and set(r)<={'0','1'} for r in s)
  assert all(r[0]==r[-1]=='0' for r in s),'central corridor violation '+name
 mode='mirror' if idx%2 else 'repeat'
 raw=world_bytes(top,bottom)
 boxes=rects_for_map(raw,mode)
 nav=connected_l3(boxes)
 assert nav.get('fully_connected'),(idx,nav)
 assert nav.get('central_band_valid'),(idx,nav)
 assert any(raw),idx
 scene={'stage':idx,'world':world,'top_motif':topname,'bottom_motif':bottomname,'top_key':topkey,'bottom_key':bottomkey,'ctrplf_mode':mode,'byte_count':96,'PF1_hex_top_order': [f'${v:02X}' for v in raw], 'PF1_binary_top_order':[format(v,'08b') for v in raw], 'raw_colliders_xyxy_exclusive':boxes,'navigation_l3_source_only':nav,
        'color':COLORS[world]}
 scenes.append(scene)
 stem=f'{idx:02d}_{world.lower().replace("ö","o")}'
 pf=draw_playfield(raw,world,mode)
 pf.resize((640,768),Image.Resampling.NEAREST).save(PRE/(stem+'_PLAYFIELD_4X_SOURCE_ONLY.png'))
 gold=draw_playfield(raw,world,mode,True)
 gold.resize((640,768),Image.Resampling.NEAREST).save(PRE/(stem+'_HALO_GOLD_4X_SOURCE_ONLY.png'))
 # Concept illustration: source masks are exact; multi-actor scheduling is not modeled or claimed.
 spr=pf.copy()
 draw_sprite(spr,U1A,80,94,'#d2d2d1')
 draw_sprite(spr,K1_TOP,50,87,COLORS[world]['knight'])
 draw_sprite(spr,K1_TOP,113,110,COLORS[world]['knight'])
 draw_sprite(spr,R1_TOP,130,86,COLORS[world]['ranger'])
 spr.resize((640,768),Image.Resampling.NEAREST).save(PRE/(stem+'_SPRITES_SIZE_REFERENCE_4X_SOURCE_ONLY.png'))
 # translucent red bounding rectangles, not claims of source-exact collision physics.
 coll=pf.convert('RGBA');lay=Image.new('RGBA',pf.size,(0,0,0,0));ld=ImageDraw.Draw(lay)
 for j,(x1,x2,y1,y2) in enumerate(boxes):
  ld.rectangle((x1,y1,x2-1,y2-1),fill=(250,65,45,65),outline=(255,96,67,255),width=1)
 coll=Image.alpha_composite(coll,lay).convert('RGB')
 coll.resize((640,768),Image.Resampling.NEAREST).save(PRE/(stem+'_COLLISION_CANDIDATES_4X_SOURCE_ONLY.png'))
 # Native 160x192 is the model resolution, 1:1 (no interpolation).
 pf.save(PRE/(stem+'_PLAYFIELD_NATIVE_160x192_SOURCE_ONLY.png'))
 # Before/after derived from actual old/new 96 PF1 bytes, same pixel renderer.
 before=draw_playfield(old[idx-1],world,mode)
 before.save(COMPARE/(stem+'_PR60_BASELINE_SOURCE_RECONSTRUCTION_NATIVE.png'))
 panel=Image.new('RGB',(2*640+32,768+72),'#e8e5df');d=ImageDraw.Draw(panel)
 panel.paste(before.resize((640,768),Image.Resampling.NEAREST),(0,72))
 panel.paste(pf.resize((640,768),Image.Resampling.NEAREST),(672,72))
 d.text((13,18),f'BANA {idx} – PR60 DATA, SOURCE_ONLY',font=font(24,True),fill='#151515')
 d.text((680,18),'NY GRAFIK – SOURCE_ONLY',font=font(24,True),fill='#151515')
 panel.save(COMPARE/(stem+'_BEFORE_AFTER_SOURCE_ONLY.png'))

# Individual motif files (bits exact, native 8x6 and big pixel-aligned zoom).
for key,rows in MOTIFS.items():
 v=Image.new('RGB',(8,len(rows)),'#101317');d=ImageDraw.Draw(v)
 typ=int(key[:2]);world=WORLD_DESCS[typ-1][0]
 for y,row in enumerate(rows):
  for x,c in enumerate(row):
   if c=='1':d.point((x,y),fill=COLORS[world]['world'])
 v.save(MOT/(key+'_NATIVE_8x6.png'))
 scale=34 if len(rows)==12 else 52
 canvas=Image.new('RGB',(8*scale+104,len(rows)*scale+128),'#eae8e4');d=ImageDraw.Draw(canvas)
 grid=v.resize((8*scale,len(rows)*scale),Image.Resampling.NEAREST)
 canvas.paste(grid,(52,58))
 for i in range(9):d.line((52+scale*i,58,52+scale*i,58+len(rows)*scale),fill='#4d4d4d',width=1)
 for i in range(len(rows)+1):d.line((52,58+scale*i,52+8*scale,58+scale*i),fill='#4d4d4d',width=1)
 d.text((52,17),key+' | SOURCE_ONLY',fill='#111',font=font(18,True))
 canvas.save(MOT/(key+'_SOURCE_PIXELS_ZOOM.png'))

# Comparison board of eight screens and gold view board.
def board(halo=False,actors=False,collision=False):
 width=4*304+3*14; height=2*424+14
 out=Image.new('RGB',(width,height),'#eeece7');d=ImageDraw.Draw(out)
 for k,s in enumerate(scenes):
  col=k%4;row=k//4;x=col*318;y=row*438
  mode=s['ctrplf_mode'];a=draw_playfield(s['PF1_byte_values'],s['world'],mode,halo)
  if actors:
   draw_sprite(a,U1A,80,94,'#d2d2d1');draw_sprite(a,K1_TOP,50,87,COLORS[s['world']]['knight']);draw_sprite(a,K1_TOP,113,110,COLORS[s['world']]['knight']);draw_sprite(a,R1_TOP,130,86,COLORS[s['world']]['ranger'])
  if collision:
   ov=Image.new('RGBA',a.size,(0,0,0,0));pd=ImageDraw.Draw(ov)
   for q in s['raw_colliders_xyxy_exclusive']:
    x1,x2,y1,y2=q;pd.rectangle((x1,y1,x2-1,y2-1),fill=(240,80,60,60),outline=(255,100,60,255))
   a=Image.alpha_composite(a.convert('RGBA'),ov).convert('RGB')
  a=a.resize((300,360),Image.Resampling.NEAREST)
  d.text((x+7,y+4),f'{s["stage"]}. {s["world"]}  {mode.upper()}',font=font(15,True),fill='#141414')
  out.paste(a,(x+2,y+32))
  d.text((x+6,y+398),s['top_motif']+' / '+s['bottom_motif'],font=font(12),fill='#242424')
 return out
# Runtime data source field below; images must be generated from identical exported bytes.
for s in scenes:s['PF1_byte_values']=[int(h[1:],16) for h in s['PF1_hex_top_order']]
board().save(PRE/'ALL_EIGHT_ARENAS_PF_SOURCE_ONLY.png')
board(halo=True).save(PRE/'ALL_EIGHT_GOLD_PF_SOURCE_ONLY.png')
board(actors=True).save(PRE/'ALL_EIGHT_WITH_ACTORS_SIZE_REFERENCE_SOURCE_ONLY.png')
board(collision=True).save(PRE/'ALL_EIGHT_COLLISION_PROPOSALS_SOURCE_ONLY.png')

# Approved reference (unchanged) and original authentic Stella screen pixels, as distinct evidence.
if APPROVED.resolve() != (REF/'The_Skraun_godkand_grafikreferens_UNMODIFIED.png').resolve():
 shutil.copyfile(APPROVED,REF/'The_Skraun_godkand_grafikreferens_UNMODIFIED.png')
# Do not alter previously preserved immutable original Stella PNGs during regeneration.

# Export DASM data. No modification to bank3.asm / gameplay branch.
def table_source():
 lines=['; THE SKRAUN - GRAPHICS II / MAIN V 2026-11-25',
        '; SOURCE_ONLY, NOT DASM/STELLA TESTED. Replace ONLY the original PlayPF1 table in bank3.asm.',
        '; Keep ORG $FA00, 8x96 bytes, pointer table 00,60,C0,20,80,E0,40,A0 and F(A..C) banks as-is.',
        '; Each PF1 pixel is 4 colour clocks wide; bank3 displays world rows in reversed X order.',
        '        ORG $FA00', 'PlayPF1:']
 for i,s in enumerate(scenes,1):
  vals=s['PF1_byte_values']
  lines.append(f'; World {i}: {s["world"]} | TOP {s["top_motif"]} | BOTTOM {s["bottom_motif"]} | {s["ctrplf_mode"]}')
  for j in range(0,96,24):
   lines.append('        dc.b '+','.join(f'${v:02X}' for v in vals[j:j+24]))
 lines.append('        ; 8 * 96 = 768 bytes, ends at $FD00 (exclusive).')
 return '\n'.join(lines)+'\n'
(OUT/'03_PLAYFIELD_DATA.asm').write_text(table_source(),encoding='utf8')

motif_export={name:{'rows_top_to_bottom':list(rows),'hex_top_to_bottom':[f'${int(r,2):02X}' for r in rows], 'physical_dimensions_colour_clocks_scanlines':[32,48], 'source_pixel_dimensions':[8,len(rows)], 'scanlines_per_source_row':48//len(rows)} for name,rows in MOTIFS.items()}
for s in scenes:del s['PF1_byte_values']
rootj={'status':'SOURCE_ONLY_DESIGN_DATA_NOT_STELLA','source':{'repo':'https://github.com/Odourman/the-skraun','PR':60,'frozen_head':'2af9855fbe8d3edbe6d01609d3e539547b744aef','ROM_SHA256':'3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647','bank3_file':'experiments/fullgame1_arrow_halo_20261125/bank3.asm','bank0_file':'experiments/fullgame1_arrow_halo_20261125/bank0.asm'},
      'view':{'native_grid':[160,192],'actual_visible_loop_lines':186,'visible_loop_x_initial':186,'visible_loop_x_final':1,'row_source_index':'WorldPFIndex[x]=floor(x/2); row_displayed at y=186-x','PF1_horizontal_order':'bit7 first x16..19, bit0 last x44..47','mirror_worlds':[1,3,5,7], 'repeat_worlds':[2,4,6,8],'world_data_length_bytes':96,'physical_motif_tile_common':[4,8], 'motif_logical_dimensions_regular':[8,6], 'spiral_logical_dimensions':[8,12], 'top_band_partial_clipping':'indices 94 and 95 not accessed by Visible loop X=186..1; first top tile cropped by 4 scanlines','table_index':'bottom (24B), blank (48B), top (24B) in reversed display order','color_register':'COLUPF','halo_rule':'whole PF gold, not independent colors'},
      'palette_proposals':COLORS,'gold':GOLD,'motifs':motif_export,'worlds':scenes,
      'u1_leg1_source_status':'untouched; pulled from preexisting frieze archive, no edits; use original source for pixel identity'}
(DATA/'04_WORLD_GRAPHICS.json').write_text(json.dumps(rootj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

# Exact memory-map values: original WorldRects 4x4 half-open bytes; new envelopes 4x4.
source_worldrects={}
m=re.search(r'(?m)^WorldRects:\s*\n((?:\s*dc\.b[^\n]*\n){8})', (ROOT/'09_GENERATOR'/'BANK0_PR60_EXACT_SOURCE.asm').read_text())
assert m
lines=m.group(1).strip().splitlines()
for i,line in enumerate(lines,1):
 raw=[int(v,16) for v in re.findall(r'\$([0-9A-Fa-f]{2})',line)];assert len(raw)==16
 source_worldrects[str(i)]=[raw[j:j+4] for j in range(0,16,4)]
colinfo={'status':'SOURCE_ONLY_MATHEMATICAL_CANDIDATES','warning':'4 AABB envelopes per stage, not pixel-perfect TIA collision. Portal transparent holes and mountain corner air are considered solid within their bounding rectangles; require human choice and ROM test.',
         'order':'top-left,top-right,bottom-left,bottom-right','coordinate_convention':'x_min-inclusive,x_max-exclusive,y_min-inclusive,y_max-exclusive; physical visible PF pixels 160x186',
         'existing_code':'bank0 InstallWorldMap loads 16 bytes into $C0..$CF, bank3 CandidateValid uses them with each player level half-width and half-height',
         'original_world_rectangles':source_worldrects,
         'recommendations':{str(s['stage']):{'world':s['world'],'candidate_boxes':s['raw_colliders_xyxy_exclusive'],'original_boxes':source_worldrects[str(s['stage'])],'source_only_l3_navigation':s['navigation_l3_source_only'],'note':'AABB covers visible nonzero PF1 silhouette; corner/portal internal voids remain solid due single rectangle per object.'} for s in scenes}}
(DATA/'05_COLLISION_RECOMMENDATIONS.json').write_text(json.dumps(colinfo,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
# Optional assembler table for the existing 16-byte rectangles at WorldRects in bank0, not applied.
coll_lines=['; GRAPHICS II SOURCE_ONLY collision proposal. DO NOT APPLY WITHOUT MAIN/ROM AUTHORIZATION.','WorldRects:']
for s in scenes:
 nums=[v for q in s['raw_colliders_xyxy_exclusive'] for v in q]
 coll_lines.append(f'; stage {s["stage"]} {s["world"]}: 4x half-open x0,x1,y0,y1')
 coll_lines.append('        dc.b '+','.join(f'${v:02X}' for v in nums))
(DATA/'05_COLLISION_CANDIDATE_BYTES_NOT_APPLIED.asm').write_text('\n'.join(coll_lines)+'\n',encoding='utf8')
# Existing mapping (do not replace) is recorded bit-exact and verified.
ptr=['$00','$00','$60','$C0','$20','$80','$E0','$40','$A0']
pth=['$FA','$FA','$FA','$FA','$FB','$FB','$FB','$FC','$FC']
assert ptr == [f'${(96*(i-1)%256):02X}' if i else '$00' for i in range(9)]
assert pth == [f'${(0xFA00+96*(i-1))//256:02X}' if i else '$FA' for i in range(9)]

# Round-trip test: parse new DASM dc.b values and reconstruct the 8 maps in same order, SHA byte-level.
text=(OUT/'03_PLAYFIELD_DATA.asm').read_text()
reparsed=[int(v,16) for v in re.findall(r'\$([0-9A-Fa-f]{2})',text.split('PlayPF1:',1)[1]) if True]
# Comments may have hexadecimal-looking marker; parser scope uses dc.b lines only.
reparsed=[]
for line in text.splitlines():
 if 'dc.b' in line and not line.strip().startswith(';'):
  reparsed.extend(int(v,16) for v in re.findall(r'\$([0-9A-Fa-f]{2})',line))
assert len(reparsed)==768
assert reparsed==sum(([int(v[1:],16) for v in s['PF1_hex_top_order']] for s in scenes),[])
oldvec=b''.join(bytes(x) for x in old)
newvec=bytes(reparsed)
assert len(oldvec)==len(newvec)==768
assert sum(a!=b for a,b in zip(oldvec,newvec))>0
bytehash=hashlib.sha256(newvec).hexdigest()
assert all(len(s['PF1_hex_top_order'])==96 for s in scenes)
assert all(int(h[1:],16) in range(256) for s in scenes for h in s['PF1_hex_top_order'])
assert len(set(tuple(s['PF1_hex_top_order']) for s in scenes))==8

# Exact data-byte visual oracle, no read from render source after JSON write: reconstruct all and check.
again=json.loads((DATA/'04_WORLD_GRAPHICS.json').read_text())
for j,s in enumerate(again['worlds']):
 arr=[int(x[1:],16) for x in s['PF1_hex_top_order']]
 assert arr==reparsed[j*96:(j+1)*96]
 assert s['ctrplf_mode']==('mirror' if j%2==0 else 'repeat')
 assert connected_l3(s['raw_colliders_xyxy_exclusive'])['fully_connected']

# A readable report and integration handoff; metrics grounded in actual source-only checks.
summary={'stage_count':8,'motif_count':16,'new_table_size_bytes':len(newvec),'old_table_sha256':hashlib.sha256(oldvec).hexdigest(),'new_table_sha256':bytehash,'changed_byte_count':sum(a!=b for a,b in zip(oldvec,newvec)),'all_maps_distinct':True,'all_l3_reachable_from_center':True,'min_legal_l3_centers':min(s['navigation_l3_source_only']['legal_l3_centers'] for s in scenes),'min_central_open_vertical_l3_band':'Y 63..118 tested valid at X80 in all eight AABB models'}
(DATA/'SELF_CHECK_SOURCE_ONLY.json').write_text(json.dumps(summary,indent=2)+'\n')

(OUT/'00_START_HAR.md').write_text(f'''# THE SKRAUN — FINAL WORLD GRAPHICS — GRAPHICS II → MAIN V

**2026-11-25 | SOURCE_ONLY | Uppdragsgräns: ENDAST grafik och förslag till kollision.**

Hela leveransen bygger på godkänd bildreferens i `11_APPROVED_VISUAL_REFERENCE/` och exakt PF1-källstruktur i PR #60. De 16 individuella motiven är 14 enkla 8×6-masker och 2 tydligare 8×12-spiraler, utlagda som 32 färgklockor × 48 rasterlinjer (PF1-bitar 4 färgklockor breda; 8 respektive 4 rasterrader per källrad). Varje bana har överst ett eget motiv och nederst ett annat. Horisontell spegling gäller 1/3/5/7, upprepning 2/4/6/8.

- **Rapport:** `01_GRAPHICS_REPORT.md`.
- **Kort integrationshandoff:** `02_HANDOFF_TO_ROM_DEVELOPMENT.md`.
- **Komplett DASM-tabell:** `03_PLAYFIELD_DATA.asm` (8×96 = **768B**, samma storlek som PR60).
- **Maskspecifikationer:** `03_04_05_DATA/04_WORLD_GRAPHICS.json`.
- **Föreslagna kollisionsrektanglar:** `03_04_05_DATA/05_COLLISION_RECOMMENDATIONS.json`.
- **Alla åtta banor:** `06_PREVIEWS/ALL_EIGHT_ARENAS_PF_SOURCE_ONLY.png`.
- **Guldfärg under halo:** `06_PREVIEWS/ALL_EIGHT_GOLD_PF_SOURCE_ONLY.png`.
- **Med oförändrade figurkällor som storleksreferens:** `06_PREVIEWS/ALL_EIGHT_WITH_ACTORS_SIZE_REFERENCE_SOURCE_ONLY.png`.
- **Original-vs-nytt per bana:** `08_BEFORE_AFTER/`.
- **Reproduktion:** `09_GENERATOR/build_worlds.py`.

**Kontrollerat:** {len(newvec)} byte source data, 8 skilda masker, 16 unika motiv, alla 8 Level3-modeller förenade och spawn (80,88) fri. Ny PF1-tabell SHA256: `{bytehash}`. ***Inga nya ROM- eller Stella-prov har utförts på nya grafiken.***

Originalkällor ändras inte. Ingen main-merge. Behåll projektets befintliga spel- och animationskrav.
''',encoding='utf8')

(OUT/'01_GRAPHICS_REPORT.md').write_text(f'''# GRAPHICS II — FINAL WORLD GRAPHICS | MAIN V | 2026-11-25

## Resultat
**Åtta PF1-världar (8×96 bytes), 16 skilda maskmotiv (14 × 8×6 och 2 × 8×12 spiraler), direkt DASM-ready. SOURCE_ONLY.** Designen följer användarens godkända referensbild, förverkligad inom existerande rasterkärna. Totalt ändrade **{summary['changed_byte_count']} av 768 PF1-databyte** gentemot fryst PR60. Baslinjens 768B SHA256 `{summary['old_table_sha256']}`, ny tabell `{summary['new_table_sha256']}`.

### Käll- och bevisnivå
- PR60 HEAD `2af9855fbe8d3edbe6d01609d3e539547b744aef`; officiellt SHA för befintlig 16KiB-ROM `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647`.
- Lästa Project Sources 00–04, GitHub docs `DESIGN_DECISIONS_01-60_2026-11-16.md`, `SKRAUN_VISUAL_DIRECTION_2026-11-16.md`, PR60 och faktisk PR60 bank0/bank2/bank3 ASM från original-ROM-leverans i Drive. Ursprunglig godkänd bild oförändrad.
- Baslinjefoton i `08_BEFORE_AFTER/*PR60_ACTUAL_STELLA*` kommer ur PR60:s verkliga Stella-delivery ZIP. Alla nya förhandsvisningar är **SOURCE_ONLY**, aldrig kallade Stella.

## Utformning
| Bana | Värld | Överst | Nederst | Horisontell metod |
|---|---|---|---|---|
'''+''.join(f'| {s["stage"]} | {s["world"]} | {s["top_motif"]} | {s["bottom_motif"]} | {s["ctrplf_mode"]} |\n' for s in scenes)+f'''
## Faktiskt original-TIA-dataformat
- **8 bitars PF1** används för miljön; en bit tar 4 av 160 fysiska färgklockor, PF1 ligger på vänster sida i x16..47. Höger kopia är speglad eller upprepad genom befintliga CTRLPF-kodvägar (inga extra skrivningar).
- 14 motiv har **8×6** källbitar och 8 rasterrader per källrad. Spiral A/B har **8×12** källbitar och 4 rasterrader per källrad för mer läsbar fyrkantig spiral; båda utgör likväl exakt 24 PF1-byte och totalt 48 rasterrader var. Mittens 48-byte nollor innebär 96 fysiska tomma rasterlinjer i basdata.
- Tabellen lagras **nedre motiv 24 bytes i omvänd radordning, sedan 48 bytes nollor, översta motiv 24 bytes i omvänd radordning**. Den synliga kärnan kör X=186..1 och läser `WorldPFIndex[x]`, så 2 högsta tabellbyte per bana index94..95 visas inte. Det övre motivets första 8-radersband visas därför bara 4 rasterrader; resten behålls. Inga spegelvända träd eller vertikalt inverterade berg.
- Existerande pekartabell i bank0 `WorldPFLo/Hi` behålls oförändrad. 96 bytes per bana vid $FA00,$FA60,$FAC0,$FB20,$FB80,$FBE0,$FC40,$FCA0. Upptar $FA00..$FCFF, slutar vid $FD00.
- Ingen ändring i Visible/VisibleArrow, WorldPFIndex, CTRLPF, registerfärger eller RAM. Därmed **ingen ny synlig TIA-registreringskostnad från själva grafiken**, men byteinnehållets verkliga läsbarhet/halo/IRQ-fall kräver ROM/Stella.

## Färg
Behåll befintliga TIA-värden i bank2: skog `$C6/$C8`, berg `$36/$38`, dröm `$56/$58`, natt `$06/$08`; exakta skärmfärger varierar med TV och emulatorpalett. SOURCE_ONLY-RGB i JSON är bara illustrativa. Halon gör **hela PF guld** enligt testmodell B, inte individuella objektfärger. Spelets gamla ofullständiga 360-halo är en separat teknisk begränsning, inte löst av detta paket.

## Spelbarhet, kollisionssanning och risk
Fyra markerade miljöobjekt/bana är **inte** fyra godtyckliga spritekopior utan PF1:s två skärmkopior av respektive två olika motiv. Alla varianter behåller ett brett öppet mittfält och y-centrum. Samtliga 8 föreslagna 4×AABB-rektangeluppsättningar testades source-only med samma Level3 centrumgränser och HalfW=16/HalfH=18 som nuvarande `bank3.asm` och alla 8 var sammanhängande från center (80,88). Minsta antal lagliga Level3-centrum: {summary['min_legal_l3_centers']}.

**VARNING:** Aktuell PR60 WorldRects blockerar på delvis andra platser än nya PF1-silhuetterna. `05_COLLISION_RECOMMENDATIONS.json` innehåller separata nya 16-byte *kandidater* att granska. De har en rektangel per synlig silhuett (exakt AABB över dess icke-noll PF1-pixlar), alltså kan triangulära berg/spiralhål/portalvalv ha osynlig kollisionsyta inuti sin AABB. Detta är ett källmodellsavsteg, inte en spårad gameplaykollision. Ingen av rektanglarna har införts i ROM. Endast ROM DEVELOPMENT får pröva att ersätta WorldRects efter separat MAIN V-order. Värld 5/6:s portaler förblir **solida, inte teleporters**.

### Försiktighetsgränser
1. 76 CPU-cykler per fysisk rad och verkliga beamdeadlines är inte uppmätta för nya tabellen; den nya grafiken undviker extra registerskrivningar men detta är inte en generell renderer-GO.
2. L3-framkomlighet ovan gäller matematiska sammanhängande centerpositioner under kollisionsförslagen, inte verklig 8-riktnings-Stella-playtest, orb/tillväxt, svärd eller arrow.
3. P0 = fryst U1-LEG1. P1-kandidater/final aktörsuppsättning är orörda; tre fiender samtidigt och slutlig halo är fortfarande tekniska begränsningar.
4. Vissa motivs finform (spiral, portalöppning, bergkant) kan inte beskrivas pixel-perfekt med ett enda axis-aligned kollisionsrektangelobjekt. Inget ingrepp i kollisionsalgoritm auktoriserat.
5. Detta är implementerbar **dataleverans**, inte byggd/visad ROM. Integrationen och fysisk acceptans tillhör ROM DEVELOPMENT efter ny order.

**Rekommendation:** godkänn denna sammanhållna, stilrena, hårdvarunära PF1-kandidat som nästa grafikunderlag, granska kollisionernas hörn/portalhål vid verklig körning och bevara de 8 unika banorna. STOP GRAPHICS II efter leverans.
''',encoding='utf8')
(OUT/'02_HANDOFF_TO_ROM_DEVELOPMENT.md').write_text(f'''# MAIN V → ROM DEVELOPMENT: kort SOURCE_ONLY handoff (INTE implementationstillstånd)

**BASLINJE:** PR60, `2af9855fbe8d3edbe6d01609d3e539547b744aef`, standard F6 16KiB NTSC, ROM-SHA `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647`. Detta paket på separat GRAPHICS-gren.

**När MAIN separat beordrar integration:**
1. I `experiments/fullgame1_arrow_halo_20261125/bank3.asm`: byt den **enda** befintliga `PlayPF1:`-tabellen mellan `ORG $FA00` och `ORG $FD00` mot texten i `03_PLAYFIELD_DATA.asm`. Ändra inte $FD00, WorldPFIndex, WorldPFPtr, Visible, VisibleArrow eller HaloRowPtr.
2. **Behåll** bank0 `WorldPFLo/Hi` oförändrade, och bank2:s `SetWorldColors`/`CTRLPF` och palett. Stadier 1,3,5,7 är `mirror` och 2,4,6,8 `repeat` i originalet.
3. I bank0 `WorldRects:` finns 8×16 bytes för de fyra solida föremålen. **Om MAIN godkänner** kandidaterna: uppdatera endast dessa 128 data-byte med `03_04_05_DATA/05_COLLISION_CANDIDATE_BYTES_NOT_APPLIED.asm`, utan att ändra `CandidateValid`. Avvikelsen mellan synlig spiral/portalöppning och AABB är **avsiktligt synlig risk**; begär designbeslut om solid yta innan patch.
4. Källkontroll: 96 byte per värld = 768 byte; ny PF1-dataström SHA256 `{bytehash}`. Enbart source-data, ingen ny ROM med denna hash påstås finnas.
5. Efter separat auktorisation: bygg verklig F6 i DASM, kontrollera bank3 ryms oförändrat, 262 NTSC-rader, beamdeadlines, 128B RAM+stack, riktig Stella pixelordning och verklig input/navigerbarhet L3 samt orb-/växthörn. Kör sedan 8 världar och både inaktiv och aktiv guld-PF. Rapportera bara verkliga PASS.

**VIKTIGT:** inga sprites, ranger, attack eller halologik i detta grafikuppdrag ändrade. Ingen ny ROM, ingen merge, ingen Verification.
''',encoding='utf8')
(OUT/'10_SOURCE_REGISTER.md').write_text('''# Källregister

- Användaren 2026-11-25: bifogad `The_Skraun_godkand_grafikreferens(1).png`, kopierad oförändrad under `11_APPROVED_VISUAL_REFERENCE/` (visuell designauktoritet).
- User-supplied arbetsorder: `THE SKRAUN – GRAPHICS II FINAL WORLD GRAPHICS – ALL EIGHT ARENAS`, 2026-11-25. Ursprung finns i användarens inklistrade text.
- Project Sources 00–04 daterade 2026-11-21: navigation, inte permanent live implementation.
- GitHub live PR60 https://github.com/Odourman/the-skraun/pull/60, HEAD `2af9855fbe8d3edbe6d01609d3e539547b744aef` (check at receipt), ROM SHA `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647`.
- Faktiska ASM: `experiments/fullgame1_arrow_halo_20261125/{bank0,bank2,bank3}.asm`, hämtade ur exakt leveranspaket Google Drive `1yhOprGF-PsQ7kPLPNw7bgV_mX3jOb3gn` och matchade live PR60-grenens källinnehåll/relevanta symboler.
- Baseline Stella PNG: `fresh/play_final/visit_01_stage1.png` … `visit_08_stage8.png` från PR60:s utvecklarpaket (verkligt captured, utgör inte nytt test).
- Spelets grafiska beslut: https://github.com/Odourman/the-skraun/blob/main/docs/DESIGN_DECISIONS_01-60_2026-11-16.md ; https://github.com/Odourman/the-skraun/blob/main/docs/SKRAUN_VISUAL_DIRECTION_2026-11-16.md
- Exact frozen player bitmap: https://github.com/Odourman/the-skraun/blob/graphics/u1-leg1-caprine-gait-20261116/graphics/u1_leg1/SOURCE_U1_LEG1.json (kopierad endast för storleksexempel, *inte* ändrad).
- Förhandsvisningar, masktabeller, AABB och navigatorcheckar: ny `SOURCE_ONLY` från deterministiskt genereringsskript. Inte oberoende verifiering och inte ROM.
''',encoding='utf8')

# Reproduction complete; check SOURCE_ONLY arrays and outputs exactly against SHA256SUMS, excluding mutable report/manifests.
print('REBUILT 8 worlds from same PF1 bits:', bytehash)
