Reproduktion inom detta paket:

1. Kör `python3 09_GENERATOR/rebuild.py` från leveransmappens rot.
2. Kräver Pillow; inga externa nätanrop.
3. `rebuild.py` startar den exakta källgeneratorn med frysta bank0/bank3 och U1-referensen. Den jämför SHA256SUMS för determinism.
4. PREVIEW-filer är SOURCE_ONLY och ska inte räknas som Stella-rendering.
