# THE SKRAUN — GRAPHICS II / MAIN IV / Forest and Knight art candidates

**2026-11-22 | SOURCE_ONLY / DESIGN_CANDIDATES / NOT APPROVED / NOT STELLA**

This isolated directory is one authorized graphics-design delivery. It does not modify the
frozen U1-LEG1 master sprite, ROM, TIA kernel, gameplay logic, levels, or other worlds.

## Visual assets
- `images/SKOG_TRE_KANDIDATER.png` — side-by-side woods A/B/C, 2x nearest-neighbour.
- `images/A_Glanta_poster.png`, etc. — 3x review posters, with source-only composite actors.
- `images/<forest>_PF_NATIVE_160x176.png` — exact logical PF art, 160cc x176 lines, no actors.
- `images/<forest>_COMPOSITE_NATIVE_160x176.png` — intentionally unimplemented composite: U1-LEG1 P0, two P1 knight instances, ranger proxy from v0.3 plus orb; NOT runnable physical proof.
- `images/RIDDARE_TRE_KANDIDATER.png` — 3x3 8-bit P1 poses, enlarged + native.
- `images/K*_POSES.png` — three separate pose review boards with 1x logical sprite and 16x grid view.
- `images/K*_*_NATIVE_8x16.png` — byte-exact source sprites, NOT Stella screenshots.

## Exact source, provenance
- `data/knight_masks.json` — K1/K2/K3 A neutral/raised warning/strike pixel rows, top-first bit7 left.
- `data/KNIGHTS_P1_SOURCE_ONLY.inc` — strictly source-only assembler data; ROW ORDER MUST BE CHECKED against a future rendering kernel.
- `data/forest_pf.json` — 20-bit left-hand row masks mirrored to 40 PF cells, 22 vertical bands of eight actual scanlines, exact PF0/PF1/PF2 values.
- `data/palette_proposals.json` — preliminary TIA byte candidates with illustrative RGB only.
- `data/U1_LEG1_FROZEN_REFERENCE_UNMODIFIED.json` — **byte-identical public reference snapshot, not an edited art source**. SHA-256 `3762285335f5c7deb8b89812472c6d4f881fa04efb4f241db44ecf6530f6ba49`; source-of-truth remains the existing frozen graphics branch `graphics/u1-leg1-caprine-gait-20261116/graphics/u1_leg1/SOURCE_U1_LEG1.json`.
- `generate.py` — Pillow renderer, no Stella, no ROM, no cycle simulation, reproducible from JSON sources.

## Representation, hard limits
- Atari TIA playfield: PF0 4 bits + PF1 8 bits + PF2 8 bits on each 80cc half; 1 PF cell = 4 color clocks. The source uses `CTRLPF.D0=1` mirrored right half. A candidate spans 22x8 = 176 lines, not 22 physical scanlines. Each row has three precomputed PF register bytes. Unmerged source art is not a claim of safe write deadlines or available cycles during a visible gameplay kernel.
- The 8x16 P1 sprite colour is unified; sample light-blue `COLUP1=$9E`, *not a validated NTSC colour approval*. P1 holds one 8-bit pattern at a time; alternating knight/ranger/same-Y multiplexing is NOT solved by this artwork. M1 shares P1 colour, and using it as a separate sword is **not** authorized.
- Forest source uses `COLUBK` dark green / `COLUPF` muted green (illustrative RGB); actual register-byte palette needs ROM DEVELOPMENT's real Stella palette test. Test B globally switches all playfield to gold under halo, including trees: the environmental masks remain the same. A green PF cannot stay independently green during gold with one COLUPF.
- Each visual crown tile is mirrored on screen; visible rounded branches are coarse 4cc x8-line PF cells (no 1cc texture or unproven extra object). Trees/branches are **visual masks only**; collisions/hitbox are separate and no arena gameplay geometry is adopted. A later developer must provide an explicitly authorized safe arena and gap/growth proof before treating any shape as solid.
- P1 sword is **inside the same 8-bit player mask**. Its blade reach relative to the moving knight depends on pose and facing; attack hitbox/timing stays independent. The 0.4s warning and brief strike/1s recovery from design canon remain unchanged. The sprite cannot communicate different metal colours unless a new per-scanline colour schedule is proven physically, which this art DOES NOT assume.

## Verdict & release fence
Recommended **forest A** (open tree crowns with maximum central space) + **knight K1** (visor with distinct blade-raise pose). K2 is runner-up for recognisable winged helmet; K3 is deliberately heavier but less legible as distinct blade in 8-bit width. These are design recommendations only; user/MAIN IV approval is separate.

No ROM, no GitHub main merge, no implementation order, no N8/N9, no other-world art and no independent verification is created through this delivery.
