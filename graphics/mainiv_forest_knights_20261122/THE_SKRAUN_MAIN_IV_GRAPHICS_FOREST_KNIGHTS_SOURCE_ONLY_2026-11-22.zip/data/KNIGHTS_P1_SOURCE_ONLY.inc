; GRAPHICS II / MAIN IV / 2026-11-22
; SOURCE_ONLY P1 art bytes, top-first notation.
; ROM code may need bottom-first or reverse row sequencing: explicitly verify.
; No P1 scheduling, colour/timing, missile or TIA renderer implementation here.

K1_VISIR_NEUTRAL:
    dc.b $38 ; y=00 %00111000
    dc.b $7C ; y=01 %01111100
    dc.b $68 ; y=02 %01101000
    dc.b $7C ; y=03 %01111100
    dc.b $38 ; y=04 %00111000
    dc.b $7C ; y=05 %01111100
    dc.b $FC ; y=06 %11111100
    dc.b $BA ; y=07 %10111010
    dc.b $7D ; y=08 %01111101
    dc.b $39 ; y=09 %00111001
    dc.b $39 ; y=10 %00111001
    dc.b $39 ; y=11 %00111001
    dc.b $28 ; y=12 %00101000
    dc.b $28 ; y=13 %00101000
    dc.b $6C ; y=14 %01101100
    dc.b $C6 ; y=15 %11000110

K1_VISIR_WARNING:
    dc.b $39 ; y=00 %00111001
    dc.b $7D ; y=01 %01111101
    dc.b $69 ; y=02 %01101001
    dc.b $7D ; y=03 %01111101
    dc.b $39 ; y=04 %00111001
    dc.b $7D ; y=05 %01111101
    dc.b $FD ; y=06 %11111101
    dc.b $BB ; y=07 %10111011
    dc.b $7D ; y=08 %01111101
    dc.b $38 ; y=09 %00111000
    dc.b $38 ; y=10 %00111000
    dc.b $38 ; y=11 %00111000
    dc.b $28 ; y=12 %00101000
    dc.b $28 ; y=13 %00101000
    dc.b $6C ; y=14 %01101100
    dc.b $C6 ; y=15 %11000110

K1_VISIR_STRIKE:
    dc.b $38 ; y=00 %00111000
    dc.b $7C ; y=01 %01111100
    dc.b $68 ; y=02 %01101000
    dc.b $7C ; y=03 %01111100
    dc.b $38 ; y=04 %00111000
    dc.b $7C ; y=05 %01111100
    dc.b $FC ; y=06 %11111100
    dc.b $BF ; y=07 %10111111
    dc.b $7F ; y=08 %01111111
    dc.b $38 ; y=09 %00111000
    dc.b $38 ; y=10 %00111000
    dc.b $38 ; y=11 %00111000
    dc.b $28 ; y=12 %00101000
    dc.b $28 ; y=13 %00101000
    dc.b $6C ; y=14 %01101100
    dc.b $C6 ; y=15 %11000110

K2_VINGHJALM_NEUTRAL:
    dc.b $24 ; y=00 %00100100
    dc.b $7E ; y=01 %01111110
    dc.b $42 ; y=02 %01000010
    dc.b $66 ; y=03 %01100110
    dc.b $3C ; y=04 %00111100
    dc.b $3C ; y=05 %00111100
    dc.b $FF ; y=06 %11111111
    dc.b $DB ; y=07 %11011011
    dc.b $DB ; y=08 %11011011
    dc.b $7E ; y=09 %01111110
    dc.b $7E ; y=10 %01111110
    dc.b $BC ; y=11 %10111100
    dc.b $98 ; y=12 %10011000
    dc.b $98 ; y=13 %10011000
    dc.b $66 ; y=14 %01100110
    dc.b $C3 ; y=15 %11000011

K2_VINGHJALM_WARNING:
    dc.b $A4 ; y=00 %10100100
    dc.b $FE ; y=01 %11111110
    dc.b $C2 ; y=02 %11000010
    dc.b $E6 ; y=03 %11100110
    dc.b $BC ; y=04 %10111100
    dc.b $BC ; y=05 %10111100
    dc.b $FF ; y=06 %11111111
    dc.b $DB ; y=07 %11011011
    dc.b $DB ; y=08 %11011011
    dc.b $7E ; y=09 %01111110
    dc.b $7E ; y=10 %01111110
    dc.b $3C ; y=11 %00111100
    dc.b $30 ; y=12 %00110000
    dc.b $30 ; y=13 %00110000
    dc.b $66 ; y=14 %01100110
    dc.b $C3 ; y=15 %11000011

K2_VINGHJALM_STRIKE:
    dc.b $24 ; y=00 %00100100
    dc.b $7E ; y=01 %01111110
    dc.b $42 ; y=02 %01000010
    dc.b $66 ; y=03 %01100110
    dc.b $3C ; y=04 %00111100
    dc.b $3C ; y=05 %00111100
    dc.b $FF ; y=06 %11111111
    dc.b $FF ; y=07 %11111111
    dc.b $F7 ; y=08 %11110111
    dc.b $EF ; y=09 %11101111
    dc.b $DF ; y=10 %11011111
    dc.b $3C ; y=11 %00111100
    dc.b $30 ; y=12 %00110000
    dc.b $30 ; y=13 %00110000
    dc.b $66 ; y=14 %01100110
    dc.b $C3 ; y=15 %11000011

K3_TUNG_RUSTNING_NEUTRAL:
    dc.b $3C ; y=00 %00111100
    dc.b $7E ; y=01 %01111110
    dc.b $DB ; y=02 %11011011
    dc.b $E7 ; y=03 %11100111
    dc.b $DB ; y=04 %11011011
    dc.b $7E ; y=05 %01111110
    dc.b $FF ; y=06 %11111111
    dc.b $E7 ; y=07 %11100111
    dc.b $E7 ; y=08 %11100111
    dc.b $7E ; y=09 %01111110
    dc.b $7E ; y=10 %01111110
    dc.b $67 ; y=11 %01100111
    dc.b $67 ; y=12 %01100111
    dc.b $67 ; y=13 %01100111
    dc.b $C3 ; y=14 %11000011
    dc.b $C3 ; y=15 %11000011

K3_TUNG_RUSTNING_WARNING:
    dc.b $3D ; y=00 %00111101
    dc.b $7E ; y=01 %01111110
    dc.b $DB ; y=02 %11011011
    dc.b $E7 ; y=03 %11100111
    dc.b $DB ; y=04 %11011011
    dc.b $7E ; y=05 %01111110
    dc.b $FF ; y=06 %11111111
    dc.b $E7 ; y=07 %11100111
    dc.b $E7 ; y=08 %11100111
    dc.b $7E ; y=09 %01111110
    dc.b $7E ; y=10 %01111110
    dc.b $66 ; y=11 %01100110
    dc.b $66 ; y=12 %01100110
    dc.b $66 ; y=13 %01100110
    dc.b $C3 ; y=14 %11000011
    dc.b $C3 ; y=15 %11000011

K3_TUNG_RUSTNING_STRIKE:
    dc.b $3C ; y=00 %00111100
    dc.b $7E ; y=01 %01111110
    dc.b $DB ; y=02 %11011011
    dc.b $E7 ; y=03 %11100111
    dc.b $DB ; y=04 %11011011
    dc.b $7E ; y=05 %01111110
    dc.b $FF ; y=06 %11111111
    dc.b $FF ; y=07 %11111111
    dc.b $FF ; y=08 %11111111
    dc.b $7F ; y=09 %01111111
    dc.b $3F ; y=10 %00111111
    dc.b $66 ; y=11 %01100110
    dc.b $66 ; y=12 %01100110
    dc.b $66 ; y=13 %01100110
    dc.b $C3 ; y=14 %11000011
    dc.b $C3 ; y=15 %11000011

