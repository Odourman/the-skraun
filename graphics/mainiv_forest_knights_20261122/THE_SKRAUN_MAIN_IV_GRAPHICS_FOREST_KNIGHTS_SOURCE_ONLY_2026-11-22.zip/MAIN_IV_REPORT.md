# GRAPHICS II → MAIN IV — skogsglänta och riddar-P1 (2026-11-22)

**Verdikt:** SOURCE_ONLY. Tre skogsmasker, tre åttabitars riddarfamiljer och tre poser per familj. Ingen design är ännu användar-/MAIN-godkänd. Inga riktiga Stella-bilder, ROM-test eller tidsmätningar har utförts.

## Kontrollerade projektkällor
- MAIN IV GAMEPLAY-1 draft PR #41 head `7f289a536c375bf760428274280179cfe15a6a62`, F8 8KiB experimental, **delvis spelbart**, en P1-proxy åt gången, 2 provisoriska PF-kartor, ljusblå P1 `COLUP1=$9E`, testvärlds-PF och logisk svärdsvarning utan upplyft sprite.
- Designbeslut 01–60, senare L3 fri manövrering; visuell riktning, U1-LEG1 exakt källa på fryst grafikgren; tidigare GRAPHICS v0.3 `ENEMIES_V03.json`, `WORLDS_V03.json` (oreviderade designreferenser).
- Original skiss/fotografi: används inte, publiceras inte.

## A / skogsmiljö
Alla tre består av 20 bitar vänster PF-halva, **speglade** i höger halvbild, 22 band á 8 scanlines = 176 lines. En pixelcell = 4 TIA colour clocks bred, alltså ingen felaktig 1-clock träddetalj. Källmaskerna finns i JSON. Varje trädkronepixel och stam är samma PF-färg; ingen per-objekt tvåfärgsträd-rastertrick antas.
- **A Gläntan:** rund/kantig skogskrona upptill, ojämn nedtill och buske på ytterkanten. Öppen mitt och tydliga två-trädgrupper. **Rekommenderas.**
- **B Dungar:** en högre ojämn gruppering + träd nära den övre delen och mindre stubbar. Något tätare.
- **C Skogskant:** större variation längs vänster/höger skogskant, centralt öppet, 4 återanvändbara tiles.

Hela de synliga PF-maskerna ger en källgeometrisk mittöppning, men det är **inte** verifierade kollisionspassager. Använd inte den visuella kronans bounding box som direkt gameplay-hitbox utan egen design-/implementationsacceptans. Små löv/gräs på marken föreslås endast som valfri framtida dekor: de är inte ritade in, eftersom TIA inte har ett gratis separat dekorationslager. Ny världsfärg och guldhalo konkurrerar om samma COLUPF.

## B / riddare
- **K1 Visir & svärd (rekommenderas):** tydlig mörk visirspalt, skarpa axlar, separat benpar; högervinklad hållning i neutral och en tydlig 1-bit upphöjd klinga i warning. Slagruta har diagonal, integrerad klingform inom samma 8-bit P1.
- **K2 Vinghjälm:** tydliga hjälmspetsar, svärd på vänster sida; mer sagoriddare men risk för horn-liknande silhuett som liknar Skraun.
- **K3 Tung rustning:** bred plåtrustning/hjälm; närmast en robust tank, men svärdet kan se ut som en axelklump i rörelse.

Varje pose 8x16, topp-först, 1 bit per 1 P1 clock. Byteexakta tabeller/hex i JSON och `.inc`. Om original ROM använder omvänd ordning / dubblerade källrader måste ROM DEVELOPMENT översätta utan att påstå drop-in bevis.

**Animation/strid:** neutral jakt → varning i cirka 0,4s (24 NTSC frames) → kort skadefönster med strike-mask → cirka 1s återhämtning, enligt canon. Spegling via REFP1 är möjligt i design, men riktning och sent GRP1-timing måste särskilt testas. `COLUP1=$9E` kandidat, färger på grafiska kort är illustrativa RGB och inte en emulatorpalett.

## Integrationskontrakt till ROM DEVELOPMENT III (framtida, EJ ORDER)
1. INPUT: en vald familj K1/2/3, 3x16-byte tabeller, ren 8x16 P1 (NUSIZ1 1x) och PF variant A/B/C: 22 tripletter PF0/1/2 i skanningsordning. Mirrored CTRLPF D0=1; inga ändrade Skraun 8x12-källbitar.
2. Granska bank1 `Visible` / befintliga `DummyScan` och `PlayPF1`/`HaloRowPtr` där PF2 skrivs på fysisk rasterrad. Nya PF0/PF1/PF2 bytepar får inte ersätta halo-PF2-grafik eller injiceras utan faktisk deadlineledger. Synk med guld-B/ON och spelar-/P1-pixlar måste provas som gemensam skärm.
3. Utbilda den faktiska korrekta row-order i ROM; jämför exakta 8 bitar / samtliga 16 rader med en verklig Stella-pixelorakel. Bevisa fysisk poseväxling inom 0,4s-varningen och kort strike-fönster, och korrekt weapon hitbox som **inte** skadar via kroppskontakt.
4. En P1 kan inte samtidigt visa två oberoende knights och ranger utan korrekt multiplexing; den här designen löser INTE den öppna fysiska N6-C/N7-grinden eller samma-Y 6507-budgeten. Svärd via M1 är bara framtida alternativ (delar P1-färg), inte en kravändring.
5. Koppla separat solida kollisionsformer till visuellt identifierbara trädkronor/stammar; level3 32x36 måste förbli fullt manövrerbar, utan tysta hitbox-krympningar. Verifiera båda skogsbanornas öppna vägar, orb- och growth-platser genom faktisk kommande gameplay-test, inte source-only bild.
6. Mät 262 NTSC scanlines, worst-case beam-write deadlines / 76c, riktig 6507-väg, stack/RAM 128B, reproducerbar assembler- och Stella-artefakt **inom separat auktoriserat ROM-uppdrag**. Ingen implementation görs här.

## Väsentliga begränsningar
Den planerade utvecklingsvägen kan behöva alternativa synliga PF-masktrick om hela halo/hinder/fiende-renderern inte har cykler kvar. Detta SOURCE_ONLY-paket tillför INTE nya TIA-objekt, men byter PF-maskvärden och kan ändra antal registeruppdateringar/ROM-tabellbehov. Ingen automatisk timing neutralitet får utlovas. Prioritering: tydlig skog, igenkännbar hjälm och märkbart svärd i faktisk skala, utan att kompromissa med tre fiender, halo, nivå 3 eller speltempo.
