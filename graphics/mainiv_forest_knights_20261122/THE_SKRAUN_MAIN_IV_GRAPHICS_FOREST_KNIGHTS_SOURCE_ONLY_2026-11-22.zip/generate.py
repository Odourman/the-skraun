#!/usr/bin/env python3
"""THE SKRAUN / MAIN IV / GRAPHICS II. SOURCE_ONLY pixel previews. NO ROM or Stella.
All 160x176 art maps are exact unfiltered logical-coordinate illustrations:
- PF shapes: each displayed cell = 4 horizontal TIA colour clocks, band = 8 scanlines
- P1 candidate masks: 8 bits wide, one bit = 1 colour clock, 16 scanlines tall
- Skraun U1-LEG1: read-only snapshot loaded byte-for-byte, unchanged.
Run: python3 generate.py  (requires pillow)
"""
import json,hashlib,os,zipfile,math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; IMG=ROOT/'images'
DATA.mkdir(exist_ok=True); IMG.mkdir(exist_ok=True)
SW,SH=160,176
FOREST_BG=(18,39,30); PF_COLOR=(102,148,77); GRAY=(210,210,209); CYAN=(132,210,247)
RANGER=(99,174,91); GOLD=(238,191,69); TEXT=(235,239,227); BLACK=(11,20,18)
FNT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def ft(n=16,bold=False):return ImageFont.truetype(BOLD if bold else FNT,n)
def sha(b):return hashlib.sha256(b).hexdigest()

# Previous GRAPHICS v0.3 P1 candidates used only as historical design references;
# new mask rows are original, bounded 8x16 bitmaps prepared in this task.
K={
 'K1_VISIR': {
  'title':'K1  /  Visir & svärd', 'note':'Smalt ansikte, tydlig klinga i yttre P1-kolumn',
  'neutral':['..###...','.#####..','.##.#...','.#####..','..###...','.#####..','######..','#.###.#.','.#####.#','..###..#','..###..#','..###..#','..#.#...','..#.#...','.##.##..','##...##.'],
  'warning':['..###..#','.#####.#','.##.#..#','.#####.#','..###..#','.#####.#','######.#','#.###.##','.#####.#','..###...','..###...','..###...','..#.#...','..#.#...','.##.##..','##...##.'],
  'strike':['..###...','.#####..','.##.#...','.#####..','..###...','.#####..','######..','#.######','.#######','..###...','..###...','..###...','..#.#...','..#.#...','.##.##..','##...##.'],
 },
 'K2_VINGHJALM': {
  'title':'K2  /  Vinghjälm', 'note':'Utstående hjälmtoppar; vänsterburet blad',
  'neutral':['..#..#..','.######.','.#....#.','.##..##.','..####..','..####..','########','##.##.##','##.##.##','.######.','.######.','#.####..','#..##...','#..##...','.##..##.','##....##'],
  'warning':['#.#..#..','#######.','##....#.','###..##.','#.####..','#.####..','########','##.##.##','##.##.##','.######.','.######.','..####..','..##....','..##....','.##..##.','##....##'],
  'strike':['..#..#..','.######.','.#....#.','.##..##.','..####..','..####..','########','########','####.###','###.####','##.#####','..####..','..##....','..##....','.##..##.','##....##'],
 },
 'K3_TUNG_RUSTNING': {
  'title':'K3  /  Tung rustning', 'note':'Kraftiga axlar; bred silhuett men trängre svärd',
  'neutral':['..####..','.######.','##.##.##','###..###','##.##.##','.######.','########','###..###','###..###','.######.','.######.','.##..###','.##..###','.##..###','##....##','##....##'],
  'warning':['..####.#','.######.','##.##.##','###..###','##.##.##','.######.','########','###..###','###..###','.######.','.######.','.##..##.','.##..##.','.##..##.','##....##','##....##'],
  'strike':['..####..','.######.','##.##.##','###..###','##.##.##','.######.','########','########','########','.#######','..######','.##..##.','.##..##.','.##..##.','##....##','##....##']
 }
}
for key,k in K.items():
 for pose in ('neutral','warning','strike'):
  b=k[pose]
  assert len(b)==16 and all(len(s)==8 and set(s)<={'.','#'} for s in b),(key,pose)
  k[pose+'_bits']=[x.replace('#','1').replace('.','0') for x in b]
  k[pose+'_hex']=[f'${int(x,2):02X}' for x in k[pose+'_bits']]
  k[pose+'_pixel_count']=sum(x.count('#') for x in b)
 k['note_technical']='P1 / GRP1: 8 bits x 16 separate raster lines; one solid P1 colour, no extra objects.'
# Palettes are proposals only. TIA NTSC byte samples are candidates and need Stella proof.
PAL={
 'status':'SOURCE_ONLY; illustrative RGB, no emulator palette calibration',
 'shared':{'COLUP0_U1_LEG1_gray':{'tia_ntsc':'$0C','rgb_preview':GRAY},
           'COLUP1_knight_lightblue':{'tia_ntsc':'$9E','rgb_preview':CYAN},
           'COLUPF_halo_B_on_all_PF':{'tia_ntsc':'$2E','rgb_preview':GOLD}},
 'forest':{'COLUBK_background':{'tia_ntsc_candidate':'$C2','rgb_preview':FOREST_BG},
           'COLUPF_canopy_and_trunk':{'tia_ntsc_candidate':'$C8','rgb_preview':PF_COLOR}},
 'caution':'Exactly one COLUPF colour is used for PF and BL at a time; any separate multicolour canopy/trunk or decorative texture requires separate verified raster technique.'
}
(DATA/'palette_proposals.json').write_text(json.dumps(PAL,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

(DATA/'knight_masks.json').write_text(json.dumps({'status':'SOURCE_ONLY, UNAPPROVED, NO STELLA','width':8,'height':16,'top_first':True,'bit7_left':True,'candidates':K},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

# Resource-minded repeatable PF tiles; use mirror, no special right-half writes.
# Coordinates: 20 cells left half only (x0..19), 22 eight-scanline bands y0..21.
# xcell4 actual colour clocks / ycell8 actual scanlines.
TREES={
 'T1_round':['.###.','#####','#####','.###.','..#..','..#..'],
 'T2_uneven':['.###..','#####.','######','.####.','..##..','..##..'],
 'B1_bush':['.#.','###','.##'],
 'S1_stump':['##','##','.#']
}
SCENES={
 'A_Glanta':{'title':'A  /  Den öppna gläntan','detail':'2 stora kronpar, stubbar vid kanterna; maximal öppen mitt',
            'pieces':[('T1_round',3,3),('T2_uneven',3,14),('B1_bush',0,11)],'rgb_bg':(19,40,30),'rgb_pf':(94,143,76)},
 'B_Dungar':{'title':'B  /  Skogsdungar','detail':'Ojämn trädrad, mindre buskage, tydlig korridor',
            'pieces':[('T2_uneven',1,5),('T1_round',7,1),('S1_stump',3,16)],'rgb_bg':(23,39,31),'rgb_pf':(105,145,79)},
 'C_Skogskant':{'title':'C  /  Skogskanten','detail':'Träd längs sidokanterna, glesare centralt',
            'pieces':[('T1_round',5,3),('T2_uneven',0,13),('B1_bush',0,7),('S1_stump',8,17)],'rgb_bg':(17,36,32),'rgb_pf':(98,145,85)}
}

def mirrored_rows(pieces):
 half=[[0]*20 for _ in range(22)]
 for kind,x,y in pieces:
  for dy,row in enumerate(TREES[kind]):
   for dx,ch in enumerate(row):
    if ch=='#':
     if x+dx<20 and y+dy<22:half[y+dy][x+dx]=1
 full=[r+r[::-1] for r in half]
 return half,full

def regs(halfrow):
 bits=''.join(map(str,halfrow))
 pf0=sum(int(bits[j])<<(4+j) for j in range(4))
 pf1=sum(int(bits[j+4])<<(7-j) for j in range(8))
 pf2=sum(int(bits[j+12])<<j for j in range(8))
 return {'PF0':f'${pf0:02X}','PF1':f'${pf1:02X}','PF2':f'${pf2:02X}'}

forest={'status':'SOURCE_ONLY design candidates; no Stella, no collision map or renderer approval',
        'logical_width_cc':160,'height_scanlines':176,'left_half_cells':20,'total_pf_cells':40,'cell_width_cc':4,
        'row_band_scanlines':8,'ctr_pf_reflect_D0':1,'tiles':TREES,'variants':{}}
for name,desc in SCENES.items():
 half,full=mirrored_rows(desc['pieces'])
 assert all(r[:20]==r[20:][::-1] for r in full)
 assert all(len(r)==40 for r in full)
 descriptor={x:v for x,v in desc.items() if x!='pieces'}
 descriptor['pieces_left_half']=[{'tile':t,'x_cell_left':x,'y_band':y} for t,x,y in desc['pieces']]
 descriptor['half_rows_20']=[''.join(map(str,r)) for r in half]
 descriptor['mirrored_rows_40']=[''.join(map(str,r)) for r in full]
 descriptor['tia_registers_top_to_bottom']=[regs(r) for r in half]
 descriptor['distinct_row_triples']=len({tuple(q.values()) for q in descriptor['tia_registers_top_to_bottom']})
 # Geometric widest left-side PF reach / minimum mirrored centre opening; no hitbox assertion.
 descriptor['min_clear_central_width_cc']=min(160-8*(max([i for i,p in enumerate(row) if p] or [-1])+1) for row in half)
 forest['variants'][name]=descriptor
(DATA/'forest_pf.json').write_text(json.dumps(forest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

# Copy public frozen exact U1 source as read-only art input for reproducibility.
# If source filename available from shipped archive we VERIFY bytes.  In GitHub it is a
# separate historical branch; the authoritative file itself is NOT modified by task.
u1src=DATA/'U1_LEG1_FROZEN_REFERENCE_UNMODIFIED.json'
if not u1src.exists():
 z=ROOT.parent/'THE_SKRAUN_U1_LEG1_CAPRINE_GAIT_2026-11-16.zip'
 if z.exists():
  with zipfile.ZipFile(z) as zf:u1src.write_bytes(zf.read('SOURCE_U1_LEG1.json'))
 if not u1src.exists():raise RuntimeError('Missing frozen input U1_LEG1_FROZEN_REFERENCE_UNMODIFIED.json')
assert sha(u1src.read_bytes())=='3762285335f5c7deb8b89812472c6d4f881fa04efb4f241db44ecf6530f6ba49'
u1=json.loads(u1src.read_text())['one_candidate_U1_LEG1']
# Original/source RIGHT is stored, reflected/source LEFT is reversed. VISUAL RIGHT = source LEFT.
u1right=[s[::-1] for s in u1['A']];u1left=list(u1['A'])
assert all(len(x)==8 for x in u1right)

# Native logical assets use no unphysical colour overlays or sub-PF tree details.
def draw_pf(desc,show_sources=False):
 im=Image.new('RGB',(SW,SH),tuple(desc['rgb_bg']))
 d=ImageDraw.Draw(im)
 rows=desc['mirrored_rows_40']
 for y,r in enumerate(rows):
  for x,b in enumerate(r):
   if b=='1':d.rectangle((x*4,y*8,x*4+3,y*8+7), fill=tuple(desc['rgb_pf']))
 return im

def paint_pattern(img,rows,x,y,color,scale_x=1,scale_y=1):
 d=ImageDraw.Draw(img)
 for dy,r in enumerate(rows):
  for dx,c in enumerate(r):
   if c in ('1','#'):
    xx=x+dx*scale_x;yy=y+dy*scale_y
    d.rectangle([xx,yy,xx+scale_x-1,yy+scale_y-1],fill=color)

archer=['00111100','01100110','01100110','00111100','10011000','11011100','10111110','10011110','10011100','00011000','01100110','11000011']

def add_actors(img,scene_name,knight_name='K1_VISIR'):
 # Scenes are composited SOURCE ONLY with independent P0/P1 references:
 # two visible P1 knights + archer are IMPOSSIBLE TO CLAIM as a proved kernel.
 paint_pattern(img,u1right,76,87,GRAY)
 k=K[knight_name]
 paint_pattern(img,k['neutral_bits'],45,105,CYAN)
 paint_pattern(img,k['warning_bits'],117,92,CYAN)
 paint_pattern(img,archer,69,30,RANGER)
 d=ImageDraw.Draw(img)
 d.rectangle((96,56,97,57),fill=GOLD)

def save_native(img,name):img.save(IMG/name)
def enlarge(img,scale=4):return img.resize((img.width*scale,img.height*scale),Image.Resampling.NEAREST)

def poster_scene(name,desc,im):
 width,height=560,820
 p=Image.new('RGB',(width,height),(9,19,19));d=ImageDraw.Draw(p)
 d.text((29,20),desc['title'],font=ft(28,True),fill=TEXT)
 d.text((30,64),'SOURCE_ONLY  |  160x176 logiska TIA-koordinater',font=ft(14),fill=(167,199,184))
 # 160x176 x4 =640x704 too wide, x3 =480x528
 pic=enlarge(im,3);p.paste(pic,(40,109));d.rectangle((39,108,521,638),outline=(101,119,104),width=1)
 d.text((30,665),desc['detail'],font=ft(15),fill=TEXT)
 d.text((30,694),'PF: 4 färgklockor/cell  ·  8 scanlines/band',font=ft(15),fill=(166,190,176))
 d.text((30,726),'Gul orb/P0/P1 i scener = konceptlager',font=ft(14),fill=(176,185,179))
 d.text((30,749),'INTE en Stella-rendering / ej testad kernel',font=ft(14,True),fill=(235,181,107))
 p.save(IMG/f'{name}_poster.png')

for name,desc in SCENES.items():
 raw=draw_pf(forest['variants'][name]);save_native(raw,f'{name}_PF_NATIVE_160x176.png')
 stage=raw.copy();add_actors(stage,name)
 save_native(stage,f'{name}_COMPOSITE_NATIVE_160x176.png')
 poster_scene(name,desc,stage)

# Draw short 8x16 source P1 native scale next to enlarged 20x enlargement.
def native_knight_canvas(rows):
 im=Image.new('RGB',(8,16),FOREST_BG)
 paint_pattern(im,rows,0,0,CYAN)
 return im
for name,k in K.items():
 poster=Image.new('RGB',(980,465),(14,27,29));d=ImageDraw.Draw(poster)
 d.text((28,17),k['title'],font=ft(29,True),fill=TEXT)
 d.text((28,60),k['note'],font=ft(16),fill=(176,208,207))
 for i,pose in enumerate(('neutral','warning','strike')):
  x=25+i*310
  d.text((x,105),{'neutral':'1  NEUTRAL','warning':'2  FÖRVARNING','strike':'3  HUGG'}[pose],font=ft(18,True),fill=(230,237,224))
  im=native_knight_canvas(k[pose+'_bits'])
  im.save(IMG/f'{name}_{pose}_NATIVE_8x16.png')
  # enlarged block 16x = 128x256; grid for source pixels
  poster.paste(enlarge(im,16),(x+33,150))
  for gy in range(17):d.line((x+33,150+16*gy,x+33+128,150+16*gy),fill=(45,69,66),width=1)
  for gx in range(9):d.line((x+33+16*gx,150,x+33+16*gx,150+256),fill=(45,69,66),width=1)
  poster.paste(enlarge(im,2),(x+187,159))
  d.text((x+172,200),'8 x 16',font=ft(15,True),fill=(175,198,195))
  d.text((x+173,229),'1x P1',font=ft(14),fill=(175,198,195))
 d.text((29,435),'KÄLLPIXEL 16x FÖRSTORAD  |  8-BIT P1  |  EJ STELLA',font=ft(15,True),fill=(237,180,111))
 poster.save(IMG/f'{name}_POSES.png')

# comparisons and forest contact sheet
sheet=Image.new('RGB',(1170,720),(12,21,23));dr=ImageDraw.Draw(sheet)
dr.text((26,15),'THE SKRAUN  /  SKOG  ·  TRE PF-KANDIDATER',font=ft(28,True),fill=TEXT)
dr.text((27,58),'ÄKTA 160x176-koordinater i SOURCE_ONLY-förhandsvisning, 2x närmaste granne',font=ft(17),fill=(164,189,183))
for i,(name,desc) in enumerate(SCENES.items()):
 x=25+385*i
 frame=draw_pf(forest['variants'][name]);add_actors(frame,name)
 sheet.paste(enlarge(frame,2),(x,113))
 dr.text((x,482),name.replace('_',' / '),font=ft(19,True),fill=(224,235,228))
 dr.text((x,518),f"Min mittöppning PF: {forest['variants'][name]['min_clear_central_width_cc']} cc",font=ft(15),fill=(170,206,174))
 dr.text((x,555),f"{forest['variants'][name]['distinct_row_triples']} olika registertripletter",font=ft(14),fill=(173,184,180))
dr.text((25,648),'KONCEPTLAGER: Skraun U1-LEG1 oförändrad · 2 riddare + ranger (ej samtidigt bevisbara)',font=ft(17),fill=(239,199,136))
dr.text((25,677),'Ingen ROM, ingen Stella, ingen verklig TIA-fysisk kernel',font=ft(15),fill=(209,205,192))
sheet.save(IMG/'SKOG_TRE_KANDIDATER.png')

kn=Image.new('RGB',(1100,775),(12,23,27));dk=ImageDraw.Draw(kn)
dk.text((25,16),'THE SKRAUN  /  TRE RIDDARE  ·  P1 8 x 16',font=ft(29,True),fill=TEXT)
dk.text((25,60),'Välj silhuett i verklig 8px-bredd först. Förstoringen visar exakta källceller.',font=ft(17),fill=(181,197,199))
for j,(name,k) in enumerate(K.items()):
 col=j*355+25
 dk.text((col,117),k['title'],font=ft(18,True),fill=TEXT)
 for i,pose in enumerate(('neutral','warning','strike')):
  x=col+i*108
  im=native_knight_canvas(k[pose+'_bits']);kn.paste(enlarge(im,10),(x+13,181))
  dk.text((x+10,354),{'neutral':'JAKT','warning':'VARNING','strike':'HUGG'}[pose],font=ft(13,True),fill=(189,213,218))
 for i,pose in enumerate(('neutral','warning','strike')):
  x=col+110*i
  im=native_knight_canvas(k[pose+'_bits']);kn.paste(im,(x+36,410))
 dk.text((col,460),'Överst: 10x  ·  Nederst: 1x P1',font=ft(15),fill=(165,201,211))
 dk.text((col,501),k['note'],font=ft(13),fill=(169,192,184))
dk.text((25,663),'Alla maskerna har 8 kolumner, 16 rader och en enda ljusblå P1-färg.',font=ft(18,True),fill=(224,231,229))
dk.text((25,704),'Inget här bevisar tre samtidiga P1-fiender; detta är SOURCE_ONLY, inte Stella.',font=ft(16),fill=(240,189,119))
kn.save(IMG/'RIDDARE_TRE_KANDIDATER.png')

# technical format, data integrity, proof markers
inc=[]
inc+=['; GRAPHICS II / MAIN IV / 2026-11-22','; SOURCE_ONLY P1 art bytes, top-first notation.','; ROM code may need bottom-first or reverse row sequencing: explicitly verify.','; No P1 scheduling, colour/timing, missile or TIA renderer implementation here.','']
for key,k in K.items():
 for pose in ('neutral','warning','strike'):
  label=f'{key}_{pose}'.replace('-','_').upper()
  inc.append(f'{label}:')
  for i,(s,h) in enumerate(zip(k[pose+'_bits'],k[pose+'_hex'])):
   inc.append(f'    dc.b {h} ; y={i:02d} %{s}')
  inc.append('')
(DATA/'KNIGHTS_P1_SOURCE_ONLY.inc').write_text('\n'.join(inc)+'\n',encoding='utf-8')

readme='''# THE SKRAUN — GRAPHICS II / MAIN IV / Forest and Knight art candidates

**2026-11-22 | SOURCE_ONLY / DESIGN_CANDIDATES / NOT APPROVED / NOT STELLA**

This isolated directory is one authorized graphics-design delivery. It does not modify the
frozen U1-LEG1 master sprite, ROM, TIA kernel, gameplay logic, levels, or other worlds.

## Visual assets
- `images/SKOG_TRE_KANDIDATER.png` — side-by-side woods A/B/C, 2x nearest-neighbour.
- `images/A_Glanta_poster.png`, etc. — 3x review posters, with source-only composite actors.
- `images/<forest>_PF_NATIVE_160x176.png` — exact logical PF art, 160cc x176 lines, no actors.
- `images/<forest>_COMPOSITE_NATIVE_160x176.png` — intentionally unimplemented composite: U1-LEG1 P0, two P1 knight instances, ranger proxy from v0.3 plus orb; NOT runnable physical proof.
- `images/RIDDARE_TRE_KANDIDATER.png` — 3x3 8-bit P1 poses, enlarged + native.
- `images/K*_POSES.png` — three separate pose review boards with 1x logical sprite and 16x grid view.
- `images/K*_*_NATIVE_8x16.png` — byte-exact source sprites, NOT Stella screenshots.

## Exact source, provenance
- `data/knight_masks.json` — K1/K2/K3 A neutral/raised warning/strike pixel rows, top-first bit7 left.
- `data/KNIGHTS_P1_SOURCE_ONLY.inc` — strictly source-only assembler data; ROW ORDER MUST BE CHECKED against a future rendering kernel.
- `data/forest_pf.json` — 20-bit left-hand row masks mirrored to 40 PF cells, 22 vertical bands of eight actual scanlines, exact PF0/PF1/PF2 values.\n- `data/palette_proposals.json` — preliminary TIA byte candidates with illustrative RGB only.
- `data/U1_LEG1_FROZEN_REFERENCE_UNMODIFIED.json` — **byte-identical public reference snapshot, not an edited art source**. SHA-256 `3762285335f5c7deb8b89812472c6d4f881fa04efb4f241db44ecf6530f6ba49`; source-of-truth remains the existing frozen graphics branch `graphics/u1-leg1-caprine-gait-20261116/graphics/u1_leg1/SOURCE_U1_LEG1.json`.
- `generate.py` — Pillow renderer, no Stella, no ROM, no cycle simulation, reproducible from JSON sources.

## Representation, hard limits
- Atari TIA playfield: PF0 4 bits + PF1 8 bits + PF2 8 bits on each 80cc half; 1 PF cell = 4 color clocks. The source uses `CTRLPF.D0=1` mirrored right half. A candidate spans 22x8 = 176 lines, not 22 physical scanlines. Each row has three precomputed PF register bytes. Unmerged source art is not a claim of safe write deadlines or available cycles during a visible gameplay kernel.
- The 8x16 P1 sprite colour is unified; sample light-blue `COLUP1=$9E`, *not a validated NTSC colour approval*. P1 holds one 8-bit pattern at a time; alternating knight/ranger/same-Y multiplexing is NOT solved by this artwork. M1 shares P1 colour, and using it as a separate sword is **not** authorized.
- Forest source uses `COLUBK` dark green / `COLUPF` muted green (illustrative RGB); actual register-byte palette needs ROM DEVELOPMENT's real Stella palette test. Test B globally switches all playfield to gold under halo, including trees: the environmental masks remain the same. A green PF cannot stay independently green during gold with one COLUPF.
- Each visual crown tile is mirrored on screen; visible rounded branches are coarse 4cc x8-line PF cells (no 1cc texture or unproven extra object). Trees/branches are **visual masks only**; collisions/hitbox are separate and no arena gameplay geometry is adopted. A later developer must provide an explicitly authorized safe arena and gap/growth proof before treating any shape as solid.
- P1 sword is **inside the same 8-bit player mask**. Its blade reach relative to the moving knight depends on pose and facing; attack hitbox/timing stays independent. The 0.4s warning and brief strike/1s recovery from design canon remain unchanged. The sprite cannot communicate different metal colours unless a new per-scanline colour schedule is proven physically, which this art DOES NOT assume.

## Verdict & release fence
Recommended **forest A** (open tree crowns with maximum central space) + **knight K1** (visor with distinct blade-raise pose). K2 is runner-up for recognisable winged helmet; K3 is deliberately heavier but less legible as distinct blade in 8-bit width. These are design recommendations only; user/MAIN IV approval is separate.

No ROM, no GitHub main merge, no implementation order, no N8/N9, no other-world art and no independent verification is created through this delivery.
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')
report='''# GRAPHICS II → MAIN IV — skogsglänta och riddar-P1 (2026-11-22)

**Verdikt:** SOURCE_ONLY. Tre skogsmasker, tre åttabitars riddarfamiljer och tre poser per familj. Ingen design är ännu användar-/MAIN-godkänd. Inga riktiga Stella-bilder, ROM-test eller tidsmätningar har utförts.

## Kontrollerade projektkällor
- MAIN IV GAMEPLAY-1 draft PR #41 head `7f289a536c375bf760428274280179cfe15a6a62`, F8 8KiB experimental, **delvis spelbart**, en P1-proxy åt gången, 2 provisoriska PF-kartor, ljusblå P1 `COLUP1=$9E`, testvärlds-PF och logisk svärdsvarning utan upplyft sprite.
- Designbeslut 01–60, senare L3 fri manövrering; visuell riktning, U1-LEG1 exakt källa på fryst grafikgren; tidigare GRAPHICS v0.3 `ENEMIES_V03.json`, `WORLDS_V03.json` (oreviderade designreferenser).
- Original skiss/fotografi: används inte, publiceras inte.

## A / skogsmiljö
Alla tre består av 20 bitar vänster PF-halva, **speglade** i höger halvbild, 22 band á 8 scanlines = 176 lines. En pixelcell = 4 TIA colour clocks bred, alltså ingen felaktig 1-clock träddetalj. Källmaskerna finns i JSON. Varje trädkronepixel och stam är samma PF-färg; ingen per-objekt tvåfärgsträd-rastertrick antas.
- **A Gläntan:** rund/kantig skogskrona upptill, ojämn nedtill och buske på ytterkanten. Öppen mitt och tydliga två-trädgrupper. **Rekommenderas.**
- **B Dungar:** en högre ojämn gruppering + träd nära den övre delen och mindre stubbar. Något tätare.
- **C Skogskant:** större variation längs vänster/höger skogskant, centralt öppet, 4 återanvändbara tiles.

Hela de synliga PF-maskerna ger en källgeometrisk mittöppning, men det är **inte** verifierade kollisionspassager. Använd inte den visuella kronans bounding box som direkt gameplay-hitbox utan egen design-/implementationsacceptans. Små löv/gräs på marken föreslås endast som valfri framtida dekor: de är inte ritade in, eftersom TIA inte har ett gratis separat dekorationslager. Ny världsfärg och guldhalo konkurrerar om samma COLUPF.

## B / riddare
- **K1 Visir & svärd (rekommenderas):** tydlig mörk visirspalt, skarpa axlar, separat benpar; högervinklad hållning i neutral och en tydlig 1-bit upphöjd klinga i warning. Slagruta har diagonal, integrerad klingform inom samma 8-bit P1.
- **K2 Vinghjälm:** tydliga hjälmspetsar, svärd på vänster sida; mer sagoriddare men risk för horn-liknande silhuett som liknar Skraun.
- **K3 Tung rustning:** bred plåtrustning/hjälm; närmast en robust tank, men svärdet kan se ut som en axelklump i rörelse.

Varje pose 8x16, topp-först, 1 bit per 1 P1 clock. Byteexakta tabeller/hex i JSON och `.inc`. Om original ROM använder omvänd ordning / dubblerade källrader måste ROM DEVELOPMENT översätta utan att påstå drop-in bevis.

**Animation/strid:** neutral jakt → varning i cirka 0,4s (24 NTSC frames) → kort skadefönster med strike-mask → cirka 1s återhämtning, enligt canon. Spegling via REFP1 är möjligt i design, men riktning och sent GRP1-timing måste särskilt testas. `COLUP1=$9E` kandidat, färger på grafiska kort är illustrativa RGB och inte en emulatorpalett.

## Integrationskontrakt till ROM DEVELOPMENT III (framtida, EJ ORDER)
1. INPUT: en vald familj K1/2/3, 3x16-byte tabeller, ren 8x16 P1 (NUSIZ1 1x) och PF variant A/B/C: 22 tripletter PF0/1/2 i skanningsordning. Mirrored CTRLPF D0=1; inga ändrade Skraun 8x12-källbitar.
2. Granska bank1 `Visible` / befintliga `DummyScan` och `PlayPF1`/`HaloRowPtr` där PF2 skrivs på fysisk rasterrad. Nya PF0/PF1/PF2 bytepar får inte ersätta halo-PF2-grafik eller injiceras utan faktisk deadlineledger. Synk med guld-B/ON och spelar-/P1-pixlar måste provas som gemensam skärm.
3. Utbilda den faktiska korrekta row-order i ROM; jämför exakta 8 bitar / samtliga 16 rader med en verklig Stella-pixelorakel. Bevisa fysisk poseväxling inom 0,4s-varningen och kort strike-fönster, och korrekt weapon hitbox som **inte** skadar via kroppskontakt.
4. En P1 kan inte samtidigt visa två oberoende knights och ranger utan korrekt multiplexing; den här designen löser INTE den öppna fysiska N6-C/N7-grinden eller samma-Y 6507-budgeten. Svärd via M1 är bara framtida alternativ (delar P1-färg), inte en kravändring.
5. Koppla separat solida kollisionsformer till visuellt identifierbara trädkronor/stammar; level3 32x36 måste förbli fullt manövrerbar, utan tysta hitbox-krympningar. Verifiera båda skogsbanornas öppna vägar, orb- och growth-platser genom faktisk kommande gameplay-test, inte source-only bild.
6. Mät 262 NTSC scanlines, worst-case beam-write deadlines / 76c, riktig 6507-väg, stack/RAM 128B, reproducerbar assembler- och Stella-artefakt **inom separat auktoriserat ROM-uppdrag**. Ingen implementation görs här.

## Väsentliga begränsningar
Den planerade utvecklingsvägen kan behöva alternativa synliga PF-masktrick om hela halo/hinder/fiende-renderern inte har cykler kvar. Detta SOURCE_ONLY-paket tillför INTE nya TIA-objekt, men byter PF-maskvärden och kan ändra antal registeruppdateringar/ROM-tabellbehov. Ingen automatisk timing neutralitet får utlovas. Prioritering: tydlig skog, igenkännbar hjälm och märkbart svärd i faktisk skala, utan att kompromissa med tre fiender, halo, nivå 3 eller speltempo.
'''
(ROOT/'MAIN_IV_REPORT.md').write_text(report,encoding='utf-8')
# SHA over delivered static assets (excluding manifesto itself)
manifest=[]
for path in sorted(ROOT.rglob('*')):
 if path.is_file() and path.name not in ('SHA256SUMS.txt',):
  manifest.append(f'{sha(path.read_bytes())}  {path.relative_to(ROOT).as_posix()}')
(ROOT/'SHA256SUMS.txt').write_text('\n'.join(manifest)+'\n',encoding='utf-8')
print('Created',len(manifest),'files; forest min gaps:',[(k,v['min_clear_central_width_cc']) for k,v in forest['variants'].items()])
