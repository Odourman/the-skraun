# THE SKRAUN / GRAPHICS II / MAIN VI

SOURCE_ONLY slutleverans 2026-11-27. Börja med `MAIN_HANDOFF.md`. Alla bilder och tabeller är framtagna från exakt samma 8-bitars sprite- och PF1-data. Inga filer i original-PR76 eller tidigare grafikleverans har ändrats.

- `art/ALL_EIGHT_WORLDS_MAIN_VI_SOURCE_ONLY.png`
- `art/ALL_EIGHT_BATTLE_STAGE_PREVIEWS_SOURCE_ONLY.png` (illustrerad samtidig layout, ej TIA-bevis)
- `art/USER_REFERENCE_VS_TWO_8x16_CANDIDATES_SOURCE_ONLY.png`
- `art/C_SHIELD_CONTOUR_COMPLETE_GIF_SOURCE_ONLY.gif` och `art/C_SHIELD_SOLID_COMPLETE_GIF_SOURCE_ONLY.gif`
- `art/WORLD_PF1_DROPIN_SOURCE_ONLY.asm`, `art/KNIGHT_P1_DROPIN_SOURCE_ONLY.asm`
- `art/SHIELD_SWORD_BODY_LAYERS.json` samt `art/WORLD_GEOMETRY_INVISIBLE_SOLIDS_AUDIT.json`
- `tools/generate.py`, `tools/validate.py` för reproduktion och statisk kontroll
- `SHA256SUMS.txt` täcker alla övriga arkiverade filer.
