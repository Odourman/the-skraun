# ROM DEVELOPMENT – INTEGRATIONSGUIDE (INGEN ROM-ORDER)

**Begränsa till fryst PR76/C innan en separat ny MAIN-order.**

## 1. Direkt källdatabyte (ingen avsiktlig kodändring)

- I `experiments/fullgame1_arrow_halo_20261125/bank3.asm`, ersätt endast exakt `PlayPF1`-region mellan `ORG $FA00` och `ORG $FD00` med `art/WORLD_PF1_DROPIN_SOURCE_ONLY.asm`. Precis **8×96=768 byte**, samma tabelladresser; `WorldPFLo`, `WorldPFHi`, `WorldPFIndex`, `CTRLPF`, världsfärger och RAM oförändrade.
- Ersätt endast innehållet under `K1NeutralBytes`, `K1WarningBytes`, `K1StrikeBytes` i `ORG $F7A8` med 3×17 bytes från `art/KNIGHT_P1_DROPIN_SOURCE_ONLY.asm` (rekommenderad sköldkontur). Om MAIN väljer solid sköld används alternativfilen i stället, aldrig båda samtidigt. Behåll `R1NeutralBytes`, `R1DrawBytes`, `R1ReleaseBytes` byte-exakta.
- P1 bit7 vänster, källrader top-first; ROM omvänd ordning, byte 16 = nollvakt. `REFP1` och `VDELP1` hanteras av befintlig renderer. Ingen ändring i NUSIZ1 eller pil M1. 184 fysiska PF-rader, X 184→1, synliga PF1 parindex 92→1; två särskilda färgradpar idx61/56 skriver PF1=0. Rendering ska granskas i riktig Stella.

## 2. Mindre kod/ROM-utrymmesändring – INTE drop-in

- Lägg endast efter separat MAIN-auktorisation in `WALK_B` (17 byte extra för delad riddarkälla), ett extra par `EnemyArtLo/Hi`-pekare (2 byte) och viss posevalskod för alternering av WALK_A/B **bara vid faktiskt rörelse**. WARNING, STRIKE, återhämtning måste stoppa gångväxling. P1 och eventuellt L3-aura ska prioriteras enligt tidigare scheduler, utan nytt TIA-objekt.
- Den nuvarande maskregionen `F7A8–F820` ger 120 byte. Sex etablerade 17-byte maskdata är 102 byte; 9 byte `ds` plus 9 ytterligare lediga byte når 120, så 17 nya byte passar inte där utan omlokalisering av minst 8 byte. Flytta INTE på befintliga pointer/bankgränser utan DASM/SHA-bevis.

## 3. Större ändringar som kräver MAIN-beslut

- Exaktare collision än 4 AABB per bana, t.ex. krona + stam, håliga portaler eller spiralöppningar; ny kod/rombudget och alternativa rektanglar krävs, se audit.
- Längre synligt svärd än P1:s 8 kolumner, förlängd träffräckvidd, flyttad P1-position eller extra TIA-objekt. M1 är redan Ranger-pil och får inte lånas implicit.
- Eventuellt NUSIZ1-skalerad 16-klockors riddare (fortfarande endast 8 oberoende bitkolumner), påverkar missil, P1-placering och multiplexering: ingår **inte** i drop-in.
- Justering av förvarnings-/hugg-/vilotider från PR76 `#16/#9/#24` mot äldre designmål `~0.4s/~1s`; inte ett grafiskt beslut.

## Test som faktiskt krävs efter auktorisation

Bygg exakt F6/NTSC 16KiB ROM med DASM, kör Stella 6.7.1 eller modern kompatibel. Kontrollera 262 scanlines i alla världar, real P1 16-radsmask/1-rads-VDEL, REFP1 och neutral+warning+strike, båda riddarna och Ranger i multiplexering, M1-pil/BL-orb/L3-aura, färgväxlingar, beamdeadline/rastercykler, stack/RAM, kollisionsskillnad mellan AABB och visuella hål, L3-övergångar, orb och riktiga joysticksekvenser. Nya bilder ska märkas DEVELOPER_OBSERVED endast efter verklig körning.
