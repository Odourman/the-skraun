; ALTERNATIVE only: replace original K1 3 x 17-byte tables after a MAIN visual choice.
; C_SHIELD_SOLID, SOURCE_ONLY; NOT simultaneously with C_SHIELD_CONTOUR.
K1NeutralBytes:
    dc.b $4C,$64,$25,$35,$5D,$DF,$FE,$FE,$FE,$FC,$7C,$38,$7C,$44,$7C,$38,$00
K1WarningBytes:
    dc.b $4C,$64,$24,$34,$5C,$DC,$FC,$FC,$FE,$FF,$7D,$39,$7D,$45,$7D,$39,$00
K1StrikeBytes:
    dc.b $4C,$64,$24,$34,$5C,$DC,$FF,$FF,$FC,$FC,$7C,$38,$7C,$44,$7C,$38,$00
