; OPTIONAL WALK_B, NOT DROP-IN: requires new enemy art pointer/selector; 17 bytes plus code/pointers.
; Existing F7A8..F820 contains 6*17=102 actor bytes, ds 9 = 111, + 9 slack =120.
; New 17B mask does not fit entire 17B at same location (only 9B spare); relocation mandatory.
CShieldContourWalkB:
    dc.b $68,$2C,$25,$35,$5D,$DF,$DE,$DE,$DE,$FC,$7C,$38,$7C,$44,$7C,$38,$00
CShieldSolidWalkB:
    dc.b $68,$2C,$25,$35,$5D,$DF,$FE,$FE,$FE,$FC,$7C,$38,$7C,$44,$7C,$38,$00
