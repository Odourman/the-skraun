# Reproducera SOURCE_ONLY-data

Kräver Python 3.10+ och Pillow. Från ZIP-rot:

```bash
python tools/generate.py .
python tools/validate.py .
python tools/package.py .
```

Första kommandot regenererar alla `art/` PNG/GIF/JSON/ASM direkt från `reference/` och fryst PR76-källa i `baseline/`. Andra kommandot kontrollerar datalängder, exakta ROM/PF-byte, 8x16-masker och deras PNG, källans morfologi, spegling, binär bitordning och alla L1–L3-BFS-vägar. Tredje kommandot skriver om SHA256SUMS.txt och det deterministiska ZIP-arkivet. Det körs ingen DASM eller Stella.

SHA256SUMS.txt listar alla filer förutom sig själv. ZIP-filen distribueras separat från paketmappen och ingår därför inte som eget objekt i manifestet.
