# Visuell självkritik – SOURCE_ONLY

Den aktuella huvudreferensen visar en upprätt ljusblå riddare med en horisontell slits i hjälmen, tydlig rundad sköld till vänster och synligt sammanbundet svärd till höger. 8-bitarsproportionerna innebär att hjälmen blir en kompromiss, skölden 2 pixelkolumner och svärdet som längst en kolumn till ytterkanten. Den centrala kroppen är dock sammanhängande i alla fyra masker. Hela kanten (visir, sköld, vapen) är transparent när ingen pixel avses; ingen extra färg har reserverats.

**C_SHIELD_CONTOUR** får större sköldläsbarhet än tidigare K1. **C_SHIELD_SOLID** saknar avgränsningsränna men kan uppfattas som en tjock vänsterarm. Kontrollera särskilt figuren i original 8×16, där skillnaden är subtil. Båda WALK_A/B använder samma hjälm/axlar och växlande fötter. WARNING visar svärdet uppåt, STRIKE korsvis framåt och ingen lös pixelö lämnas.

Världarna 1,3,5,7 lämnas exakt som förra leveransen; 2 har bättre rund krona/tydligare barr, 4 mindre trappig bergstopp, 6 mer igenkännbar spiral och delvis förseglad portalbas, 8 något tydligare kollapssiluett. De udda använder REFLECT, jämna REPEAT, vilket ger andra skärmhalvans PF1 en annan X-position.

Avsiktliga förenklingar: de statiska kompositscenerna visar fler figurer och aura samtidigt än PR76 kan garantera, och färgerna är approximationer av TIA-färgbyte; ingen ny bild kommer från Stella. En ritad aura är endast en jämförelseoval och gör inget påstående om faktisk pixelperfekt P1-halo.
