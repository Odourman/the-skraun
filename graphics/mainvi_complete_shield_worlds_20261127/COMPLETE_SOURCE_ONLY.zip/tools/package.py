#!/usr/bin/env python3
"""Deterministic ZIP publisher for The Skraun Graphics II MAIN VI SOURCE_ONLY package."""
import hashlib,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
out=root.parent/'THE_SKRAUN_GRAPHICS_VI_KNIGHT_SHIELD_EIGHT_WORLDS_SOURCE_ONLY_2026-11-27.zip'
paths=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt' and p.name!='.DS_Store')
entries=[(p.relative_to(root).as_posix(),p.read_bytes()) for p in paths]
manifest=''.join(hashlib.sha256(b).hexdigest()+'  '+rel+'\n' for rel,b in entries).encode()
(root/'SHA256SUMS.txt').write_bytes(manifest)
entries.append(('SHA256SUMS.txt',manifest))
entries.sort(key=lambda t:t[0])
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel,bytes_ in entries:
  i=zipfile.ZipInfo(filename=rel,date_time=(1980,1,1,0,0,0))
  i.compress_type=zipfile.ZIP_DEFLATED
  i.external_attr=(0o100644 & 0xFFFF)<<16
  z.writestr(i,bytes_,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for rel,b in entries:assert z.read(rel)==b
assert len(entries)==len(paths)+1
print('OUTPUT',str(out))
print('FILES',len(entries),'MANIFEST_ENTRIES',len(paths),'BYTES',out.stat().st_size)
print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
