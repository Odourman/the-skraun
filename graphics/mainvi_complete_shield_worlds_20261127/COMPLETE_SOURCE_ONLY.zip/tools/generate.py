#!/usr/bin/env python3
"""The Skraun / MAIN VI GRAPHICS II source-only art generator.
Requires Pillow; no game code is executed and no emulator is simulated.
All visual previews generated from same P1/PF1 byte arrays as output ASM.
Run: python tools/generate.py [package_directory]; default inferred from script.
"""
from pathlib import Path
from hashlib import sha256
from collections import deque
import json, re, sys, math
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
ROOT.mkdir(parents=True,exist_ok=True)
OUT=ROOT/'art'; OUT.mkdir(exist_ok=True)
BASE=ROOT/'baseline'/'PR76_C_BANK3_UNMODIFIED.asm'
SRC=BASE.read_text()
def extract(name,amount=None):
    m=re.search(r'(?m)^'+re.escape(name)+r':\s*\n',SRC)
    if not m:raise RuntimeError(f'not found {name}')
    s=SRC[m.end():]
    b=[]
    for line in s.splitlines():
        if not line.strip().startswith('dc.b'):break
        line=line.split(';')[0].split('dc.b',1)[1]
        b.extend(int(x.strip()[1:],16) if x.strip().startswith('$') else int(x.strip(),10) for x in line.split(',') if x.strip())
    if amount is not None and len(b)!=amount: raise ValueError((name,len(b),amount))
    return b
# Grab sprite tables from exact PR76/C source; verify entire 6*17+9B ROM allocation.
oldkn={n:extract(n,17) for n in ['K1NeutralBytes','K1WarningBytes','K1StrikeBytes','R1NeutralBytes','R1DrawBytes','R1ReleaseBytes']}
raw=extract('PlayPF1',768)
worlds=[raw[i*96:(i+1)*96] for i in range(8)]
# WorldRects are from PR76/C bank0, separate from what the PF bytes can change.
b0=(ROOT/'baseline'/'PR76_C_BANK0_UNMODIFIED.asm').read_text()
rectsection=b0.split('WorldRects:',1)[1].split('RangerCheckTimer:',1)[0]
rects=[]
for line in rectsection.splitlines():
    if 'dc.b' in line:
        ss=line.split(';')[0].split('dc.b',1)[1]
        vals=[int(v.strip().replace('$','0x'),0) for v in ss.split(',') if v.strip()]
        if len(vals)==16:rects.append([vals[k:k+4] for k in range(0,16,4)])
assert len(rects)==8
# NOTE: sources use these exact band index ranges. Never widen outside existing AABB rectangles.
def bands(data):
    active=[i for i,v in enumerate(data) if v!=0]
    groups=[]
    for i in active:
        if not groups or i-groups[-1][-1]>1:groups.append([i])
        else: groups[-1].append(i)
    assert len(groups)==2,(len(groups),[(g[0],g[-1]) for g in groups])
    # ascending index == bottom->top, so top group is last group
    return [(groups[-1][0],groups[-1][-1]),(groups[0][0],groups[0][-1])]
# 8-bit patterns, bit 7 = leftmost. Entries are top-first source rows; rows mapped to native two-line table resolution.
# Even stages intentionally avoid leftmost bit (x=16..20) because actual repetition shifts right-side obstacle to x=96..128.
patterns={
'1_top_pine':[
'...##...','..####..','..####..','.######.','.######.','..####..','########','########','.######.',
'..####..','.######.','########','########','...##...','...##...','...##...','...##...','...##...','...##...'],
'1_bottom_round':[
'..####..','.######.','.######.','########','########','########','########','.######.','.######.',
'..####..','..####..','...##...','...##...','...##...','...##...','...##...','...##...'],
'2_top_round':[
'...###..','..#####.','.#######','.#######','.#######','.#######','.#######','.#######',
'..#####.','..#####.','...###..','...##...','...##...','...##...','...##...','...##...',
'...##...','...##...'],
'2_bottom_pine':[
'....#...','...###..','...###..','..#####.','..#####.','...###..','.#######','.#######',
'..#####.','...###..','..#####.','.#######','.#######','...##...','...##...','...##...',
'...##...','...##...'],
'3_top_peak':[
'...##...','..####..','..####..','.######.','.######.','########','########',
'########','########','########','########','########','########'],
'3_bottom_rock':[
'..####..','..####..','.######.','.######.','########','########','########','########','########',
'########','########','########'],
'4_top_peak':[
'....#...','...###..','...###..','..#####.','..#####.','.#######','.#######',
'.#######','.#######','.#######','.#######','.#######','.#######'],
'4_bottom_rock':[
'...###..','..#####.','..#####.','.#######','.#######','.#######','.#######',
'.#######','.#######','.#######','.#######','.#######'],
'5_top_spiral':[
'#######.','#.....#.','#.#####.','#.#.....','#.#.###.','#.#.#.#.','#...#.#.',
'#####.#.','#.....#.','#######.'],
'5_bottom_portal':[
'..####..','.######.','########','########','##....##','##....##','##....##','##....##',
'##....##','##....##','##....##','##....##'],
'6_top_portal':[
'...##...','..####..','.######.','.######.','.##..##.','.##..##.','.##..##.',
'.##..##.','.##..##.','.##..##.','.##..##.','.##..##.'],
'6_bottom_spiral':[
'.#######','.1.....1', # corrected immediately below using dotted rows
'.#######','.##...##','.###..##','.####.##','.##.#.##','.##...##','.#######'],
'7_top_wall':[
'##.##.##','##.##.##','##.##.##','########','########','########','########','########',
'########','########','########','########'],
'7_bottom_ruin':[
'##....##','##...###','###..###','###.####','########','########','########','########',
'########','########','########'],
'8_top_ruin':[
'.##....#','.##...##','.###..##','.###.###','.#######','.#######','.#######',
'.#######','.#######','.#######','.#######'],
'8_bottom_wall':[
'.##.##.#','.##.##.#','.##.##.#','.#######','.#######','.#######','.#######',
'.#######','.#######','.#######','.#######']
}
patterns['6_bottom_spiral']=[
'.#######','.##....#','.######.','.....#.#','.#####.#','.##..#.#','.##.##.#',
'.##....#','.#######'
]
# Explicit stage-specific motifs, not merely reusing identical masks between even and odd stage.
assign=[('1_top_pine','1_bottom_round'),('2_top_round','2_bottom_pine'),('3_top_peak','3_bottom_rock'),('4_top_peak','4_bottom_rock'),('5_top_spiral','5_bottom_portal'),('6_top_portal','6_bottom_spiral'),('7_top_wall','7_bottom_ruin'),('8_top_ruin','8_bottom_wall')]
# Ensure ASCII patterns are individually valid and even stages stay in their narrower hardware footprint.
for name,rows in patterns.items():
    assert all(len(r)==8 and set(r)<={'.','#'} for r in rows),(name,rows)
    if int(name[0])%2==0: assert all(r[0]=='.' for r in rows),name

def genband(source,bounds,pattern):
    lo,hi=bounds; length=hi-lo+1
    # Generate top-first native rows, resample to existing exact band height.
    templ=patterns[pattern]
    tops=[templ[min(len(templ)-1,(j*len(templ))//length)] for j in range(length)]
    arr=source.copy()
    for n,idx in enumerate(range(hi,lo-1,-1)):
        arr[idx]=int(tops[n].replace('#','1').replace('.','0'),2)
    return arr
proposed=[]
# Improve only stages whose geometry/readability benefits from rework; the rest reuses prior visual art.
patterns.update({
'2_top_round': ['...##...','..####..','.######.','.#######','.#######','.#######','.######.','..####..','..####..','...##...','...##...','...##...','...##...','...##...','...##...','...##...','...##...','...##...'],
'2_bottom_pine':['....#...','...###..','...###..','..#####.','..#####.','...###..','.#######','.#######','..#####.','..#####.','..#####.','.#######','.#######','...##...','...##...','...##...','...##...','...##...'],
'4_top_peak':['....#...','...###..','..#####.','..#####.','.#######','.#######','.#######','.#######','.#######','.#######','.#######','.#######','.#######'],
'6_top_portal':['...##...','..####..','.######.','.######.','.##..##.','.##..##.','.##..##.','.##..##.','.##..##.','.##..##.','.######.','.######.'],
'6_bottom_spiral':['.#######','.#.....#','.#.#####','.#.#...#','.#.#.###','.#.#.#.#','.#...#.#','.#####.#','.#.....#'],
'8_top_ruin':['.##...##','.##...##','.###..##','.###.###','.#######','.#######','.#######','.#######','.#######','.#######','.#######']
})
for name, rows in patterns.items():
    assert all(len(x)==8 and set(x) <= set('.#') for x in rows)
    assert not(int(name[0])%2==0 and any(x[0]=='#' for x in rows))
proposed=[]
for stage,arr in enumerate(worlds):
    top,bot=bands(arr)
    out=genband(arr,top,assign[stage][0]);out=genband(out,bot,assign[stage][1]);
    # No previously empty PF1 cell outside two established vertical bands.
    for idx in range(96):
        if arr[idx]==0 and not(top[0]<=idx<=top[1] or bot[0]<=idx<=bot[1]):assert out[idx]==0
    proposed.append(out)
assert len(proposed)==8 and all(len(x)==96 for x in proposed)
# Knight candidate masks top-first; all 16 rows, feet and torso held stationary across poses.
# MAIN VI VI references, exact user-supplied 8x16 bitmap is primary authority for new knight identity.
refC=json.loads((ROOT/'reference'/'SKRAUN_C_SKOLD_GANG_8x16.json').read_text())['poses']
K2={k.replace('walk_A','neutral').replace('walk_B','walk_B'):{'top_first':v['top_first']} for k,v in refC.items()}
K2={k:[r.replace('1','#').replace('0','.') for r in v['top_first']] for k,v in K2.items()}
# Shield SOLID: reference-preserving body/head/feet with sword drawn at hand and lowered in walk.
for nm in ('neutral','walk_B'):
    K2[nm][8]='11111110'
    K2[nm][9]='11111110'
    K2[nm][10]='11011111'
    K2[nm][11]='01011101'  # connects the right leg at x5 to the main torso, sword remains at x7
# Attack legs/feet deliberately frozen at WALK_A anchor. The lowered sword tip at x7
# in WALK cannot persist as disconnected sword fragments during WARNING/STRIKE.
for nm in ('warning','strike'):
    K2[nm][11]='01011100'   # torso x5 links to right leg
    K2[nm][-4:]=[r[:7]+'0' for r in K2['neutral'][-4:]]
# Shield CONTOUR (recommended): transparent column2 marks shield edge only below intact shoulder.
K1={name:rows.copy() for name,rows in K2.items()}
for name,rows in K1.items():
    if name in ('neutral','walk_B'):
        rows[7]='11011110';rows[8]='11011110';rows[9]='11011110'
    elif name=='warning':
        rows[7]='11011110';rows[8]='11011100';rows[9]='11011100'
    elif name=='strike':
        rows[7]='11011100';rows[8]='11011111';rows[9]='11011111'
# Convert programmatic binary overrides into the same . / # visual convention.
for fam in (K1,K2):
    for pose in fam: fam[pose]=[r.replace('1','#').replace('0','.') for r in fam[pose]]
# Poses remain top-first 8x16, normalized to the exact original anchor/feet.
for family,poses in [('K1',K1),('K2',K2)]:
    for name,rows in poses.items(): assert len(rows)==16 and all(len(r)==8 and set(r)<={'.','#'} for r in rows),(family,name)
for p in ('neutral','warning','strike'):
    assert all(a[:7]==b[:7] for a,b in zip(K1[p][-4:],K1['neutral'][-4:])) and all(a[:7]==b[:7] for a,b in zip(K2[p][-4:],K2['neutral'][-4:]))
hexrow=lambda x:[int(row.replace('#','1').replace('.','0'),2) for row in x]
knight={fam:{pose:{'top_first_binary':[r.replace('#','1').replace('.','0') for r in rows], 'rom_bottom_first_hex':[f'${v:02X}' for v in hexrow(rows)[::-1]]+['$00'], 'mirror_top_first_binary':[r.replace('#','1').replace('.','0')[::-1] for r in rows]} for pose,rows in poses.items()} for fam,poses in [('C_SHIELD_CONTOUR',K1),('C_SHIELD_SOLID',K2)]}
# Old reference and source bytes. Do not alter R1 tables in assembler output.
original_knight={n:oldkn[n] for n in ('K1NeutralBytes','K1WarningBytes','K1StrikeBytes')}
# TIA active PF1 geometry. WorldPFIndex first-row lookup from X=184 through X=2 is 92..1, one lookup per pair.
# Start with row 0 (top), 184 rows. PF1 forced blank at index 56 and 61 color rows. PF0=0, PF2 = separate aura, preview is PF1 geometry only.
def matrix(data,stage):
    pic=Image.new('RGB',(160,184),(0,0,0));pix=pic.load();
    for pair in range(92):
        idx=92-pair
        if idx in (56,61):continue  # PR76 color-control lines (PF1=0 on pair)
        b=data[idx]
        for v in range(8):
            if b&(0x80>>v):
                for dy in range(2):
                    for dx in range(4):
                        x=16+4*v+dx;pix[x,2*pair+dy]=(255,255,255)
                        if stage%2==1: # reflected: right half = 160-(left + 1)
                            pix[159-x,2*pair+dy]=(255,255,255)
                        else: # repeated: right half starts +80 clocks
                            pix[x+80,2*pair+dy]=(255,255,255)
    return pic
# NTSC approximate palette based on source register values, concept, not Stella color calibration.
COLORS=[(100,162,78),(109,178,85),(111,127,154),(125,145,172),(166,95,186),(178,108,198),(88,115,183),(100,126,199)]
BACKS=[(7,16,10),(7,16,10),(20,20,24),(20,20,24),(19,11,27),(19,11,27),(4,8,18),(4,8,18)]
GOLD=(225,183,64); BLUE=(151,202,249); RANGER=[(93,181,91),(93,181,91),(113,140,157),(113,140,157),(150,99,178),(150,99,178),(116,132,185),(116,132,185)]
GRAY=(207,207,208)
# Native 160x184 pixel canvases: PF1 field occupies only a fixed subset of the screen.
def render(data,stage,gold=False):
    m=matrix(data,stage+1); c=GOLD if gold else COLORS[stage]
    bg=BACKS[stage]
    o=Image.new('RGB',m.size,bg)
    o.paste(c,(0,0,160,184),m.convert('L'))
    return o
# for bitmap sprite draw P0/P1 exactly one logical pixel wide, preview only.
U1_A=['00100100','01111110','01011010','01100110','00111110','01111111','10111100','00111100','00111100','00100110','00100011','01100000']
def blit_sprite(im,rows,x,y,color,sx=1,sy=1):
    p=im.load()
    for j,row in enumerate(rows):
        for i,b in enumerate(row):
            if b=='1' or b=='#':
                for ay in range(sy):
                    for ax in range(sx):
                        px=x+i*sx+ax; py=y+j*sy+ay
                        if 0<=px<im.width and 0<=py<im.height:p[px,py]=color
# Renderer screenshot-like sources are not real emulator; optional actors are spatial exemplars only.
def actor_scene(data,stage,level):
    o=render(data,stage)
    dims={1:(1,12),2:(2,20),3:(4,30)}; sx,h=dims[level]
    # preserve U1-LEG1 source mask; height equals actual PR76 L1/L2/L3 (12/20/30).
    # nearest row allocation is SOURCE_ONLY, not a claim of ROM P0 row-exactness.
    ub=Image.new('RGB',(8,12),(0,0,0))
    blit_sprite(ub,U1_A,0,0,GRAY)
    rowscaled=ub.resize((8*sx,h),Image.Resampling.NEAREST)
    black=(0,0,0); dest=o.load(); srcpix=rowscaled.load()
    for j in range(h):
        for k in range(8*sx):
            if srcpix[k,j]!=black:
                xx=80-4*sx+k; yy=91-h//2+j
                if 0<=xx<160 and 0<=yy<184:dest[xx,yy]=GRAY
    blit_sprite(o,K1['neutral'],53,88,BLUE,1,1)
    blit_sprite(o,K1['neutral'],118,96,BLUE,1,1)
    r0=oldkn['R1NeutralBytes'][:16][::-1]
    blit_sprite(o,[f'{x:08b}' for x in r0],138,74,RANGER[stage],1,1)
    dr=ImageDraw.Draw(o)
    px=(22 if stage%2==0 else 138)  # ONE orb displayed, other candidate tested separately
    dr.ellipse((px-2,68-2,px+2,68+2),fill=GOLD)
    return o
# Geometric AABB model precisely follows CurrentPR76 CandidateValid x/y comparisons.
MINX,MAXX,MINY,MAXY=20,141,19,158
HALFW,HALFH=16,15
OBX=(22,138); OBY=68; start=(80,88)
def valid(x,y,stage):
    if not(MINX<=x<MAXX and MINY<=y<MAXY):return False
    for a,b,c,d in rects[stage]:
        if x+HALFW>=a and x-HALFW<b and y+HALFH>=c and y-HALFH<d:return False
    return True
# Enumerate 4 cardinal moves only as a conservative reachability lower bound,
# actual game supports eight dirs / axis sliding.
def reach(stage):
    assert valid(*start,stage),(stage,'center blocked')
    todo=deque([start]);visited={start}
    while todo:
        x,y=todo.popleft()
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
            p=(x+dx,y+dy)
            if p not in visited and valid(*p,stage):visited.add(p);todo.append(p)
    targets={str(x):((x,OBY) in visited) for x in OBX}
    return len(visited),targets
# Model visual occupancy boundaries and whether each white pixel lies inside candidate collider.
def coverage(stage,dat):
    mask=matrix(dat,stage+1).convert('L'); p=mask.load(); inside=0;outside=0
    # overlay bounding rectangle x/y screen extents: game y = image y -8 (SOURCE_ONLY matching visible PF1 index 92)
    for y in range(184):
        for x in range(160):
            if p[x,y]:
                if any(a<=x<b and c+8<=y<d+8 for a,b,c,d in rects[stage]):inside+=1
                else:outside+=1
    return {'in_pixels':inside,'outside_collision_envelopes_pixels':outside}
# Note collision y +9 baseline is documented offset from previous graphical PR; keep separate from runtime proof.
metrics=[]
for stage in range(8):
    count,targets=reach(stage)
    metric={'stage':stage+1,'source_bytes_changed':sum(a!=b for a,b in zip(worlds[stage],proposed[stage])),
            'active_old':sum(v!=0 for v in worlds[stage]),'active_new':sum(v!=0 for v in proposed[stage]),
            'reflect_or_repeat':'reflect' if stage%2==0 else 'repeat',
            'L3_4way_connected_centers':count,'orb_candidates_22_138_y68_reachable_from_80_88':targets,
            'visual_coverage':coverage(stage,proposed[stage]),
            'baseline_visual_coverage':coverage(stage,worlds[stage])}
    metrics.append(metric)
# Build exact DASM replacement tables with preserved symbol names; no ROM implementation performed.
def da(b):return '$'+format(b,'02X')
knasm='; THE SKRAUN MAIN VI / GRAPHICS II : SOURCE_ONLY P1 REPLACEMENT, NOT BUILT\n'
knasm+='; Only replace 3 K1 17-byte data rows within the existing F7A8 block.\n'
knasm+='; Data order is bottom-first for ROM: index 0 is physical bottom. Index 16 is zero guard.\n'
knasm+='; Do not change Ranger R1 rows, pointer tables, REFP1, VDEL, or code.\n'
for nm,pose in (('K1NeutralBytes','neutral'),('K1WarningBytes','warning'),('K1StrikeBytes','strike')):
    knasm+=f'{nm}:\n    dc.b '+','.join(map(da,hexrow(K1[pose])[::-1]+[0]))+'\n'
(OUT/'KNIGHT_P1_DROPIN_SOURCE_ONLY.asm').write_text(knasm)
pfasm='; THE SKRAUN MAIN VI / GRAPHICS II : SOURCE_ONLY PF1 REPLACEMENT, NOT BUILT\n'
pfasm+='; 8 x 96 = 768 bytes, expected ORG $FA00..$FD00; no extra TIA writes.\n'
pfasm+='; Even stages have CTRLPF repeat: right PF1 at x96..128. Odd reflect: x112..144.\n'
pfasm+='        ORG $FA00\nPlayPF1:\n'
for i,world in enumerate(proposed):
    pfasm+=f'; Stage {i+1} {assign[i][0]} / {assign[i][1]} / '+('REFLECT' if i%2==0 else 'REPEAT')+'\n'
    for j in range(0,96,16):pfasm+='    dc.b '+','.join(map(da,world[j:j+16]))+'\n'
pfasm+='        ORG $FD00\n'
(OUT/'WORLD_PF1_DROPIN_SOURCE_ONLY.asm').write_text(pfasm)
# Ready for exact base bank3 copy/paste. No code/ROM edit in this generator.
fullro=[x for a in proposed for x in a]
rom_kn=''.join(f'{h:02x}' for p in ('neutral','warning','strike') for h in hexrow(K1[p])[::-1]+[0])
metadata={'status':'SOURCE_ONLY, USER REVIEW REQUIRED','baseline':{'pr':76,'commit':'bd499a0736a8ed09c9e733e90387188176870039','rom_sha256':'1170604965d062916b71b48335f5ffef089bf89b8eec0418f6b17b9582d82dc1'},
'scope':'only K1 sprites, PF1 and prospective collision notes; unchanged other actor bitmaps and code',
'world_pf1':{'bytes':768,'byte_order':'world0+0..95 sequential; first visible PF1 index92 at X184; each first row decrements by 2; color-control pairs at idx56/61','bytes_hex':[f'{b:02X}' for b in fullro],
'sha256':sha256(bytes(fullro)).hexdigest(),'old_sha256':sha256(bytes(raw)).hexdigest(),
'stages':[{'number':i+1,'mode':'reflect' if i%2==0 else 'repeat','top_motif':assign[i][0],'bottom_motif':assign[i][1],
'motif_source_top_first':{n:patterns[n] for n in assign[i]},'PF1_bytes_bottom_first_hex':[f'{b:02X}' for b in proposed[i]],
'original_collision_rectangles_game_y':[{'x0':a,'x1_exclusive':b,'y0':c,'y1_exclusive':d} for a,b,c,d in rects[i]],'metrics':metrics[i]} for i in range(8)]},
'knights':knight,'old_pr76_knights_bottom_first_hex':{k:[f'{v:02X}' for v in arr] for k,arr in original_knight.items()},
'Ranger_blobs_unmodified_sha256':sha256(bytes(sum([oldkn[x] for x in ('R1NeutralBytes','R1DrawBytes','R1ReleaseBytes')],[]))).hexdigest(),
'not_proven':'No DASM/Stella on new graphics; source-only BFS does not prove runtime motion/timing/collision; P1 multiplex flicker and sword logical reach not reverified.'}
(OUT/'GRAPHICS_AND_GEOMETRY_DATA.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
(OUT/'GEOMETRY_SOURCE_ONLY.json').write_text(json.dumps({'rects_unchanged':True,'stage_rects':rects,'L3_half_width':16,'L3_half_height':15,'L3_domain':{'x':[20,141],'y':[19,158]},'orb_centers':[(x,68) for x in OBX],
'metrics':metrics},indent=2)+'\n')
# Graphics source pixel previews
font=ImageFont.load_default()
def heading(im,text,ys=28):
    v=Image.new('RGB',(im.width,im.height+ys),(19,20,26));v.paste(im,(0,ys));ImageDraw.Draw(v).text((8,8),text,fill=(235,235,235),font=font);return v

def maskimg(rows,s=14,box=True,fg=BLUE,bg=(14,20,29)):
    p=Image.new('RGB',(8*s,len(rows)*s),bg);d=ImageDraw.Draw(p)
    for y,row in enumerate(rows):
        for x,ch in enumerate(row):
            if ch in ('#','1'):d.rectangle((x*s,y*s,(x+1)*s-1,(y+1)*s-1),fill=fg)
            if box:d.rectangle((x*s,y*s,(x+1)*s-1,(y+1)*s-1),outline=(43,54,66),width=1)
    return p
# Sprite comparison and GIF
for fam,poses in [('C_SHIELD_CONTOUR',K1),('C_SHIELD_SOLID',K2)]:
    for pose,rows in poses.items():
        im=maskimg(rows,s=18); heading(im,f'{fam} {pose} 8x16 SOURCE_ONLY').save(OUT/f'{fam}_{pose.upper()}_PIXELGRID.png')
        maskimg(rows,s=1,box=False).save(OUT/f'{fam}_{pose.upper()}_NATIVE_8x16.png')
        mirrored=[r[::-1] for r in rows];maskimg(mirrored,s=18).save(OUT/f'{fam}_{pose.upper()}_MIRRORED.png')
oldtop=[[f'{v:08b}' for v in oldkn[label][:16][::-1]] for label in ('K1NeutralBytes','K1WarningBytes','K1StrikeBytes')]
compare=Image.new('RGB',(3*184,480),(18,18,25));d=ImageDraw.Draw(compare)
for j,name in enumerate(['NEUTRAL','WARNING','STRIKE']):
    compare.paste(maskimg(oldtop[j],s=14),((184*j)+8,22));compare.paste(maskimg(K1[name.lower()],s=14),((184*j)+8,250))
    d.text((184*j+8,2),f'PR76 {name}',fill=(228,228,228),font=font)
    d.text((184*j+8,236),'MAIN VI K1 SOURCE_ONLY',fill=(228,228,228),font=font)
compare.save(OUT/'KNIGHT_PR76_VS_K1_SOURCE_ONLY.png')
# Review K1 and K2 on native background and as enlarged 4x/TV approx.
def showfamily(fam,poses):
    a=Image.new('RGB',(3*240,400),(21,21,26));d=ImageDraw.Draw(a)
    for j,pose in enumerate(('neutral','warning','strike')):
        a.paste(maskimg(poses[pose],s=14),(j*240+28,30))
        d.text((j*240+28,8),f'{fam} / {pose}',fill=(228,228,228),font=font)
        native=maskimg(poses[pose],s=1,box=False);a.paste(native.resize((16,32),Image.Resampling.NEAREST),(j*240+28,304))
        d.text((j*240+28,342),'8x16 source (2x shown)',fill=(210,210,210),font=font)
    a.save(OUT/f'{fam}_THREE_POSES_SOURCE_ONLY.png')
showfamily('C_SHIELD_CONTOUR',K1);showfamily('C_SHIELD_SOLID',K2)
framerate=[('neutral',270),('warning',267),('strike',150),('neutral',400)]
frames=[];dur=[]
for pose,ms in framerate:
    p=maskimg(K1[pose],s=20);p=heading(p,f'K1 {pose.upper()} | SOURCE_ONLY | {ms}ms',30);frames.append(p);dur.append(ms)
frames[0].save(OUT/'C_SHIELD_CONTOUR_SWORD_CYCLE_SOURCE_ONLY.gif',save_all=True,append_images=frames[1:],duration=dur,loop=0,disposal=2)
wframes=[heading(maskimg(K1[pose],s=20),f'K1 WALK {pose} SOURCE_ONLY') for pose in ('neutral','walk_B')];wframes[0].save(OUT/'K1_OPTIONAL_WALK_AB_SOURCE_ONLY.gif',save_all=True,append_images=wframes[1:],duration=[170,170],loop=0)
# Draw all 8 stages in native 160x184, 640x480 approximate display, halo, actor reference and collision overlays.
for i in range(8):
    curr=render(proposed[i],i); prev=render(worlds[i],i)
    curr.save(OUT/f'WORLD_{i+1}_NATIVE_160x184_SOURCE_ONLY.png')
    curr.resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_TV_640x480_SOURCE_ONLY.png')
    render(proposed[i],i,True).resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_GOLD_TV_SOURCE_ONLY.png')
    for lev in (1,2,3):actor_scene(proposed[i],i,lev).resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_ACTORS_L{lev}_SOURCE_ONLY.png')
    oldnew=Image.new('RGB',(1280,520),(15,15,20));dr=ImageDraw.Draw(oldnew)
    oldnew.paste(prev.resize((640,480),Image.Resampling.NEAREST),(0,30));oldnew.paste(curr.resize((640,480),Image.Resampling.NEAREST),(640,30))
    dr.text((8,8),f'WORLD {i+1} | PR76 SOURCE RECONSTRUCTION',fill='white',font=font)
    dr.text((648,8),'MAIN VI SOURCE_ONLY REFINEMENT',fill='white',font=font)
    oldnew.save(OUT/f'WORLD_{i+1}_BEFORE_AFTER_SAME_TV_SCALE.png')
    coll=curr.copy();d=ImageDraw.Draw(coll)
    for x0,x1,y0,y1 in rects[i]:d.rectangle((x0,y0+8,x1-1,y1+7),outline=(255,95,90),width=1)
    coll.resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_COLLISION_ENVELOPES_SOURCE_ONLY.png')
    # left/right visualization with original raw byte on left and exact kernel-mode transform on right
    half=curr.copy();dp=ImageDraw.Draw(half);dp.line((80,0,80,183),fill=(246,234,103))
    half.resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_PF1_REFLECT_REPEAT_EXACT_SOURCE_ONLY.png')
# 2x4 overview of eight worlds, stage color names and mode header
names=['SKOG 1','SKOG 2','BERG 1','BERG 2','DROM 1','DROM 2','NATT 1','NATT 2']
allim=Image.new('RGB',(4*320,2*390),(21,22,27));dd=ImageDraw.Draw(allim)
for i in range(8):
    x=i%4*320;y=i//4*390
    dd.text((x+8,y+7),f'{names[i]} - '+('REFLEKTERAD' if i%2==0 else 'UPPREPAD'),fill=(240,240,240),font=font)
    allim.paste(render(proposed[i],i).resize((320,372),Image.Resampling.NEAREST),(x,y+18))
allim.save(OUT/'ALL_EIGHT_WORLDS_MAIN_VI_SOURCE_ONLY.png')
# Montage actual prior frame vs proposed source-only (not implying same game state)
# Show skill-specific one glance for stage 2 and 8.
focus=Image.new('RGB',(2*420,2*510),(16,16,22));d=ImageDraw.Draw(focus)
for i,stage in enumerate((1,3,5,7)):
    x=(i%2)*420;y=(i//2)*510
    focus.paste(render(proposed[stage],stage).resize((400,465),Image.Resampling.NEAREST),(x+10,y+28))
    d.text((x+10,y+8),f'EVEN STAGE {stage+1}: PF1 REPEAT (SOURCE_ONLY)',fill='white')
focus.save(OUT/'EVEN_STAGES_2_4_6_8_SOURCE_ONLY.png')
# Individual motif swatches: isolate band of PF1 for one physical left-hand motif.
for i in range(8):
    for m,(lo,hi) in zip(('TOP','BOTTOM'),bands(worlds[i])):
        data=[0]*96
        for j in range(lo,hi+1):data[j]=proposed[i][j]
        im=render(data,i)
        # left half only: 16..48cc, source match bitmap
        ys=[2*(93-j) for j in range(hi,lo-1,-1)]
        ya=max(0,min(ys)-4); yb=min(184,max(ys)+6)
        crop=im.crop((10,ya,54,yb)); crop.resize((crop.width*8,crop.height*6),Image.Resampling.NEAREST).save(OUT/f'MOTIF_STAGE_{i+1}_{m}_SOURCE_ONLY.png')
print('generated',len(list(OUT.iterdir())),'visual / data files')
print('BYTE_SHA256',metadata['world_pf1']['sha256'],'OLD',metadata['world_pf1']['old_sha256'])
print('METRICS',json.dumps(metrics))

# --- MAIN VI 2026-11-27 second-pass package: original references, 2 shield variants, full battle staging ---
PREVIOUS = json.loads((ROOT/'reference'/'PREVIOUS_MAIN_VI_GRAPHICS_SOURCE.json').read_text())
prevbyte=[int(h,16) for h in PREVIOUS['world_pf1']['bytes_hex']]
assert len(prevbyte)==768 and sha256(bytes(prevbyte)).hexdigest() == '5ed1067c44dba05bb4da19920c659167f1828d99ec5b52210f634a14b72c0ec8'
original_u1=json.loads((ROOT/'reference'/'U1_LEG1_UNCHANGED_SOURCE.json').read_text())
assert original_u1['one_candidate_U1_LEG1']['A']==U1_A, 'The user-approved source bitmap must remain unchanged'
modified=[sum(a!=b for a,b in zip(proposed[i],prevbyte[i*96:(i+1)*96])) for i in range(8)]
assert all(modified[i]==0 for i in (0,2,4,6)), f'Expected stages 1/3/5/7 to retain past art: {modified}'
assert all(modified[i]>0 for i in (1,3,5,7)),f'Targeted even world refinements must be source-only byte edits: {modified}'
assert len(fullro)==768 and all(len(proposed[i])==96 for i in range(8))
assert all(not any((x & 0x80)!=0 for x in proposed[i]) for i in (1,3,5,7)), 'No even-world PF1 leftmost mirror collision cell'
assert len(oldkn)==6 and all(len(x)==17 for x in oldkn.values())
assert sha256(bytes(sum([oldkn[x] for x in ('R1NeutralBytes','R1DrawBytes','R1ReleaseBytes')],[]))).hexdigest() == metadata['Ranger_blobs_unmodified_sha256']

# Knight morphology: all 8x16 top-first. The warned raised blade and active horizontal blade
# always connect to body by 4-neighbourhood. This is a bitmap-only property, not TIA timing proof.
def components4(rows):
    cells={(x,y) for y,row in enumerate(rows) for x,ch in enumerate(row) if ch=='#'}
    found=[]
    while cells:
        init=cells.pop(); todo=[init]; cur={init}
        while todo:
            x,y=todo.pop()
            for dx,dy in ((0,1),(0,-1),(1,0),(-1,0)):
                pt=(x+dx,y+dy)
                if pt in cells:
                    cells.remove(pt);cur.add(pt);todo.append(pt)
        found.append(len(cur))
    return sorted(found,reverse=True)
# A pose may contain detached boot contact only if under 8-bit rendering constraints; flag any islands.
component_audit={fam:{pose:components4(rows) for pose,rows in candidate.items()} for fam,candidate in [('C_SHIELD_CONTOUR',K1),('C_SHIELD_SOLID',K2)]}

def attrib_parts(rows,pose):
    body=[list('.'*8) for _ in range(16)]
    shield=[list('.'*8) for _ in range(16)]
    sword=[list('.'*8) for _ in range(16)]
    for y,row in enumerate(rows):
        for x,pixel in enumerate(row):
            if pixel!='#':continue
            # Shield left of the torso, explicitly no gameplay block mechanic.
            if 6<=y<=11 and x<=1:which=shield
            # P1 sword is down while walking, up during warning, and extended at strike.
            elif pose=='warning' and x==7 and y<=6:which=sword
            elif pose=='strike' and 8<=y<=9 and x>=6:which=sword
            elif pose.startswith('walk') or pose=='neutral':
                which=sword if (x==7 and 10<=y<=13) or (x>=6 and y==10) else body
            else:which=body
            which[y][x]='#'
    def conv(a):return [''.join(row).replace('#','1').replace('.','0') for row in a]
    allparts=[body,shield,sword]
    assert all(sum(a[y][x]=='#' for a in allparts)==(rows[y][x]=='#') for y in range(16) for x in range(8))
    return dict(zip(('body','shield','sword'),map(conv,allparts)))
knight_extra={}
for family,poses in [('C_SHIELD_CONTOUR',K1),('C_SHIELD_SOLID',K2)]:
    knight_extra[family]={}
    for pose,rows in poses.items():
        knight_extra[family][pose]={'component_masks':attrib_parts(rows,pose),'connected_components_4':components4(rows),
        'source_width':8,'source_height':16,'pose_foot_anchor':{'x_center':4,'baseline_row':15},
        'rom_bottom_first_hex':[da(v) for v in hexrow(rows)[::-1]]+['$00'],
        'top_first_binary':[r.replace('#','1').replace('.','0') for r in rows],
        'mirror_top_first_binary':[r.replace('#','1').replace('.','0')[::-1] for r in rows]}
    knight_extra[family]['mirror_rule']='reverse exactly all 8 bit positions per source row; hardware REFP1 must remain original'
(OUT/'SHIELD_SWORD_BODY_LAYERS.json').write_text(json.dumps(knight_extra,ensure_ascii=False,indent=2)+'\n')

# Alternatives for exactly the same three existing symbol slots. Never try to assemble these simultaneously.
knasm_alt='; ALTERNATIVE only: replace original K1 3 x 17-byte tables after a MAIN visual choice.\n'
knasm_alt+='; C_SHIELD_SOLID, SOURCE_ONLY; NOT simultaneously with C_SHIELD_CONTOUR.\n'
for symbol,pose in (('K1NeutralBytes','neutral'),('K1WarningBytes','warning'),('K1StrikeBytes','strike')):
    knasm_alt+=symbol+':\n    dc.b '+','.join(map(da,hexrow(K2[pose])[::-1]+[0]))+'\n'
(OUT/'C_SHIELD_SOLID_ALTERNATIVE_3_POSE_DROPIN.asm').write_text(knasm_alt)

walkasm='; OPTIONAL WALK_B, NOT DROP-IN: requires new enemy art pointer/selector; 17 bytes plus code/pointers.\n'
walkasm+='; Existing F7A8..F820 contains 6*17=102 actor bytes, ds 9 = 111, + 9 slack =120.\n'
walkasm+='; New 17B mask does not fit entire 17B at same location (only 9B spare); relocation mandatory.\n'
for nm,pose in [('CShieldContourWalkB','walk_B'),('CShieldSolidWalkB','walk_B')]:
    rows=(K1 if 'Contour' in nm else K2)[pose]
    walkasm+=nm+':\n    dc.b '+','.join(map(da,hexrow(rows)[::-1]+[0]))+'\n'
(OUT/'WALK_B_OPTIONAL_NOT_DIRECT_DROPIN.asm').write_text(walkasm)

# Audit source-bitmap silhouette geometry vs original PR76 four AABB rectangles. Screen Y offset
# +8 is a SOURCE_ONLY mapping grounded in first physical visible kernel index92; full Stella proof pending.
def phantom(stage,dat):
    canvas=matrix(dat,stage+1).convert('L')
    p=canvas.load()
    collider=painted=phantom_pixels=outside=0
    for y in range(184):
        for x in range(160):
            c=any(x0<=x<x1 and y0+8<=y<y1+8 for x0,x1,y0,y1 in rects[stage]);v=p[x,y]!=0
            if c:collider+=1
            if v and c:painted+=1
            if v and not c:outside+=1
            if c and not v:phantom_pixels+=1
    assert painted+phantom_pixels==collider
    return {'collision_AABB_area_pixel_cells':collider,'painted_inside':painted,'visible_outside_collision':outside,
            'solid_but_invisible_inside':phantom_pixels,'solid_but_invisible_pct':round(100*phantom_pixels/collider,1)}
full_collision=[dict(stage=i+1,mode='reflect' if i%2==0 else 'repeat',old=phantom(i,worlds[i]),
                    previous=phantom(i,prevbyte[i*96:(i+1)*96]),proposed=phantom(i,proposed[i]),
                    unchanged_collision_rects=[list(rc) for rc in rects[i]]) for i in range(8)]
assert all(x['proposed']['visible_outside_collision']==0 for x in full_collision)

# L1/L2/L3 logical source movement: 4-connected grid is a *conservative* reachability check
# (actual movement 8-dir, sliding; no joystick frames or ROM compiled).
DOMAINS={1:(8,153,10,167,4,6),2:(12,149,14,163,8,10),3:(20,141,19,158,16,15)}
def valid_level(x,y,stage,level):
    a,b,c,d,w,h=DOMAINS[level]
    if not (a<=x<b and c<=y<d):return False
    for x0,x1,y0,y1 in rects[stage]:
        if x+w>=x0 and x-w<x1 and y+h>=y0 and y-h<y1:return False
    return True

def test_paths(stage,level):
    origin=(80,88)
    assert valid_level(*origin,stage,level)
    work=deque([origin]);seen={origin}
    while work:
        x,y=work.popleft()
        for dx,dy in ((-1,0),(1,0),(0,-1),(0,1)):
            p=(x+dx,y+dy)
            if p not in seen and valid_level(*p,stage,level):seen.add(p);work.append(p)
    orb={str(x):{'center_valid':valid_level(x,68,stage,level),'reachable':(x,68) in seen} for x in (22,138)}
    return {'connected_center_count':len(seen),'orb':orb,'center_safe':origin in seen}
reachability=[dict(stage=i+1,levels={str(l):test_paths(i,l) for l in (1,2,3)}) for i in range(8)]
assert all(r['levels']['3']['orb']['22']['reachable'] and r['levels']['3']['orb']['138']['reachable'] for r in reachability)

geom_report={'status':'SOURCE_ONLY, 4-way reachability and PF1 screen y offset +8 model, NOT live collisions',
             'stage_rects_game_logic':[rects[i] for i in range(8)],'source_pixel_vs_collision_both_directions':full_collision,
             'levels_8x12_16x20_32x30_as_current_runtime_candidates':reachability,
             'note':'Ranger shotlines, growth at moving orb, actual physical Stella beam and collision events not established by this model.'}
(OUT/'WORLD_GEOMETRY_INVISIBLE_SOLIDS_AUDIT.json').write_text(json.dumps(geom_report,ensure_ascii=False,indent=2)+'\n')

# Original physical source for honest source comparisons. Triple view at exactly same rendered scale.
for i in range(8):
    trio=[render(worlds[i],i),render(prevbyte[i*96:(i+1)*96],i),render(proposed[i],i)]
    panel=Image.new('RGB',(3*320,410),(14,17,21));draw=ImageDraw.Draw(panel)
    headers=[f'PR76/C original: stage{i+1}',f'Previous GRAPHICS II: stage{i+1}',f'Current SOURCE_ONLY: stage{i+1}']
    for j,img in enumerate(trio):
        panel.paste(img.resize((320,368),Image.Resampling.NEAREST),(j*320,32))
        draw.text((j*320+5,8),headers[j],fill=(238,238,238),font=font)
    panel.save(OUT/f'WORLD_{i+1}_PR76_PREVIOUS_FINAL_TRIPLE.png')

# Representative static mockup. Under actual PR76, L3 aura and enemies time-share P1;
# this presentation intentionally shows all objects at once and cannot be interpreted as TIA proof.
ROM_SIZES={1:(1,12,14,21),2:(2,20,28,35),3:(4,30,56,52)}
RANGER_16=[''.join(str(int(bool(int(bit)))) for bit in f'{v:08b}') for v in oldkn['R1NeutralBytes'][:16][::-1]]
def drawbattle(stage,level,aura=False):
    im=render(proposed[stage],stage).copy()
    px=im.load()
    factor,h,auraw,aurah=ROM_SIZES[level]
    cx=80;cy=95
    if aura:
        # Approximate source-sized filled aura shape only, not byte-exact Stella TIA halo.
        ImageDraw.Draw(im).ellipse((cx-auraw//2,cy-aurah//2,cx+auraw//2-1,cy+aurah//2-1),fill=GOLD)
    # Player from exact U1 approved rows, nearest-neighbour scaled only.
    rows=[f'{int(row,2):08b}' for row in U1_A]
    native=Image.new('RGB',(8,12), (0,0,0));blit_sprite(native,rows,0,0,GRAY)
    scaled=native.resize((8*factor,h),Image.Resampling.NEAREST)
    for yy in range(h):
        for xx in range(8*factor):
            c=scaled.getpixel((xx,yy))
            if c!= (0,0,0):
                x=cx-4*factor+xx;y=cy-h//2+yy
                if 0<=x<160 and 0<=y<184:px[x,y]=c
    # Static composition: two different actors sharing same underlying sprite data and time-shared P1.
    blit_sprite(im,K1['neutral'],51,79,BLUE)
    blit_sprite(im,K1['warning'],115,94,BLUE)
    blit_sprite(im,RANGER_16,140,71,RANGER[stage])
    # Orb is BL 2x/4px at x22 and different height; arrow M1 2px x 3 rows (illustrative).
    ImageDraw.Draw(im).ellipse((19,64,23,69),fill=GOLD)
    ImageDraw.Draw(im).rectangle((132,98,133,100),fill=RANGER[stage])
    return im
for i in range(8):
    for level in (1,2,3):
        out=drawbattle(i,level,False)
        out.resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_BATTLE_L{level}_SOURCE_ONLY.png')
    out=drawbattle(i,3,True)
    out.resize((640,480),Image.Resampling.NEAREST).save(OUT/f'WORLD_{i+1}_BATTLE_L3_AURA_COMPOSITE_SOURCE_ONLY.png')

# Compact two-row 4x2 visual of complete scenes. All 8 have exact proposed PF1 map byte projection.
mat=Image.new('RGB',(4*320,2*380),(12,16,20));ed=ImageDraw.Draw(mat)
for i in range(8):
    x=(i%4)*320;y=(i//4)*380
    ed.text((x+7,y+3),f'{names[i]} | SOURCE_ONLY L3 composited',fill=(236,236,236),font=font)
    mat.paste(drawbattle(i,3,False).resize((320,368),Image.Resampling.NEAREST),(x,y+15))
mat.save(OUT/'ALL_EIGHT_BATTLE_STAGE_PREVIEWS_SOURCE_ONLY.png')

levpanel=Image.new('RGB',(3*320,400),(14,17,20));ld=ImageDraw.Draw(levpanel)
for lev in (1,2,3):
    levpanel.paste(drawbattle(0,lev,False).resize((320,368),Image.Resampling.NEAREST),((lev-1)*320,30))
    ld.text(((lev-1)*320+8,8),f'FOREST 1 / Skraun L{lev} / SOURCE_ONLY',fill='white',font=font)
levpanel.save(OUT/'SKRAUN_L1_L2_L3_WITH_SHIELD_KNIGHTS_SOURCE_ONLY.png')

# Audit display: body/shield/sword attribution in exact 8x16 masks, helps guide logical hitboxes later.
colorsParts={'body':(161,210,245),'shield':(75,150,198),'sword':(247,230,155)}
for fam in ('C_SHIELD_CONTOUR','C_SHIELD_SOLID'):
    stage=Image.new('RGB',(4*200,430),(9,18,27));od=ImageDraw.Draw(stage)
    for index,pose in enumerate(('neutral','walk_B','warning','strike')):
        comps=knight_extra[fam][pose]['component_masks']
        x0=index*200+10;y0=34
        od.text((x0,5),f'{fam} {pose}',fill='white',font=font)
        for ty in range(16):
            for tx in range(8):
                for part in ('body','shield','sword'):
                    if comps[part][ty][tx]=='1':
                        od.rectangle((x0+tx*19,y0+ty*19,x0+(tx+1)*19-1,y0+(ty+1)*19-1),fill=colorsParts[part]);break
                od.rectangle((x0+tx*19,y0+ty*19,x0+(tx+1)*19-1,y0+(ty+1)*19-1),outline=(35,51,65),width=1)
    stage.save(OUT/f'{fam}_BODY_SHIELD_SWORD_SEGMENTATION_SOURCE_ONLY.png')

# Animated original-size + magnified readout. All exact source rows and bit-mirror, no AI art.
for fam,poses in [('C_SHIELD_CONTOUR',K1),('C_SHIELD_SOLID',K2)]:
    for gifname,states,durations in [
        ('WALK_GIF_SOURCE_ONLY',[('neutral',160),('walk_B',160)],None),
        ('ATTACK_GIF_SOURCE_ONLY',[('neutral',230),('warning',267),('strike',150),('neutral',300)],None),
        ('COMPLETE_GIF_SOURCE_ONLY',[('neutral',160),('walk_B',160),('neutral',160),('warning',267),('strike',150),('neutral',350)],None),
    ]:
        gifframes=[];gifdur=[]
        for state,dur in states:
            main=maskimg(poses[state],s=18)
            small=maskimg(poses[state],s=1,box=False).resize((16,32),Image.Resampling.NEAREST)
            comp=Image.new('RGB',(176,368),(14,20,29));dd=ImageDraw.Draw(comp)
            dd.text((7,5),f'{fam} {state}',fill='white',font=font)
            comp.paste(main,(12,33));comp.paste(small,(142,326))
            gifframes.append(comp);gifdur.append(dur)
        gifframes[0].save(OUT/f'{fam}_{gifname}.gif',save_all=True,append_images=gifframes[1:],duration=gifdur,loop=0,disposal=2,optimize=False)
    for pose,rows in poses.items():
        # Explicit mirrored native PNG, no row reversal.
        maskimg([r[::-1] for r in rows],s=1,box=False).save(OUT/f'{fam}_{pose.upper()}_MIRROR_NATIVE_8x16.png')

# Three-way concept reference vs source-design alternative, true source pixels labelled.
reference=Image.open(ROOT/'reference'/'SKRAUN_RIDDARREFERENS_SKOLD_SVARD_GANG.png').convert('RGB')
large=Image.new('RGB',(960,540),(12,17,25));imgdraw=ImageDraw.Draw(large)
refshot=reference.resize((484,484),Image.Resampling.NEAREST)
large.paste(refshot,(10,40));imgdraw.text((10,12),'ANVÄNDARENS VISUELLA REFERENS (EJ ROM)',fill='white',font=font)
for idx,(name,rows) in enumerate([('C_SHIELD_CONTOUR',K1['neutral']),('C_SHIELD_SOLID',K2['neutral'])]):
    x=512+idx*214
    large.paste(maskimg(rows,s=23),(x,60));imgdraw.text((x,12),name,fill='white',font=font)
    im=maskimg(rows,s=1,box=False).resize((16,32),Image.Resampling.NEAREST)
    large.paste(im,(x,460));imgdraw.text((x+22,464),'Native width x1',fill='white',font=font)
large.save(OUT/'USER_REFERENCE_VS_TWO_8x16_CANDIDATES_SOURCE_ONLY.png')

# Montage of red outlines (existing exact AABB) vs visual pixel masks. Keep labels useful.
collisionMontage=Image.new('RGB',(4*320,2*388),(14,16,19));cd=ImageDraw.Draw(collisionMontage)
for i in range(8):
    pic=Image.open(OUT/f'WORLD_{i+1}_COLLISION_ENVELOPES_SOURCE_ONLY.png')
    x=i%4*320;y=i//4*388
    label=f'{names[i]} unseen solid: {full_collision[i]["proposed"]["solid_but_invisible_pct"]}%'
    cd.text((x+6,y+5),label,fill='white',font=font)
    collisionMontage.paste(pic.resize((320,368),Image.Resampling.NEAREST),(x,y+18))
collisionMontage.save(OUT/'ALL_EIGHT_COLLISION_OVERLAYS_SOURCE_ONLY.png')

print('MAIN_VI_EXTRA',len(list(OUT.iterdir())),'files', 'world SHA',sha256(bytes(fullro)).hexdigest(),
      'changes previous',modified,'L3 ALL',all(x['levels']['3']['orb']['22']['reachable'] for x in reachability),
      'components',component_audit)
