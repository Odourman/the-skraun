#!/usr/bin/env python3
"""Static SOURCE_ONLY validation. Does NOT build a ROM or run Stella.
Run python tools/generate.py .; python tools/validate.py .
"""
import re, json, sys, hashlib
from pathlib import Path
from PIL import Image
ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
ART=ROOT/'art'
assert (ROOT/'baseline'/'PR76_C_BANK3_UNMODIFIED.asm').is_file()
prior=json.loads((ROOT/'reference'/'PREVIOUS_MAIN_VI_GRAPHICS_SOURCE.json').read_text())
info=json.loads((ART/'GRAPHICS_AND_GEOMETRY_DATA.json').read_text())
audit=json.loads((ART/'WORLD_GEOMETRY_INVISIBLE_SOLIDS_AUDIT.json').read_text())
masks=json.loads((ART/'SHIELD_SWORD_BODY_LAYERS.json').read_text())

def read_dc_b(path):
    out=[]
    for line in Path(path).read_text().splitlines():
        raw=line.split(';',1)[0]
        if re.match(r'^\s*dc\.b\s+',raw):
            out += [int(val[1:],16) if val.startswith('$') else int(val,10) for val in re.split(r'\s*,\s*',raw.split('dc.b',1)[1].strip())]
    return out
worlddata=[int(v,16) for v in info['world_pf1']['bytes_hex']]
assert len(worlddata)==768
assert read_dc_b(ART/'WORLD_PF1_DROPIN_SOURCE_ONLY.asm')==worlddata
assert hashlib.sha256(bytes(worlddata)).hexdigest()==info['world_pf1']['sha256']
prev=[int(v,16) for v in prior['world_pf1']['bytes_hex']]
assert len(prev)==768
assert [sum(a!=b for a,b in zip(prev[i*96:(i+1)*96],worlddata[i*96:(i+1)*96])) for i in range(8)]==[0,11,0,3,0,21,0,2]
assert all(len(stage['PF1_bytes_bottom_first_hex'])==96 for stage in info['world_pf1']['stages'])
assert all((v&0x80)==0 for stage in [1,3,5,7] for v in worlddata[stage*96:stage*96+96])
assert len(audit['source_pixel_vs_collision_both_directions'])==8
assert all(row['proposed']['visible_outside_collision']==0 for row in audit['source_pixel_vs_collision_both_directions'])
assert all(p['levels']['3']['orb'][str(pos)]['reachable'] for p in audit['levels_8x12_16x20_32x30_as_current_runtime_candidates'] for pos in [22,138])
assert all(p['levels'][str(level)]['orb'][str(pos)]['reachable'] for p in audit['levels_8x12_16x20_32x30_as_current_runtime_candidates'] for level in [1,2,3] for pos in [22,138])
for family in ('C_SHIELD_CONTOUR','C_SHIELD_SOLID'):
    m=masks[family]
    for pose in ('neutral','walk_B','warning','strike'):
        art=m[pose]
        rows=art['top_first_binary'];assert len(rows)==16 and all(len(r)==8 and set(r)<={'0','1'} for r in rows)
        assert art['connected_components_4']==[sum(int(c) for r in rows for c in r)], (family,pose,'fragment')
        assert art['mirror_top_first_binary']==[r[::-1] for r in rows]
        assert art['rom_bottom_first_hex'] == [f'${int(r,2):02X}' for r in rows[::-1]]+['$00']
        native=Image.open(ART/f'{family}_{pose.upper()}_NATIVE_8x16.png').convert('RGB')
        assert native.size==(8,16)
        for y,row in enumerate(rows):
            for x,ch in enumerate(row):
                expected=(151,202,249) if ch=='1' else (14,20,29)
                assert native.getpixel((x,y))==expected,(family,pose,x,y,native.getpixel((x,y)))
    # All poses have exact same physical foot bitmask in x=0..6, x7 changes only sword.
    for pose in ('warning','strike'):
        assert [r[:7] for r in m[pose]['top_first_binary'][-4:]]==[r[:7] for r in m['neutral']['top_first_binary'][-4:]]
    # Main 3-pose drop-in has exactly 51 bytes and alternative also 51 bytes.
assert len(read_dc_b(ART/'KNIGHT_P1_DROPIN_SOURCE_ONLY.asm'))==51
assert len(read_dc_b(ART/'C_SHIELD_SOLID_ALTERNATIVE_3_POSE_DROPIN.asm'))==51
assert len(read_dc_b(ART/'WALK_B_OPTIONAL_NOT_DIRECT_DROPIN.asm'))==34
expected=sum([[int(h[1:],16) for h in masks['C_SHIELD_CONTOUR'][p]['rom_bottom_first_hex']] for p in ['neutral','warning','strike']],[])
assert read_dc_b(ART/'KNIGHT_P1_DROPIN_SOURCE_ONLY.asm')==expected
orig=ROOT/'reference'/'U1_LEG1_UNCHANGED_SOURCE.json'
u1=json.loads(orig.read_text())['one_candidate_U1_LEG1']
assert len(u1['A'])==len(u1['B'])==12 and all(len(q)==8 for q in u1['A']+u1['B'])
# R1 source is unchanged at the original three symbols because we provide only replacement K1 tables.
assert 'R1NeutralBytes:' not in (ART/'KNIGHT_P1_DROPIN_SOURCE_ONLY.asm').read_text()
print('SOURCE_ONLY_STATIC_PASS',json.dumps({'stages':8,'motifs':16,'pf_bytes':768,'knight_candidates':2,'poses_each':4,'3pose_bytes':51,'optional_walk_B_bytes':17,'source_pixel_outside_aabb':0,'L1_L2_L3_orb_grid_path':True,'sword_and_feet_connected':True,'rom_executed':False}))
