# MAIN VI → GRAPHICS II | Fullständig grafikförfining | 2026-11-27

**Klass: SOURCE_ONLY / visuella kandidater för MAIN:s och användarens beslut.** Inget nytt ROM-bygge, ingen Stella-verifiering, ingen merge, ingen gameplayändring.

## Frysta liveankare
- GitHub PR76/C (draft, ej merge): https://github.com/Odourman/the-skraun/pull/76
- Källcommit `bd499a0736a8ed09c9e733e90387188176870039`.
- ROM SHA256 `1170604965d062916b71b48335f5ffef089bf89b8eec0418f6b17b9582d82dc1`, 16384 byte F6 NTSC, faktiskt kontrollerad från äldre leverans.
- PR76 bank3 Git blob `8d839fee0eb4ec4ef9708490a25672b5a4819b13`, bank0 `a25e67b9b56a3ba8eea319c21f2385e2d925efac`.
- Föregående grafikgren `graphics/mainvi-knight-world-refine-20261127`, commit `9775ae5df567e8ff2daf2277a597771eaa76b5bd`.
- Användarens huvudreferens `reference/SKRAUN_RIDDARREFERENS_SKOLD_SVARD_GANG.png` och källskiss `reference/SKRAUN_C_SKOLD_GANG_8x16.json` är kopior från explicit bifogad ZIP.
- Original U1-LEG1 förblir oförändrad och finns som referens `reference/U1_LEG1_UNCHANGED_SOURCE.json`. Käll- och frysankare: https://github.com/Odourman/the-skraun/blob/graphics/u1-leg1-caprine-gait-20261116/graphics/u1_leg1/SOURCE_U1_LEG1.json


## Rekommenderad riddare
**C_SHIELD_CONTOUR**, den 8×16-kandidat som följer användarens senaste medeltida referens med horisontellt visir, separat sköldform på vänster arm, sammanhängande högervapen och två gångsteg. Sköldkanten använder endast transparenta bitar, inte ny färg eller TIA-objekt. Alternativet **C_SHIELD_SOLID** har mindre sköldavgränsning och är något tyngre i silhuetten. Båda har WALK_A, WALK_B, WARNING och STRIKE samt exakta horisontella spegelbilder. Separat färg för svärd/sköld är inte implementerad eller föreslagen.

**Praktisk begränsning:** Även den förbättrade silhuetten är bara åtta P1-kolumner bred. Ett verkligt långt utfällt svärd kan inte ritas längre än P1-ytan utan extra TIA-resurs eller flyttad P1-position (förändrad renderer). Under normal gång syns svärdet nedsänkt; under förvarning syns det höjt; i slagpositionen är klingan utsträckt i kroppens höjd, men kan inte täcka hela den logiska träffavståndet.

**Direkt bytebar del:** valda WALK_A/neutral + WARNING + STRIKE = tre nuvarande 17-byte P1-masker. En ny WALK_B kräver ROM-kod, dataplats, pekare och riktig rasterkontroll. Hela fjärde masken ryms INTE i befintlig oförändrad F7A8-F820-maskregion, där 6×17 befintliga poser + nio utfyllnadsbyte lämnar endast nio oanvända byte innan nästa ORG.

## Alla åtta världar
De föregående bra formerna från bana 1, 3, 5, 7 behålls **byte-identiskt**. Alternativa banor 2/4/6/8 har förbättrade egna trädkronor/barrträd, bergstoppar, portal/spiral och ruinprofil. Samma färgregister, reflexionsläge, 96 byte/bana och stränga öppna passager. Ändrade byte jämfört med föregående grafikpaket: `[0, 11, 0, 3, 0, 21, 0, 2]`, totalt **37 av 768**. Ingen ny RAM eller synlig TIA-skrivning för de föreslagna PF-tabellerna.

**PF1 SHA256:** `8ee7ac1ee211a84fd9101b105ce86c3b08d412cc02db50e34f5af41678a4826b`. Världstabellen är 768 byte och kan ersätta det befintliga `PlayPF1`-blocket i bank3 utan ändrad tabellstorlek eller rendererkod. Dock är riktiga Stella-bilder och byggbevis fortfarande otestade.

## Geometrisk risk – även när grafiken är korrekt
Båda riktningar kontrollerades: målade PF1-celler utanför AABB och osynliga AABB-solider. Noll målade pixlar ligger utanför källmodellens AABB, men **osynliga solida delar återstår** under träd, bågar och spiralhål. De kan inte avlägsnas med enbart PF1-byte när spelkoden fortfarande använder fyra grova rektanglar per bana.

| Bana | TIA PF-läge | Målade celler utanför AABB | AABB-pixlar som saknar synlig grafik |
| --- | --- | ---: | ---: |
| 1 | reflect | 0 | 42.4% |
| 2 | repeat | 0 | 44.9% |
| 3 | reflect | 0 | 16.7% |
| 4 | repeat | 0 | 14.7% |
| 5 | reflect | 0 | 37.8% |
| 6 | repeat | 0 | 38.3% |
| 7 | reflect | 0 | 9.3% |
| 8 | repeat | 0 | 10.6% |

**Källbaserad rörlighet:** fyrvägs-BFS med PR76:s befintliga `WorldRects` från centrum `(80,88)` når båda möjliga orbcentrumen `(22,68)` och `(138,68)` på L1/L2/L3 för samtliga banor. Dessa är logiska koordinater och källmodell, inte uppmätt in-game rörelse eller faktisk tillväxtsäkert speltest. Kollisionsmodellen tillämpar halvbredd/halvhöjd L1 4×6, L2 8×10, L3 16×15, som i den frysta ROM-kandidaten; inga nya nivåmått godkänns här.

## Tidsskillnad och synlighetsbudget
PR76:s `bank0.asm` initierar `K1Warn=#16`, `K1Strike=#9` och `K1Rest=#24` (NTSC-ticks), ungefär 0,267s / 0,150s / 0,400s vid 60Hz. Äldre beslutad avsikt var ~0,4s varning och ~1s vila. Dessa är inte samma tider. GRAPHICS ändrar inga timers. GIF:ar visar ungefär PR76-tider för illustration, inte provad runtime.

P1 är delad mellan två riddare och Ranger. P1 lånas ibland till L3-aura, BL är orb och M1 är Ranger-pil. Förvarningen får GOLD `COLUP1=$2E`, aktivt hugg ljusvarm `$46`, neutral rustning `$9E` enligt PR76; svärd och sköld är samma P1-färg. Inget grafiskt byte kan bevisa tre fiender samtidig eller förbättra flimmer under pågående aura.

## MAIN:s föreslagna val
1. Granska och välj **C_SHIELD_CONTOUR** mot **C_SHIELD_SOLID** estetiskt; jämför användarreferensen och originalstorlek, inte enbart zoom.
2. Ta ställning till samma 768-byte PF1-tabeller, och acceptera eller prioritera osynliga AABB-områden som ett separat senare kollisionsuppdrag.
3. Auktorisera sedan vid behov en **separat liten ROM-integration**, först tre maskbyten + PF1 som exakt går in, sedan gångmask/pointer/posekod under eget scope. Gör DASM/Stella-beam-, VDEL- och 262-linjetest, hantera färgkontrast och faktiskt svärdsavstånd, gå vidare endast vid sanningsenligt resultat.

**STOP:** Detta är GRAPHICS II. Ingen ROM DEVELOPMENT-order skapas automatiskt och ingen oberoende Verification utförs.
