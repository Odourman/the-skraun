# Exakta binära bitmaps och TIA-resurser

Källor: fryst PR76 bank3/0 och bifogad 8×16-användarskiss. Allt i `art/` är SOURCE_ONLY.

## Masker och byteorder
`art/GRAPHICS_AND_GEOMETRY_DATA.json` + `art/SHIELD_SWORD_BODY_LAYERS.json` innehåller både 8×16 top-first, speglade masker, ROM bottom-first + `$00` och uppdelad kropp/sköld/svärd. Rekommenderad riddarfamilj: `C_SHIELD_CONTOUR`, alternativ `C_SHIELD_SOLID`. Båda har 4 unika masker och en tillhörande 8×16 originalstorleks-PNG per pose.

Källformat: x0 = bit7 (vänster), x7 = bit0 (höger); ingen färg per pixel. Riddarens sköld är **rent grafisk**, utan fysisk blockering. Svärdsriktningen är en ritad pose; räckvidden stannar inom P1:s åtta klockor. VDEL ger en fysisk rad förskjutning som inte kan bestyrkas av dessa source-only-filer.

## Världstabeller och bitreflektion
`art/WORLD_PF1_DROPIN_SOURCE_ONLY.asm` innehåller 768 exakta byte och använder den gamla `PlayPF1`-symbolen. PF1 bit7 är första cellen efter PF0. Vänster halva: x16..47, jämn `CTRLPF` repetition x96..127; udda reflektionsläge x112..143. I jämna banor är bit7=0, så synliga objekt börjar x20 respektive x100, i linje med dagens fyra AABB-rektanglar. Varje PF1-byte motsvarar två 6507/TIA-scanlines och 4 colour clocks per bit. Den frysta loopen börjar X=184 och läser PF-index 92, inte 93. I de två särskilda färgradparen (PF-index61 och56) nollställs PF1. Original kerneln är oförändrad.

Nya PF1 SHA256: `8ee7ac1ee211a84fd9101b105ce86c3b08d412cc02db50e34f5af41678a4826b`. Fyra banor 1,3,5,7 är källmässigt byte-identiska mot förra grafikleveransen. Ändrade världar 2,4,6,8: 11,3,21,2 byte.

## TIA-registerfärger i PR76
- P0 Skraun `$0C`, grå.
- P1 riddare neutral `$9E` ljusblå, förvarning `$2E` guld, hugg `$46` varm varningsfärg.
- Världs-PF och Ranger P1-kamouflage: skog `$C6/$C8`, berg `$86/$88`, dröm `$66/$68`, natt `$82/$84`. Exakta RGB beror på Stella/NTSC-palettval.
- Halo/PF aktiv `$2E`; BL-orb delar PF-färg. Ranger-pilen M1 delar P1-färg.
- Natt `$82/$84` mot mörk bakgrund bedöms som läsbart i SOURCE_ONLY men måste bedömas i autentisk Stella. Ingen paletteändring gjord.

## Träffar och animation
PR76:s aktuella logiska svärdgränser i bank0: `SwordBodyX: 0,9,13,19`, `SwordBodyY: 0,7,10,13` (nivå0..3). Det finns ingen pixel-per-pixel träffmask med enbart P1-data. Vår source-only `C_SHIELD_CONTOUR` är visuellt max 8 klockor bred, så träffavståndet är större än klingans bild. Ingen logisk justering ingår.

Timers i PR76 `K1Warn=#16`, `K1Strike=#9`, `K1Rest=#24`; omkring 0,267s, 0,150s, 0,400s vid 60 Hz. Detta avviker från äldre designönskemål om cirka 0,4s varning och 1s återhämtning. GRAPHICS ändrar ingen timer.

Original ROM-data är inte byggd om; detta är ingen oberoende Verification.
