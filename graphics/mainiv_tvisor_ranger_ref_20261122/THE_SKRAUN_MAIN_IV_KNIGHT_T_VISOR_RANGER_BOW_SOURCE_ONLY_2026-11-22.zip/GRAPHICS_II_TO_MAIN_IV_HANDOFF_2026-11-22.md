# THE SKRAUN — GRAPHICS II → MAIN IV

**2026-11-22 | Deliverable: Knight K1 T-visor + Ranger R1 bow**

**Authority:** user-supplied MAIN IV explicit **SOURCE_ONLY** graphics order; no ROM implementation, no design approval assumed, no merge. **Result:** two candidate families with three frames each, three animated GIFs, native exact 8×16 RGBA files, enlarged pixel grids, masks, byte table and palette proposals.

## 1. Source authority read

- Project Sources 00–04 were read. They are Nov 21 snapshots, not live implementation authority.
- Live primary design [01–60](https://github.com/Odourman/the-skraun/blob/main/docs/DESIGN_DECISIONS_01-60_2026-11-16.md), blob `415b66a9603e9330de53768b5800f4a23f8e47b2`; [visual direction](https://github.com/Odourman/the-skraun/blob/main/docs/SKRAUN_VISUAL_DIRECTION_2026-11-16.md), blob `ee4180805f1fd4280303608fee7cdc3d29c0d8c2`.
- Frozen [U1-LEG1](https://github.com/Odourman/the-skraun/blob/graphics/u1-leg1-caprine-gait-20261116/graphics/u1_leg1/SOURCE_U1_LEG1.json), blob `48332690d58aecf70d986eeee075dd3156bbf102`. No U1 source bytes have been changed or republished as a modified sprite.
- Previous [MAIN IV graphical experiment K1](https://github.com/Odourman/the-skraun/blob/graphics/mainiv-forest-knights-source-20261122/graphics/mainiv_forest_knights_20261122/KNIGHT_P1_CANDIDATES.json), blob `5ba39ca942a75239062f3b42f390782df56cdc54`.
- Older [Ranger reference](https://github.com/Odourman/the-skraun/blob/graphics/skraun-v0-3-final-readability-20261116/graphics/skraun_v0_3/ENEMIES_V03.json), blob `61d60a98d214cd83965ec18fe1f8cc48cd58fffb`. Old 8×12 bow hard to distinguish, only comparison, not locked production art.
- [GAMEPLAY-1 draft PR #41](https://github.com/Odourman/the-skraun/pull/41), development head `7f289a536c375bf760428274280179cfe15a6a62` read for actual provisional P1 resource context; a single P1 training knight is not a full three-enemy renderer.
- User's uploaded *T-visor JPEG* and two-frame *Ranger GIF* actually inspected: GIF 256×192, 2 frames, 160 ms each. The GIF depicts a slim forest archer with an outward curved bow, shifting between two shapes. Drawn pixels are **new, single-colour source silhouettes**, not copied or recoloured original multi-colour pixels. The JPEG/GIF originals are **not republished** in this deliverable.

## 2. Knight K1_T_VISIR_8x16 — recommended design candidate

Three 8-wide, 16-high, one-colour P1 masks, in `data/SOURCE_MASKS_AND_TIMING.json` and `data/ENEMY_P1_SOURCE_ONLY.inc` (DASM-style data only; not compiled). Top-first mask rows, bit7 leftmost, 1=foreground, 0=transparent. Image assets exactly derive from these bits.

The visor follows the new user reference: upper helmet dome, horizontal **3-pixel transparent visor opening** at y2/x1..3 and central **one-pixel vertical** opening at x2/y3..4. This is a T-shaped *gap*, not extra-colour pixels. No horn extensions. The neutral body/sword stays within x0..4, while warning raises a vertical x6 stroke near/above the head. Attack extends P1 arm/sword horizontally to x7 over y8..9. Legs remain split.

> **Limit:** This is a coherent *P1-only* attack graphic but no sword pixel can exist outside the 8-pixel P1 footprint. In the visual source the rightmost attack pixel is x7. The Boxing-like reach is represented by a change from tucked sword to extended row; it is at most three logical pixel columns beyond the neutral rightmost bit, NOT a free longer hitbox. Actual physical attack range/recognition is not proven. If longer reach is essential, test the alternative M1 on a separately authorized ROM.

Animation GIF sequence: neutral 320 ms → raised warning 400 ms → strike 160 ms → neutral 320 ms, loop. **Only the 400 ms warning models the existing 24 NTSC-frame (~0.4s) game design; strike duration in the GIF is illustrative, not approved hit window**. Knight stops during warning; facing locks from warning start; damage may only occur during active strike; body-contact never damages.

### A: P1 silhouette (preferred graphics-first)
- 16 bytes per pose, 48 bytes for three source poses (mirrors computed/stored separately); immutable 8-bit width.
- A single P1 sprite with one colour; no missile needed in the drawing.
- No guarantee that two knights + Ranger can be physically displayed in the same scanlines.

### B: P1 + M1 blade (OPTION ONLY)
- Same P1 8×16 body source; a future **M1** could be independently positioned on an attack rasterline, with possible width 1/2/4/8 *colour clocks*, shared `COLUP1` colour, `ENAM1` gating and `RESM1/HMM1` positioning.
- Illustrative `images/RIDDARE_P1_M1_ALTERNATIV_SOURCE_ONLY.png` shows an 8-clock missile extending beyond P1; it is **not** part of a P1 source mask and it is **NOT** working TIA rendering. It consumes missile, TIA writes, timing and shared P1 colour; it could conflict with other objects, same-Y enemies, renderer/HUD/halo. No assumption that M1 is free.
- MAIN IV must explicitly choose a physical test later if needed. No new rendering choice made here.

## 3. Ranger R1_BOW_8x16 — recommended candidate

The previous 8×12 archery mask is inadequate to retain a recognisable bow at this width. A **new 8×16 *candidate*** uses the same P1 bit-width and +4 source raster rows; **this is not authorization to change production sprite height**. One-colour silhouette: the human/hood occupies ~3–4 horizontal pixels, the bow curves on x6/x7, a grip/string has bits on x4/x5. R1 is noticeably narrower in its humanoid torso than K1; the bow remains part of the very same 8-bit mask.

Animation: neutral/hold 320 ms → raised, drawn bow 480 ms → release 160 ms → neutral 320 ms. Frame timings are **presentation only**, not Ranger's final gameplay attack timing or firing interval. A visible projectile is NOT present; it remains a separate, as-yet unimplemented gameplay object. Visual character form follows the two-frame reference's archer and bow draw without copying its multicolour sprites.

The mask is reused for all worlds, and only P1 colour may change:

| World | Candidate | Caveat |
|---|---|---|
| Forest | `$C6` (green) | Different from provisional forest PF `$C8`; contrast to be tested |
| Dream | `$58` (purple) | Matches dream mood, uncalibrated |
| Mountain | `$38` (earth/tan) | Candidate, not user-approved |
| Night | `$0C` (gray-white) | High contrast possible, may need darker variant to be camouflaged |

These are **NTSC-register candidates**, not calibrated palette choices, and no multi-colour Ranger is claimed. `COLUP1` changes per enemy may require precise raster scheduling; this study does not grant that time. Mirrored left-facing versions are bit-reversed rows, available to be generated from the JSON; orientation switch and AI/arrow facing have not been implemented.

## 4. Fixed game canon and integration constraints

- Player P0 remains the **exact** approved U1-LEG1 A/B facing data, no additional frames or altered sizes. The original A_Glanta PF image was reused byte-for-byte outside character overlay rectangles. Composite PNG is **concept-only**, not runtime and not a new forest assignment.
- Gameplay continues to require **two concurrently active knights + one world-camouflaged Ranger** and a readable halo. P1 has only one physical player. All three same-row actor reconstruction / 76-CPU-cycle beam timing remain unproved. **NO claim of full renderer feasibility**.
- M1 availability, P1 repositioning, possible flicker, palette contrast and 128-byte RIOT RAM/stack are open until separately authorized physical investigation.
- Source file, GIF, row order and mirrored interpretation are reproducible via `python generate.py`; this generator produces **no ROM or emulation**. `python verify.py` checks source bit matrices, per-pixel native PNG masks, GIF frame changes, unchanged previous forest outside character overlays, and exact frozen Skraun bits in the composite.
- To integrate later, ROM DEVELOPMENT III requires a **separate new explicit MAIN IV order**. It would need physical DASM/Stella replay on real native masks, three-state 24-frame warning and subsequent strike window, sprite box/color checks, 262-line NTSC, critical `GRP1/ENAM1/RESP1/PF2` beam deadlines, RIOT/stack high-water, actor multiplexing, halo and solid-hinder physics. None of that is claimed here.

## 5. Visuals and status

- `images/RIDDARE_K1_T_VISIR_ANIMATION_SOURCE_ONLY.gif`
- `images/RANGER_R1_BAGE_ANIMATION_SOURCE_ONLY.gif`
- `images/RIDDARE_RANGER_JAMFORELSE_SOURCE_ONLY.gif`
- `images/RIDDARE_K1_T_VISIR_3_POSER_PIXELGRID.png`
- `images/RANGER_R1_BAGE_3_POSER_PIXELGRID.png`
- `images/T_VISIR_OCH_BAGE_PIXELDETALJ_SOURCE_ONLY.png`
- `images/RIDDARE_P1_M1_ALTERNATIV_SOURCE_ONLY.png`
- `images/A_GLANTA_FIENDER_OVERSIKT_SOURCE_ONLY.png`
- Six native true 8×16 transparent RGBA individual pose PNGs, and a 160×176 native composite.

**Recommend for user visual selection:** K1_T_VISIR and R1_BOW, marked **PROVISIONAL_SOURCE_ONLY**. Neither masks nor GIFs are Stella images, hardware renderer passes or independent verification. **GRAPHICS II stops after submission.** No ROM development, world redesign, main merge or independent verification initiated.
