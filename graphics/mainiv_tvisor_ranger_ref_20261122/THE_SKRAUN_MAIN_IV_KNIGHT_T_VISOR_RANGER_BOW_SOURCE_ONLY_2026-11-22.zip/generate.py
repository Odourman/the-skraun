#!/usr/bin/env python3
"""Reproducible SOURCE_ONLY TIA P1 mask previews, never Stella or ROM."""
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import json, hashlib, zipfile, math
ROOT=Path(__file__).parent
IM=ROOT/'images';DATA=ROOT/'data';IM.mkdir(exist_ok=True);DATA.mkdir(exist_ok=True)
# Width EXACTLY 8 logical Atari player pixels; height 16 source rows.
K={
 'neutral':[
 '.####...', '#####...', '#...#...', '##.##...', '##.##...', '.###....',
 '#####...', '#####...', '##.##...', '.####...', '.###....', '.###....',
 '#.#.#...', '#.#.#...', '##.##...', '#...#...' ],
 'warning':[
 '.####.#.', '#####.#.', '#...#.#.', '##.##.#.', '##.##.#.', '.###..#.',
 '#####.#.', '#######.', '##.##...', '.####...', '.###....', '.###....',
 '#.#.#...', '#.#.#...', '##.##...', '#...#...' ],
 'strike':[
 '.####...', '#####...', '#...#...', '##.##...', '##.##...', '.###....',
 '#####...', '######..', '##.#####', '.#######', '.###....', '.###....',
 '#.#.#...', '#.#.#...', '##.##...', '#...#...' ]}
# R1 bow raised in draw and released positions. Outer bow is P1 x6/x7,
# with an inner string/grip: all coloured bits belong to P1 GRP1.
R={
 'neutral':[
 '..###...', '.####...', '.#.#....', '.###....', '..##....',
 '.###....', '.###....', '.###..#.', '.###...#', '.#####.#',
 '.###.#.#', '..##...#', '..##..#.', '.#.#....', '.#..#...', '##..##..'],
 'draw':[
 '..###...', '.####...', '.#.#....', '.###....', '..##..#.',
 '.###...#', '.###.#.#', '.####..#', '.#######', '.####..#',
 '.###.#.#', '..##..#.', '..#.#...', '.#..#...', '.#..#...', '##..##..'],
 'release':[
 '..###...', '.####...', '.#.#....', '.###....', '..##..#.',
 '.###...#', '.###...#', '.###...#', '.#######', '.###...#',
 '.###...#', '..##..#.', '..#.#...', '.#..#...', '.#..#...', '##..##..']}
for name,poses in [('knight',K),('ranger',R)]:
 for mode,rows in poses.items():
  assert len(rows)==16,(name,mode)
  assert all(len(s)==8 and set(s)<={'.','#'} for s in rows),(name,mode)
 assert all(len(x)==16 for x in poses.values())

C={'panel':(16,26,34),'bg':(19,42,32),'knight':(139,207,244),'ranger':(117,184,89),'muted':(167,185,195),'light':(244,248,247),'gold':(240,190,87),'stroke':(75,106,116),'visor':(12,27,33),'grid':(49,70,74),'white':(248,251,252)}
fontroot=Path('/usr/share/fonts/truetype/dejavu');FONT=lambda n,bold=False:ImageFont.truetype(str(fontroot/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')),n)
font32=FONT(30,True);font24=FONT(23,True);font18=FONT(18);font14=FONT(14);font12=FONT(12)

def bit_rows(rows):return [row.replace('.','0').replace('#','1') for row in rows]
def data_for(rows):
 b=bit_rows(rows);return {'ascii_top_first':rows,'binary_top_first':b,'hex_top_first':['$%02X'%int(s,2) for s in b], 'bytes_top_first':[int(s,2) for s in b], 'bytes_ROM_bottom_first':[int(s,2) for s in b[::-1]],'horizontal_mirror_binary_top_first':[s[::-1] for s in b]}

source={
 'metadata':{'date':'2026-11-22','status':'SOURCE_ONLY_DESIGN_NOT_STELLA_NOT_ROM',
  'scope':'MAIN IV second GRAPHICS II task: knight T visor and ranger from user-supplied two-frame GIF',
  'source_width_pixels':8,'source_height_rows':16,'rows':'top first','bit7':'leftmost (viewed)','bits':'1 foreground, 0 transparent/background',
  'P1_color':'monochromatic per row; one proposed global color per character',
  'source_right_facing':'illustrated sword/bow points to screen-right; horizontally mirror whole 8-bit rows for screen-left',
  'source_only_caution':'normal knight strike extends to x7 edge within P1; no pixels exist beyond 8px footprint; physical sword reach not proven',
  'No_ROM_implementation':True,'No_stella':True,
  'reference_GIF_frames':2,'reference_GIF_duration_ms_each':[160,160],
  'reference_use':'broad silhouette and changing/drawn bow; no copied multicolour pixels',
  'knight_ancestor':'K1_VISIR on previous graphics branch; pixel refinement, not user-approved source',
  'ranger_ancestor':'archer_idle/archer_draw 8x12 in ENEMIES_V03.json; comparison only',
  'canonical_Skraun':'frozen U1-LEG1 unchanged, source blob 48332690d58aecf70d986eeee075dd3156bbf102'},
 'knight_K1_T_VISIR_8x16':{p:data_for(rows) for p,rows in K.items()},
 'ranger_R1_BOW_8x16':{p:data_for(rows) for p,rows in R.items()},
 'animation_timing_ms':{
  'knight_preview':[['neutral',320],['warning',400],['strike',160],['neutral',320]],
  'ranger_preview':[['neutral',320],['draw',480],['release',160],['neutral',320]],
  'comparison_preview':[['neutral','neutral',320],['warning','draw',400],['strike','release',160],['neutral','neutral',320]]},
 'palette_candidates':{'knight':{'tia_ntsc_test':'$9E','illustration_RGB':C['knight']},
  'ranger_forest':{'tia_ntsc_test':'$C8','illustration_RGB':C['ranger']},
  'ranger_dream':{'tia_ntsc_test':'$58','illustration_RGB':[168,123,216]},
  'ranger_mountain':{'tia_ntsc_test':'$38','illustration_RGB':[180,151,100]},
  'ranger_night':{'tia_ntsc_test':'$0C','illustration_RGB':[186,192,197], 'caveat':'Contrast candidate only; world camouflage still needed, not final'},
  'caveat':'TIA RGB visualization approximation; palette bytes must be validated in Stella; no per-pixel RGB on real P1'}
}
(DATA/'SOURCE_MASKS_AND_TIMING.json').write_text(json.dumps(source,indent=2,ensure_ascii=False)+'\n')
# Source-only assembler tables. No executable ROM code.
asm=['; THE SKRAUN — SOURCE_ONLY, not wired to 6507/TIA kernel',
     '; 8 bits wide (bit7 = left), top-first human rows; .byte order shown TOP_FIRST and ROM_BOTTOM_FIRST',
     '; MIRROR direction = reverse the 8 bits in every row, not reverse rows.','']
for label,poses in [('KnightT',K),('RangerBow',R)]:
 for pose,rows in poses.items():
  bits=[int(s,2) for s in bit_rows(rows)]
  asm += [f'{label}_{pose}_BOTTOM_FIRST:', '    dc.b '+','.join('$%02X'%v for v in bits[::-1]),'']
(DATA/'ENEMY_P1_SOURCE_ONLY.inc').write_text('\n'.join(asm)+'\n')

# Pixel exact preview; black negative space = transparent, never separate colour region.
def blit(sprite,rows,xy,scale=1,colour=C['knight'],grid=False):
 d=ImageDraw.Draw(sprite)
 x,y=xy
 for iy,row in enumerate(rows):
  for ix,b in enumerate(row):
   if b=='#':d.rectangle((x+ix*scale,y+iy*scale,x+(ix+1)*scale-1,y+(iy+1)*scale-1),fill=colour)
 if grid:
  for ix in range(9):d.line((x+ix*scale,y,x+ix*scale,y+16*scale),fill=C['grid'],width=1)
  for iy in range(17):d.line((x,y+iy*scale,x+8*scale,y+iy*scale),fill=C['grid'],width=1)
  d.rectangle((x,y,x+8*scale,y+16*scale),outline=C['muted'],width=1)

def label(d,x,y,s,font=font18,color=None):d.text((x,y),s,font=font,fill=color or C['white'])

def frame_single(who,pose):
 isK=who=='knight';rows=(K if isK else R)[pose];colour=C['knight'] if isK else C['ranger'];name='K1-T / RIDDARE' if isK else 'R1 / RANGER';
 W,H=900,530;im=Image.new('RGB',(W,H),C['panel']);d=ImageDraw.Draw(im)
 label(d,36,18,'SOURCE_ONLY  /  PIXELMASK',font24,C['gold']);label(d,36,64,f'{name}  -  {pose.upper()}',font32)
 d.rectangle((34,110,866,480),fill=C['bg'],outline=C['stroke'],width=2)
 # Native mask: at 1 pixel, with nearest-neighbour TV pixel double 2x adjacent for visible check
 label(d,64,132,'LOGISK STORLEK',font14,C['muted']); label(d,64,150,'8 x 16 pixlar',font14)
 blit(im,rows,(100,205),scale=1,colour=colour)
 # actual TIA display 2x horizontal, 1x height
 label(d,64,290,'STELLA TV-SKALA*',font14,C['muted']);label(d,64,309,'16 x 16',font14)
 for iy,row in enumerate(rows):
  for ix,b in enumerate(row):
   if b=='#':d.rectangle((100+ix*2,348+iy,100+ix*2+1,348+iy),fill=colour)
 label(d,302,131,'FORSTORADE KALLPIX LAR',font14,C['muted'])
 blit(im,rows,(420,163),scale=17,colour=colour,grid=True)
 label(d,625,177,'8 bit / rad',font18)
 label(d,625,213,'16 rader',font18)
 label(d,625,267,'P1, en farg',font18)
 label(d,625,307,'Visirhal = 0' if isK else 'Bage = P1',font18)
 label(d,625,347,'Ej Stella-ROM',font14,C['gold'])
 label(d,36,491,'* Illustrerad TV-horisontaldubbling, inte uppmatt rendering.',font14,C['muted'])
 return im

def gif_for(name,who,sequence):
 frames=[frame_single(who,p) for p,ms in sequence]
 frames[0].save(IM/name,save_all=True,append_images=frames[1:],duration=[ms for p,ms in sequence],loop=0,optimize=False,disposal=2)

gif_for('RIDDARE_K1_T_VISIR_ANIMATION_SOURCE_ONLY.gif','knight',source['animation_timing_ms']['knight_preview'])
gif_for('RANGER_R1_BAGE_ANIMATION_SOURCE_ONLY.gif','ranger',source['animation_timing_ms']['ranger_preview'])

def frame_compare(kpose,rpose):
 W,H=1000,550;im=Image.new('RGB',(W,H),C['panel']);d=ImageDraw.Draw(im)
 label(d,34,17,'SOURCE_ONLY / SAMMA 8-BITARS BREDD',font24,C['gold'])
 for who,pose,x in [('knight',kpose,62),('ranger',rpose,530)]:
  colour=C[who];rows=(K if who=='knight' else R)[pose]
  label(d,x,75,('RIDDARE - ' if who=='knight' else 'RANGER - ')+pose.upper(),font24)
  d.rectangle((x,119,x+407,472),fill=C['bg'],outline=C['stroke'],width=2)
  blit(im,rows,(x+60,156),scale=15,colour=colour,grid=True)
  label(d,x+235,169,'8 x 16 pixlar',font14)
  label(d,x+235,222,'Logisk x1:',font14,C['muted'])
  blit(im,rows,(x+281,258),scale=1,colour=colour)
  label(d,x+235,320,'Forstorad x15',font14,C['muted'])
  label(d,x+235,366,'Inga extra',font14)
  label(d,x+235,390,'TIA-objekt',font14)
 label(d,35,497,'Separata P1-kandidater, INTE bevis pa samtidig visning.',font14,C['muted'])
 return im
frames=[];dur=[]
for kp,rp,ms in source['animation_timing_ms']['comparison_preview']:
 frames.append(frame_compare(kp,rp));dur.append(ms)
frames[0].save(IM/'RIDDARE_RANGER_JAMFORELSE_SOURCE_ONLY.gif',save_all=True,append_images=frames[1:],duration=dur,loop=0,optimize=False,disposal=2)

# Overview previews, 3 pose columns, clear native+zoom, crisp graphics.
def pose_board(who):
 poses=(K if who=='knight' else R);colour=C[who]
 W,H=1160,620;im=Image.new('RGB',(W,H),C['panel']);d=ImageDraw.Draw(im)
 label(d,40,16,'SOURCE_ONLY / '+('RIDDARE: T-VISIR + SVARD' if who=='knight' else 'RANGER: HUVA + BAGE'),font24,C['gold'])
 for j,(p,rows) in enumerate(poses.items()):
  x=34+j*379
  d.rectangle((x,70,x+366,566),fill=C['bg'],outline=C['stroke'],width=2)
  label(d,x+16,81,p.upper(),font24)
  blit(im,rows,(x+37,139),scale=19,colour=colour,grid=True)
  label(d,x+212,158,'8x16',font18)
  blit(im,rows,(x+234,199),scale=1,colour=colour)
  label(d,x+212,235,'x1',font14,C['muted'])
  label(d,x+212,272,'P1',font18)
  label(d,x+212,308,'1 farg',font14)
  label(d,x+212,339,'Bit7 till',font14)
  label(d,x+212,360,'vanster',font14)
  label(d,x+212,405,'16 byte',font14,C['gold'])
 label(d,36,586,'Varje forstorad pixel motsvarar EXAKT en kallbit; svart = genomskinlig.',font14,C['muted'])
 return im
pose_board('knight').save(IM/'RIDDARE_K1_T_VISIR_3_POSER_PIXELGRID.png')
pose_board('ranger').save(IM/'RANGER_R1_BAGE_3_POSER_PIXELGRID.png')

# Head T visor / curved bow microscope with explicit bit-values/negative space.
def detail_board():
 W,H=1100,590;im=Image.new('RGB',(W,H),C['panel']);d=ImageDraw.Draw(im)
 label(d,28,14,'SOURCE_ONLY / VISIR OCH BAGE, 8-BITARS P1',font24,C['gold'])
 for offset,name,rows,colour in [(26,'T-VISIR',K['neutral'],C['knight']),(579,'BAGE / STRANG',R['draw'],C['ranger'])]:
  d.rectangle((offset,71,offset+494,556),fill=C['bg'],outline=C['stroke'],width=2)
  label(d,offset+23,85,name,font24)
  blit(im,rows,(offset+44,145),scale=19,colour=colour,grid=True)
  d.rectangle((offset+44,145,offset+44+8*19,145+6*19),outline=C['gold'],width=3)
  label(d,offset+220,151,'Bit7 = vanster',font14)
  label(d,offset+220,198,'0 = transparent',font14,C['muted'])
  label(d,offset+220,245,'1 = same P1',font14)
  label(d,offset+220,311,'Native 8x16:',font18)
  blit(im,rows,(offset+260,350),scale=1,colour=colour)
  label(d,offset+220,382,'M1 ej anvand',font14,C['gold'])
  label(d,offset+220,420,'P0 orord',font14)
 label(d,28,565,'De markerade rutorna ar T-visir och bage. Fri bildgenerering har inte anvants.',font14,C['muted'])
 return im
detail_board().save(IM/'T_VISIR_OCH_BAGE_PIXELDETALJ_SOURCE_ONLY.png')

# Native sprites exact bitmap 8x16; don't blend/scale in file.
for who,poses,colour in [('RIDDARE',K,C['knight']),('RANGER',R,C['ranger'])]:
 for pose,rows in poses.items():
  im=Image.new('RGBA',(8,16),(0,0,0,0))
  for y,r in enumerate(rows):
   for x,ch in enumerate(r):
    if ch=='#':im.putpixel((x,y),(*colour,255))
  im.save(IM/f'{who}_{pose}_EXAKT_8x16_RGBA.png')

# A_GLANTA: existing exact archived left20 mirrored forest; no new forest design.
arch=Path('/mnt/data/THE_SKRAUN_MAIN_IV_GRAPHICS_FOREST_KNIGHTS_SOURCE_ONLY_2026-11-22.zip')
if arch.exists():
 with zipfile.ZipFile(arch) as z:
  prev=z.read('images/A_Glanta_PF_NATIVE_160x176.png')
  import io
  stage=Image.open(io.BytesIO(prev)).convert('RGB')
  assert stage.size==(160,176),stage.size
  # exact U1 LEG1 A source, mirrored to VISUAL RIGHT, but character art unchanged
  sk=[s[::-1].replace('1','#').replace('0','.') for s in ['00100100','01111110','01011010','01100110','00111110','01111111','10111100','00111100','00111100','00100110','00100011','01100000']]
  blit(stage,sk,(71,82),scale=1,colour=(210,210,209))
  blit(stage,K['neutral'],(109,100),scale=1,colour=C['knight'])
  blit(stage,R['draw'],(39,115),scale=1,colour=C['ranger'])
  stage.save(IM/'A_GLANTA_MED_REVIDERADE_FIENDER_EXAKT_160x176_SOURCE_ONLY.png')
  big=stage.resize((800,880),Image.Resampling.NEAREST)
  # create header/footer independent from source pixels
  poster=Image.new('RGB',(870,985),C['panel']);d=ImageDraw.Draw(poster)
  label(d,31,16,'SOURCE_ONLY / A_GLANTA - OFORANDRAD PF',font24,C['gold'])
  poster.paste(big,(35,60))
  label(d,35,944,'Exakta kallmasker, EJ emulatorkorning.',font14,C['muted'])
  poster.save(IM/'A_GLANTA_FIENDER_OVERSIKT_SOURCE_ONLY.png')

# Reduced-copy (no original user GIF or JPEG distributed; only metadata to protect originals)
ref={'provided_ranger_reference':'1000048336(1).gif','frames':2,'frame_durations_ms':[160,160],
 'observed':'Båge till höger, en neutral/drawn shape and one shifted bow shape; human figure with slim legs and a green cloak',
 'adaptation':'Silhouette only, no multicolour copying, P1 single colour and 8-bit width constraint',
 'helmet_reference':'1000048334(1).jpg','observed_helmet':'T-shaped dark opening: horizontal eyeslits and vertical downslit',
 'original_files_not_republished':True,'copyright':'User-provided references remain separate'}
(DATA/'REFERENCE_ANALYSIS.json').write_text(json.dumps(ref,ensure_ascii=False,indent=2)+'\n')
# Isolated P1+M1 concept comparison (NOT GIF, NOT an authorized renderer).
option=Image.new('RGB',(1060,550),C['panel']);od=ImageDraw.Draw(option)
label(od,32,20,'SOURCE_ONLY / RACKVIDD: P1 ELLER P1+M1',font24,C['gold'])
for j in range(2):
 x=48+j*498
 od.rectangle((x,81,x+463,492),fill=C['bg'],outline=C['stroke'],width=2)
 label(od,x+24,98,'A: ENDAST P1' if j==0 else 'B: P1 + M1 (HYPOTES)',font18)
 # 8-bit P1 x22 scale plus a 1-scanline 8cc-wide missile at y8 outside P1.
 blit(option,K['strike'],(x+42,170),scale=17,colour=C['knight'],grid=True)
 if j:
  od.rectangle((x+42+8*17,170+8*17,x+42+16*17-1,170+9*17-1),fill=C['knight'])
  od.rectangle((x+42+8*17,170+8*17,x+42+16*17-1,170+9*17-1),outline=C['gold'],width=2)
  label(od,x+300,210,'M1 x8cc',font14,C['gold'])
  label(od,x+300,252,'Eget objekt',font14)
  label(od,x+300,281,'Ej fritt',font14)
  label(od,x+300,310,'Ej ROM-testat',font14)
 else:
  label(od,x+275,214,'Max x7',font18,C['gold'])
  label(od,x+275,256,'Ingen pixel',font14)
  label(od,x+275,282,'utanfor P1',font14)
 label(od,x+24,458,'P1-mask = samma 8x16 i bada.',font14,C['muted'])
label(od,32,509,'Missilen M1 ar illustrerad som 8 color clocks bred och endast 1 rasterrad aktiv.',font14,C['muted'])
option.save(IM/'RIDDARE_P1_M1_ALTERNATIV_SOURCE_ONLY.png')

print('GENERATED',len(list(IM.iterdir())),'IMAGES',len(list(DATA.iterdir())),'DATA')
print('Knight head T:', '\n'.join(K['neutral'][:6]));print('Ranger draw:', '\n'.join(R['draw']))
