; THE SKRAUN — SOURCE_ONLY, not wired to 6507/TIA kernel
; 8 bits wide (bit7 = left), top-first human rows; .byte order shown TOP_FIRST and ROM_BOTTOM_FIRST
; MIRROR direction = reverse the 8 bits in every row, not reverse rows.

KnightT_neutral_BOTTOM_FIRST:
    dc.b $88,$D8,$A8,$A8,$70,$70,$78,$D8,$F8,$F8,$70,$D8,$D8,$88,$F8,$78

KnightT_warning_BOTTOM_FIRST:
    dc.b $88,$D8,$A8,$A8,$70,$70,$78,$D8,$FE,$FA,$72,$DA,$DA,$8A,$FA,$7A

KnightT_strike_BOTTOM_FIRST:
    dc.b $88,$D8,$A8,$A8,$70,$70,$7F,$DF,$FC,$F8,$70,$D8,$D8,$88,$F8,$78

RangerBow_neutral_BOTTOM_FIRST:
    dc.b $CC,$48,$50,$32,$31,$75,$7D,$71,$72,$70,$70,$30,$70,$50,$78,$38

RangerBow_draw_BOTTOM_FIRST:
    dc.b $CC,$48,$48,$28,$32,$75,$79,$7F,$79,$75,$71,$32,$70,$50,$78,$38

RangerBow_release_BOTTOM_FIRST:
    dc.b $CC,$48,$48,$28,$32,$71,$71,$7F,$71,$71,$71,$32,$70,$50,$78,$38

