#!/usr/bin/env python3
"""SOURCE_ONLY integrity assertions; this is NOT TIA/Stella verification."""
from pathlib import Path
from PIL import Image
from zipfile import ZipFile
import json,hashlib,io
base=Path(__file__).parent
src=json.loads((base/'data/SOURCE_MASKS_AND_TIMING.json').read_text())
count=0
for group,prefix in [('knight_K1_T_VISIR_8x16','RIDDARE'),('ranger_R1_BOW_8x16','RANGER')]:
 for pose,info in src[group].items():
  rows=info['ascii_top_first']
  assert len(rows)==16 and all(len(r)==8 and set(r)<={'.','#'} for r in rows)
  assert info['binary_top_first']==[r.replace('.','0').replace('#','1') for r in rows]
  assert info['bytes_ROM_bottom_first']==list(reversed(info['bytes_top_first']))
  assert info['horizontal_mirror_binary_top_first']==[x[::-1] for x in info['binary_top_first']]
  img=Image.open(base/f'images/{prefix}_{pose}_EXAKT_8x16_RGBA.png').convert('RGBA')
  assert img.size==(8,16)
  active={(x,y) for y in range(16) for x in range(8) if img.getpixel((x,y))[3]}
  expected={(x,y) for y,row in enumerate(rows) for x,b in enumerate(row) if b=='#'}
  assert active==expected, (prefix,pose,'pixel mismatch')
  assert len({img.getpixel(xy)[:3] for xy in active})==1
  count+=1
knight=src['knight_K1_T_VISIR_8x16'];ranger=src['ranger_R1_BOW_8x16']
# T negative space bar 3 (x1..3) on y2, stem at x2 y3,y4.
for pose in ('neutral','strike'):
 rows=knight[pose]['binary_top_first'];assert rows[2][1:4]=='000' and rows[3][2]=='0' and rows[4][2]=='0'
# The active P1 strike never escapes 8x16; distinguish from tucked neutral by x7 on strike.
assert '1' not in ''.join(row[7] for row in knight['neutral']['binary_top_first'])
assert any(row[7]=='1' for row in knight['strike']['binary_top_first'])
# All three modes differ.
for group in (knight,ranger):
 assert len({tuple(x['binary_top_first']) for x in group.values()})==3
# Bow x6/7 is at least 6 rows occupied in draw, constructed within same 8bit mask.
assert sum(any(r[x]=='1' for x in (6,7)) for r in ranger['draw']['binary_top_first'])>=7
for name in ('RIDDARE_K1_T_VISIR_ANIMATION_SOURCE_ONLY.gif','RANGER_R1_BAGE_ANIMATION_SOURCE_ONLY.gif','RIDDARE_RANGER_JAMFORELSE_SOURCE_ONLY.gif'):
 gif=Image.open(base/'images'/name);assert gif.n_frames==4
 # Validate there is real visual difference across frames, independent of GIF frame durations.
 digest=[]
 for i in range(4):
  gif.seek(i);digest.append(hashlib.sha256(gif.convert('RGB').tobytes()).hexdigest())
 assert digest[0]!=digest[1] and digest[1]!=digest[2] and digest[2]!=digest[3]
count+=3
# Reuse forest exactly outside selected rectangles; exact U1-LEG1 source.
with ZipFile('/mnt/data/THE_SKRAUN_MAIN_IV_GRAPHICS_FOREST_KNIGHTS_SOURCE_ONLY_2026-11-22.zip') as z:
 baseline=Image.open(io.BytesIO(z.read('images/A_Glanta_PF_NATIVE_160x176.png'))).convert('RGB')
scene=Image.open(base/'images/A_GLANTA_MED_REVIDERADE_FIENDER_EXAKT_160x176_SOURCE_ONLY.png').convert('RGB')
mask_regions=[(71,82,8,12),(109,100,8,16),(39,115,8,16)]
for y in range(176):
 for x in range(160):
  if not any(x0<=x<x0+w and y0<=y<y0+h for x0,y0,w,h in mask_regions):
   assert scene.getpixel((x,y))==baseline.getpixel((x,y))
with ZipFile('/mnt/data/THE_SKRAUN_U1_LEG1_CAPRINE_GAIT_2026-11-16.zip') as z:
 frozen=json.loads(z.read('SOURCE_U1_LEG1.json'))['one_candidate_U1_LEG1']['A']
 for yy,row in enumerate(frozen):
  for xx,ch in enumerate(row[::-1]):
   if ch=='1':assert scene.getpixel((71+xx,82+yy))==(210,210,209)
count+=2
print('SOURCE_ONLY VALIDATION PASS:',count,'checks (6 pose pixel masks, 3 GIFs, forest unchanged, frozen Skraun pixels)')
print('No DASM, ROM, TIA or Stella test was run.')
