# THE SKRAUN — MAIN IV, GRAPHICS II: revised knight + Ranger

**SOURCE_ONLY** pixel art for original Atari 2600; no ROM, no Stella, not final approval.

- `GRAPHICS_II_TO_MAIN_IV_HANDOFF_2026-11-22.md`: source provenance, masks and technical constraints, integration notes.
- `data/SOURCE_MASKS_AND_TIMING.json`: six exact 8×16 source masks, bit/hex bytes, bit-reversed mirror and proposed timings.
- `data/ENEMY_P1_SOURCE_ONLY.inc`: DASM-style *data tables only*, not executable/implemented game code.
- `images/*.gif`: Knight neutral/warning/strike/recovery, Ranger hold/draw/release, combined comparison. Source-only.
- `images/*EXAKT_8x16_RGBA.png`: pixel-exact transparent native masks.
- `images/*PIXELGRID.png`: enlarged nearest-pixel comparisons.
- `images/T_VISIR_OCH_BAGE_PIXELDETALJ_SOURCE_ONLY.png`: visor and bow.
- `images/RIDDARE_P1_M1_ALTERNATIV_SOURCE_ONLY.png`: untested physical M1 *hypothesis*, not an extra free sprite.
- `images/A_GLANTA_FIENDER_OVERSIKT_SOURCE_ONLY.png`: previous forest, unchanged PF, exact frozen Skraun and two proposed new enemy masks.
- `generate.py`: pure Pillow output reproducer.
- `verify.py`: source-only image/mask integrity assertions.
- `SHA256SUMS.txt`: checksums for everything in this directory, excluding the manifest itself.

`python generate.py && python verify.py && sha256sum -c SHA256SUMS.txt`

Never call the preview art actual Stella output. No edits to main/canon.
