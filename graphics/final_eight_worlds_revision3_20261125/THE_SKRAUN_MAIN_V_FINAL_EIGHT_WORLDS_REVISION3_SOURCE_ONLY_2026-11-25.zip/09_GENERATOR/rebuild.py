#!/usr/bin/env python3
"""THE SKRAUN GRAPHICS II: Revision 3, reproducible SOURCE_ONLY bitmap package.

Requires Python 3.10+, Pillow. No network access, no ROM builds, no GitHub writes.
Run `python 09_GENERATOR/rebuild.py` from any working directory.
Inputs are exact Revision 2 JSON, U1 mask and historical preview embedded beside this script.
Only three mask IDs may differ from Revision 2; all other data is asserted byte-identical.
"""
from pathlib import Path
import hashlib, json, collections, re, zipfile, shutil
from PIL import Image, ImageDraw, ImageFont, ImageChops

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'09_GENERATOR'
REF=ROOT/'11_APPROVED_VISUAL_REFERENCE'
PREV=ROOT/'06_PREVIEWS'; MOT=ROOT/'07_INDIVIDUAL_MOTIFS'; COMP=ROOT/'08_BEFORE_AFTER'
for d in [PREV,MOT,COMP]:d.mkdir(exist_ok=True)
R2=json.loads((SRC/'REVISION2_WORLD_GRAPHICS_FROZEN.json').read_text(encoding='utf-8'))
assert R2['status']=='SOURCE_ONLY_REVISION2'
assert [len(s['PF1_hex']) for s in R2['stages']]==[96]*8
assert len(R2['motifs'])==16
R2_ALL=bytes(int(x[1:],16) for s in R2['stages'] for x in s['PF1_hex'])
R2_EXPECT='253bd7180259cf699a4315379b900ca47801ae6259f0955a002bc601f5ef98f8'
assert len(R2_ALL)==768 and hashlib.sha256(R2_ALL).hexdigest()==R2_EXPECT
# Frozen R2 ASM is independently reparsed to confirm the JSON is exact shipped source.
R2_ASM=(SRC/'REVISION2_PLAYFIELD_DATA_FROZEN.asm').read_text(encoding='utf-8').split('PlayPF1:',1)[1]
R2_ASM_BYTES=bytes(int(z,16) for line in R2_ASM.splitlines() if 'dc.b' in line for z in re.findall(r'\$([0-9A-Fa-f]{2})',line))
assert R2_ASM_BYTES==R2_ALL

def H(*pairs):return [r for r,n in pairs for _ in range(n)]
CHANGED={
 '01_round_A': H(('00011000',1),('00111100',2),('01111110',3),('11111111',4),('01111110',3),('00111100',1),('00011000',8)),
 '02_round_B': H(('00011000',1),('00111100',2),('01111110',3),('01111111',4),('01111110',3),('00111100',1),('00011000',8)),
 '04_peak_B': H(('00001000',2),('00011100',3),('00111110',4),('01111110',3),('01111111',5)),
}
assert set(CHANGED)=={'01_round_A','02_round_B','04_peak_B'}
MOTIFS={k:v[:] for k,v in R2['motifs'].items()}
for k,r in CHANGED.items():
 assert len(r)==len(MOTIFS[k])
 assert all(len(v)==8 and set(v)<={'0','1'} for v in r)
 if int(k[:2])%2==0:assert all(v.startswith('0') for v in r),k
 MOTIFS[k]=r
assert len(MOTIFS)==16
for k in set(MOTIFS)-set(CHANGED):assert MOTIFS[k]==R2['motifs'][k],k

STAGES=[];CHANGES={};COLORS=R2['palette_proposals_only_unchanged_from_rev1'];GOLD='#eebd4c'
for i,prior in enumerate(R2['stages']):
 n=i+1
 r=list(R2_ALL[i*96:(i+1)*96]);original=r[:]
 top=prior['top_motif']['name'];bottom=prior['bottom_motif']['name']
 active=[k for k in (top,bottom) if k in CHANGED]
 for k in active:
  loc=prior['top_motif'] if k==top else prior['bottom_motif']
  start=loc['y_start']
  for row,bits in enumerate(CHANGED[k]):
   y=start+2*row
   idx=(186-y)//2
   assert 0<=idx<=93 and r[idx]==int(R2['motifs'][k][row],2), (n,k,idx,r[idx])
   r[idx]=int(bits,2)
 diff=[j for j,(a,b) in enumerate(zip(original,r)) if a!=b]
 assert bool(diff)==bool(active),(n,active,diff)
 if active:
  allowed=set()
  for k in active:
   loc=prior['top_motif'] if k==top else prior['bottom_motif']
   allowed.update((186-(loc['y_start']+2*j))//2 for j in range(len(CHANGED[k])))
  assert set(diff)<=allowed
 assert (prior['mode']=='mirror')==(n%2==1)
 if not active:assert bytes(r)==bytes(original)
 entry={**prior,'PF1_hex':[f'${b:02X}' for b in r],'PF1_binary':[f'{b:08b}' for b in r]}
 STAGES.append(entry)
 CHANGES[str(n)]={'mask_ids':active,'changed_bytes':len(diff),'indices':diff,'world':prior['world']}

ALL=bytes(int(v[1:],16) for s in STAGES for v in s['PF1_hex']);assert len(ALL)==768
assert [i for i in range(8) if ALL[i*96:(i+1)*96]!=R2_ALL[i*96:(i+1)*96]]==[0,1,3]
# Absolute byte index guarantees no other motif or unowned table byte was changed.
assert all(ALL[i]==R2_ALL[i] for i in range(768) if i//96 not in (0,1,3))

# Source-only conservative AABB remains numerically exact: all three revised mask
# outermost pixels and top/bottom row bounds remain unchanged. No collision edits.
def raster(rows):return [rows[(186-y)//2] for y in range(186)]
def rects_for(data,mirrored):
 pts=[[],[],[],[]]
 for y,v in enumerate(raster(data)):
  if not v:continue
  base=0 if y<90 else 2
  for bit in range(8):
   if v&(128>>bit):
    x=16+4*bit;xr=140-4*bit if mirrored else 96+4*bit
    for i,xx in ((base,x),(base+1,xr)):
     pts[i].append((xx,y));pts[i].append((xx+3,y))
 assert all(pts)
 return [[min(x for x,y in group),max(x for x,y in group)+1,min(y for x,y in group),max(y for x,y in group)+1] for group in pts]

def nav(rects):
 # This bounded SOURCE_ONLY floodfill checks a rectangle model, not actual gameplay.
 free=set()
 for y in range(22,155):
  for x in range(20,141):
   if all(x+16<a or x-16>=b or y+18<c or y-18>=d for a,b,c,d in rects):free.add((x,y))
 start=(80,88);assert start in free
 pending=collections.deque([start]);found={start}
 while pending:
  x,y=pending.popleft()
  for point in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
   if point in free and point not in found: found.add(point);pending.append(point)
 assert found==free
 return {'free_centers':len(free),'connected_centers':len(found),'L3_centers_connected':True,'central_spine_x80_y63_119_clear':all((80,y) in free for y in range(63,120))}
for s in STAGES:
 vals=[int(x[1:],16) for x in s['PF1_hex']]
 bbox=rects_for(vals,s['mode']=='mirror')
 assert bbox==s['rects_xyxy_halfopen'], (s['stage'],bbox,s['rects_xyxy_halfopen'])
 navdata=nav(bbox)
 assert navdata['central_spine_x80_y63_119_clear']
 s['geometric_source_only_l3']={**s['geometric_source_only_l3'],'revision3_rechecked':navdata}

HASH=hashlib.sha256(ALL).hexdigest()
COUNT=sum(a!=b for a,b in zip(R2_ALL,ALL))
assert 0<COUNT<768
OUT={
 'status':'SOURCE_ONLY_REVISION3_PENDING_MAIN_V_VISUAL_APPROVAL',
 'visual_basis':'user original approved image; Revision 2 frozen source and graphics',
 'source':{'rev2_graphics_commit':'299de38d6e8fbefbc1057d70682b56b76dd177f2','PR60_developer_head':'2af9855fbe8d3edbe6d01609d3e539547b744aef','PR60_bank3_Git_blob':'62e88de692df80024db8342e0990640a5310f620'},
 'format':R2['format'],
 'changed_motif_ids':list(CHANGED),
 'motifs':MOTIFS,
 'stages':STAGES,
 'palette_proposals_only_unchanged_from_rev2':COLORS,
 'PF1_768B_sha256':HASH,'revision2_PF1_768B_sha256':R2_EXPECT,
 'PF1_bytes_changed_against_rev2':COUNT,
 'byte_provenance_by_stage':CHANGES,
 'collision_proposal_vs_rev2':'all 8 x 4 prior half-open AABBs unchanged: computed outer extents identical',
 'source_only_navigation_not_ROM_proof':True,
}
(ROOT/'04_WORLD_GRAPHICS.json').write_text(json.dumps(OUT,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
asm=['; THE SKRAUN GRAPHICS II / MAIN V / 2026-11-25 / REVISION 3',
'; SOURCE_ONLY, no DASM or Stella run with these bytes.',
'; Replace ONLY existing PlayPF1 768-byte block in PR60 bank3.asm AFTER separate MAIN authorization.',
'; 8 worlds * 96 B each. Vertical order is reversed: (186-y)//2; 2 physical scanlines/byte.',
'; All original world selectors, PF renderer, mirror/repeat flags, sprites, halo and mapper unchanged.',
'        ORG $FA00','PlayPF1:']
for s in STAGES:
 asm.append(f'; WORLD {s["stage"]} {s["world"]} | {s["mode"]} | {s["top_motif"]["name"]} / {s["bottom_motif"]["name"]}')
 for j in range(0,96,16):asm.append('        dc.b '+','.join(s['PF1_hex'][j:j+16]))
asm+=['; End at $FD00 (exclusive), eight*96 bytes.','']
(ROOT/'03_PLAYFIELD_DATA.asm').write_text('\n'.join(asm),encoding='utf-8')
parsed=bytes(int(t,16) for line in (ROOT/'03_PLAYFIELD_DATA.asm').read_text().split('PlayPF1:',1)[1].splitlines() if 'dc.b' in line for t in re.findall(r'\$([0-9a-fA-F]{2})',line))
assert parsed==ALL and hashlib.sha256(parsed).hexdigest()==HASH
coll={
 'status':'SOURCE_ONLY_REVISION3_NOT_APPLIED',
 'explanation':'No AABB changes required; three revised shapes preserve each affected object exact R2 outer envelope and x/y placement. Each of eight stage AABBs is byte-equivalent to R2. Interior pixel differences are not part of four-rect collider.',
 'source_only_not_gameplay_verification':True,'rect_coordinate_system':'X in [0,160) colour clocks; Y in [0,186) visible rasterlines; x0,x1,y0,y1 exclusive end',
 'source_only_player_half_extent':[16,18],
 'stages':[{'stage':s['stage'],'world':s['world'],'mode':s['mode'],'rectangles':s['rects_xyxy_halfopen'],'equal_to_revision2':True,'nav_test':s['geometric_source_only_l3']['revision3_rechecked']}for s in STAGES]
}
(ROOT/'05_COLLISION_RECOMMENDATIONS.json').write_text(json.dumps(coll,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
rec=['; SOURCE_ONLY. Identical geometry to R2. NEVER alter ROM collision logic without MAIN authorization.',
'; rectangle order: top-left, top-right, bottom-left, bottom-right. Values x0,x1,y0,y1 (end exclusive).','ProposedWorldRects:']
for s in STAGES:
 rec.append(f'; World {s["stage"]} {s["world"]}')
 rec.append('        dc.b '+','.join(f'${v:02X}' for rect in s['rects_xyxy_halfopen'] for v in rect))
(ROOT/'05_COLLISION_CANDIDATES_NOT_APPLIED.asm').write_text('\n'.join(rec)+'\n',encoding='utf-8')

W,H=160,186
SCALE_X=4;SCALE_Y=2 # exact same display scaling as R2 TV_ASPECT_4X
APPROVED=Image.open(REF/'USER_APPROVED_GRAPHIC_REFERENCE_UNMODIFIED.png').convert('RGB')
def font(size,bold=False):
 return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',size)
def original_crop(world):
 coords={'Skog':(31,136,537,693),'Berg':(570,136,1075,693),'Dröm':(31,768,537,1323),'Natt':(570,768,1075,1323)}
 return APPROVED.crop(coords[world])
def draw_pfield(vals,world,mode,gold=False):
 im=Image.new('RGB',(W,H),COLORS[world]['background']);d=ImageDraw.Draw(im)
 color=GOLD if gold else COLORS[world]['world']
 for y,v in enumerate(raster(vals)):
  for bit in range(8):
   if v & (128>>bit):
    left=16+4*bit;right=140-4*bit if mode=='mirror' else 96+4*bit
    d.rectangle((left,y,left+3,y),fill=color)
    d.rectangle((right,y,right+3,y),fill=color)
 return im
def zoom(im):return im.resize((W*SCALE_X,H*SCALE_Y),Image.Resampling.NEAREST)
def l3(im):
 u1=json.loads((SRC/'SOURCE_U1_LEG1_FROZEN.json').read_text(encoding='utf-8'))
 rows=u1['one_candidate_U1_LEG1']['A']
 d=ImageDraw.Draw(im)
 for y,row in enumerate(rows):
  for x,bit in enumerate(row):
   if bit=='1':
    xx=80-16+x*4;yy=90-18+y*3
    d.rectangle((xx,yy,xx+3,yy+2),fill='#d2d2d1')
 return im
def collision_img(im,rects):
 im=im.convert('RGBA');lay=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(lay)
 for x0,x1,y0,y1 in rects:d.rectangle((x0,y0,x1-1,y1-1),fill=(250,78,66,65),outline=(255,112,66,240),width=1)
 return Image.alpha_composite(im,lay).convert('RGB')

def banner_board(kind,stage_list=STAGES):
 cw,ch=670,475;bd=Image.new('RGB',(cw*4+18*3,ch*2+18),'#eeece7');draw=ImageDraw.Draw(bd)
 for j,s in enumerate(stage_list):
  x=j%4*(cw+18);y=j//4*(ch+18)
  vals=[int(t[1:],16) for t in s['PF1_hex']]
  im=draw_pfield(vals,s['world'],s['mode'],gold=(kind=='gold'))
  if kind=='actors':l3(im)
  if kind=='collisions':im=collision_img(im,s['rects_xyxy_halfopen'])
  bd.paste(zoom(im),(x+10,y+48))
  draw.text((x+12,y+9),f'{s["stage"]}. {s["world"]} | {s["mode"].upper()}',fill='#161616',font=font(21,True))
  draw.text((x+10,y+429),f'{s["top_label"]} + {s["bottom_label"]}',fill='#333',font=font(15))
 return bd

def name_slug(s):return f'{s["stage"]:02d}_{s["world"].lower().replace("ö","o")}'
for s in STAGES:
 n=s['stage'];slug=name_slug(s);vals=[int(x[1:],16) for x in s['PF1_hex']]
 im=draw_pfield(vals,s['world'],s['mode'])
 im.save(PREV/f'{slug}_NATIVE_160x186_REV3_SOURCE_ONLY.png')
 zoom(im).save(PREV/f'{slug}_TV_ASPECT_4X_REV3_SOURCE_ONLY.png')
 zoom(draw_pfield(vals,s['world'],s['mode'],True)).save(PREV/f'{slug}_HALO_GOLD_4X_REV3_SOURCE_ONLY.png')
 zoom(l3(im.copy())).save(PREV/f'{slug}_SKRAUN_L3_4X_REV3_SOURCE_ONLY.png')
 zoom(collision_img(im,s['rects_xyxy_halfopen'])).save(PREV/f'{slug}_COLLISION_PROPOSAL_4X_REV3_SOURCE_ONLY.png')
 prior_vals=list(R2_ALL[(n-1)*96:n*96]);prior_img=draw_pfield(prior_vals,s['world'],s['mode'])
 # In unchanged stages, all rendered pixel outputs must be identical to original R2 package.
 if n not in (1,2,4):
  expected=Image.open(SRC/f'R2_{slug}_NATIVE_UNMODIFIED.png').convert('RGB')
  assert ImageChops.difference(im,expected).getbbox() is None,(n,'unexpected source-only pixel difference')
 # Preserve same scale for original/R2/R3; original is the approved *concept*, not raster.
 panel=Image.new('RGB',(3*380+28,575),'#ebe9e4');d=ImageDraw.Draw(panel)
 pic1=original_crop(s['world']).resize((365,435),Image.Resampling.NEAREST)
 pic2=zoom(prior_img).resize((365,435),Image.Resampling.NEAREST)
 pic3=zoom(im).resize((365,435),Image.Resampling.NEAREST)
 for j,p in enumerate((pic1,pic2,pic3)):
  xx=8+j*392;panel.paste(p,(xx,62))
  d.text((xx,13),('GODKÄND KONCEPTREFERENS','REVISION 2 / PF1','REVISION 3 / PF1')[j],font=font(16,True),fill='#111')
 d.text((8,525),f'Bana {n} | {s["world"]} | {s["mode"]} | PF1 2 scanlines per byte | SOURCE_ONLY',font=font(18),fill='#222')
 panel.save(COMP/f'{slug}_APPROVED_REV2_REV3_COMPARISON.png')
 # Save R2 and R3 native scene comparands as audit evidence.
 prior_img.save(COMP/f'{slug}_REVISION2_RECONSTRUCTED_NATIVE.png')

for s in STAGES:
 world=s['world'];name=s['stage'];color=COLORS[world]['world']
 for pos in ['top','bottom']:
  k=s[f'{pos}_motif']['name'];rows=MOTIFS[k];prev=R2['motifs'][k]
  for label,rs in [('REV3',rows)]:
   bitimg=Image.new('RGB',(8,len(rs)),COLORS[world]['background']);d=ImageDraw.Draw(bitimg)
   for y,row in enumerate(rs):
    for x,v in enumerate(row):
     if v=='1':d.point((x,y),fill=color)
   bitimg.save(MOT/f'{k}_PF1_NATIVE_REV3_SOURCE_ONLY.png')
   cellw,cellh=42,26
   canvas=Image.new('RGB',(8*cellw+70,len(rs)*cellh+110),'#eceae6');gd=ImageDraw.Draw(canvas)
   canvas.paste(bitimg.resize((8*cellw,len(rs)*cellh),Image.Resampling.NEAREST),(35,68))
   for x in range(9):gd.line((35+x*cellw,68,35+x*cellw,68+len(rs)*cellh),fill='#777')
   for y in range(len(rs)+1):gd.line((35,68+y*cellh,35+8*cellw,68+y*cellh),fill='#777')
   gd.text((35,12),f'{k} / PF1 REVISION 3 SOURCE_ONLY',fill='#161616',font=font(17,True))
   canvas.save(MOT/f'{k}_PIXELGRID_REV3_SOURCE_ONLY.png')

for kind,filename in [
 ('normal','ALL_EIGHT_ARENAS_REV3_TV_ASPECT_SOURCE_ONLY.png'),
 ('gold','ALL_EIGHT_HALO_GOLD_REV3_SOURCE_ONLY.png'),
 ('actors','ALL_EIGHT_SKRAUN_L3_REV3_SOURCE_ONLY.png'),
 ('collisions','ALL_EIGHT_COLLISIONS_REV3_SOURCE_ONLY.png')]:
 banner_board(kind).save(PREV/filename)

# Visually enlarged per-motif comparisons from exact frozen R2 and R3 bit matrices.
for k,rev3 in CHANGED.items():
 world=R2['stages'][int(k[:2])-1]['world'];c=COLORS[world]['world']
 rev2=R2['motifs'][k];assert len(rev2)==len(rev3)
 canvas=Image.new('RGB',(2*460+40,len(rev2)*22+125),'#eae8e2');d=ImageDraw.Draw(canvas)
 for col,rows in enumerate((rev2,rev3)):
  ox=col*480+22;oy=67;w=52;h=22
  for y,s in enumerate(rows):
   for x,b in enumerate(s):
    color=c if b=='1' else COLORS[world]['background']
    d.rectangle((ox+x*w,oy+y*h,ox+(x+1)*w-1,oy+(y+1)*h-1),fill=color)
  for x in range(9):d.line((ox+x*w,oy,ox+x*w,oy+len(rows)*h),fill='#8c8c8c')
  for y in range(len(rows)+1):d.line((ox,oy+y*h,ox+8*w,oy+y*h),fill='#8c8c8c')
  d.text((ox,18),f'{k} – '+('REVISION 2' if col==0 else 'REVISION 3'),fill='#111',font=font(18,True))
 canvas.save(COMP/f'{k}_REV2_VS_REV3_PIXELGRID.png')

# Summary comparison for the changed stages, with *identical* scene scale for R2 and R3.
comp=Image.new('RGB',(2*690+18,3*465),'#eeece7');d=ImageDraw.Draw(comp)
for row,n in enumerate((1,2,4)):
 s=STAGES[n-1];slug=name_slug(s);old=draw_pfield(R2_ALL[(n-1)*96:n*96],s['world'],s['mode']);new=draw_pfield(ALL[(n-1)*96:n*96],s['world'],s['mode'])
 for col,im in enumerate((old,new)):
  xx=col*690+14;yy=row*465+50
  comp.paste(zoom(im),(xx,yy))
  d.text((xx,yy-34),f'BANA {n}: '+('R2, SOURCE_ONLY' if col==0 else 'R3, SOURCE_ONLY'),fill='#171717',font=font(20,True))
comp.save(COMP/'CHANGED_STAGES_01_02_04_REV2_VS_REV3_SAME_SCALE.png')

# Original world concept reference vs R2 and R3 for every world (first stage each).
four=Image.new('RGB',(3*680,4*460),'#eeeae5');d=ImageDraw.Draw(four)
for i,world in enumerate(('Skog','Berg','Dröm','Natt')):
 s=STAGES[i*2];stage=i*2+1;old=draw_pfield(R2_ALL[(stage-1)*96:stage*96],world,s['mode']);new=draw_pfield(ALL[(stage-1)*96:stage*96],world,s['mode'])
 imgs=[original_crop(world).resize((640,372),Image.Resampling.NEAREST),zoom(old),zoom(new)]
 for j,img in enumerate(imgs):
  x=j*680+12;y=i*460+56;four.paste(img,(x,y))
  d.text((x,y-40),f'{world} / '+('GODKÄND REFERENS' if j==0 else ('REVISION 2' if j==1 else 'REVISION 3')),fill='#111',font=font(18,True))
four.save(COMP/'FOUR_WORLDS_APPROVED_REV2_REV3_OVERVIEW.png')

# Precise source-only stage-size summary and bounded AABB recheck; never emulator claims.
metrics=[]
for s in STAGES:
 v=[int(x[1:],16) for x in s['PF1_hex']]
 bbox=rects_for(v,s['mode']=='mirror')
 metrics.append({'stage':s['stage'],'top_source_rows':s['top_motif']['source_rows'],'bottom_source_rows':s['bottom_motif']['source_rows'],
   'top_y_range':[s['top_motif']['y_start'],s['top_motif']['y_end_exclusive']],
   'bottom_y_range':[s['bottom_motif']['y_start'],s['bottom_motif']['y_end_exclusive']],
   'top_width_cc':bbox[0][1]-bbox[0][0],'bottom_width_cc':bbox[2][1]-bbox[2][0],
   'AABB_identical_to_REV2':True,'visual_byte_changes':CHANGES[str(s['stage'])]['changed_bytes']})
(ROOT/'METRICS_SOURCE_ONLY.json').write_text(json.dumps(metrics,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

REPORT=f'''# THE SKRAUN — GRAPHICS II / MAIN V — FINAL WORLD GRAPHICS REVISION 3

**2026-11-25 | SOURCE_ONLY, awaiting MAIN V and user's aesthetic choice.** Exactly three of 16 approved-direction base motifs were revised from frozen R2. No other bitmap masks, ROM source, sprites, halo, mapper or game mechanics were touched.

## Visual changes: precisely three motifs

1. **Stage 1, bottom, `01_round_A`**: canopy now 14 PF1 entries (28 physical scanlines) and stem 8 entries (16 scanlines), instead of R2 canopy 17 (34) and stem 5 (10). Crown keeps 8-bit full width and round stepped transitions.
2. **Stage 2, bottom, `02_round_B`**: canopy 14 PF1 entries and stem 8 entries, versus R2 canopy 18 and stem 4. Seven-bit asymmetrical round crown (bit7 forced off on REPEAT world), distinct from stage 1.
3. **Stage 4, top, `04_peak_B`**: 17 two-scanline rows; peak begins near x4 then opens on BOTH sides to an asymmetric 7-cell broad base. The rounded lower mountain remains untouched.

All 13 other motifs are **literal bit-for-bit matches** to the frozen R2 JSON, including all firs, both stage 3 mountains, stage 4 rounded mountain, spirals, portals, walls, ruins. Three modified motifs retain the same width/height envelope and precise y-positions. Eight arenas retain identical mirror/REPEAT behavior, 96 PF1 bytes each, no extra TIA writes or RAM.

## Exact reproducible source-only checks

- R2 frozen source SHA256 {R2_EXPECT}; 768 bytes.
- R3 PlayPF1 source SHA256 {HASH}; 768 bytes.
- R3 vs R2 changed individual byte positions: **{COUNT}**, only stages 1, 2, 4 and only the specified top/bottom motif ranges.
- The **other five stages' full 96-byte tables are unchanged**; stage 1/2 top fir data and stage 4 bottom hill unchanged; every other 13 frozen motif rows unchanged.
- All 32 original conservative collision rectangles (8*4) are still exactly valid AABB envelopes, automatically recalculated and equal to R2. No collision data change requested.
- R2 and R3 unchanged-stage 160x186 scenes have **identical image pixel data**. All generated images from the exact R3 768-byte source; no AI illustration or interpolated source detail.
- Approximate TV presentation uses 4 display px per logical colour clock and 2 px per visible rasterline, same as R2. This is for comparison only, not a calibrated CRT. The user-approved original is a design mockup, not physical ROM screenshot.
- Source-only BFS for level 3 (half-width 16cc/half-height18 scanlines) found all free center positions connected and open x80 y63-119 in all eight stages. Real collision navigation, simultaneous enemies, halo, TIA timing, stack, and Stella remain **untested** by this graphics revision.

## Authentic TIA ownership

Original draft PR60 baseline commit `2af9855fbe8d3edbe6d01609d3e539547b744aef`, source bank3 blob `62e88de692df80024db8342e0990640a5310f620`; original developer ROM SHA256 `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647` is **historical**, not a new R3 ROM. `WorldPFIndex`, `WorldPFPtr`, `Visible`, `VisibleArrow`, `CTRLPF`, `WorldRects` and 6507/TIA kernel are untouched. R3 sends 8x96 PF1 data only. Fewer colored rectangles do not imply fewer TIA writes; the renderer continues writing PF1 every visible scanline.

## Approval gate

Recommend R3 for MAIN V and user aesthetic review. Do **not** merge, implement in ROM, assign ROM work automatically or label it independently verified. Further development requires a separate express MAIN authorization and actual DASM/Stella/joystick tests.
'''.replace('\x10','`').replace('\x11','`')
(ROOT/'01_GRAPHICS_REPORT.md').write_text(REPORT,encoding='utf-8')

HANDOFF=f'''# THE SKRAUN — MAIN V → ROM DEVELOPMENT | REVISION 3 handoff (advisory only)

**No implementation authorization.** R3 is a complete SOURCE_ONLY graphics candidate, based on frozen R2 commit `299de38d6e8fbefbc1057d70682b56b76dd177f2`, R2 data SHA256 `{R2_EXPECT}`.

After a **separate MAIN order**, replace only the 768 bytes inside `PlayPF1:` after `ORG $FA00` and up to `ORG $FD00` in the exact PR60 `experiments/fullgame1_arrow_halo_20261125/bank3.asm` with the `dc.b` tables from `03_PLAYFIELD_DATA.asm`. Do **not** change a single other bank/visible kernel register write. All data still uses `WorldPFIndex=(186-y)//2`, reversed table order; mirror on 1/3/5/7, repeat on 2/4/6/8.

R3 PF1 SHA256 `{HASH}`, 8x96=768 bytes; exactly {COUNT} changed bytes vs R2, restricted to bottom motifs of stages 1/2, top motif of stage 4. This is **not** a validated ROM binary. `04_WORLD_GRAPHICS.json` contains per-world data and all 16 source motifs. `09_GENERATOR/rebuild.py` creates exact previews, ASM, JSON, collision files and manifest.

The 4x8 existing R2 collision envelopes in `05_COLLISION_RECOMMENDATIONS.json` remain *numerically identical*, because each altered shape retains the same x/y outer extent. Their relation to real physical collision must be verified before integrating. Portal/spiral negative voids are still enveloped by solid AABBs in the existing design candidate. Nothing has changed in `WorldRects` code. No gameplay compromise.

Before MAIN go/no-go: actual native DASM build, Stella 6.7.1 262-line checks including visible PF byte order/pixel matching on all eight stages, real joystick & L3 corridors, orb transformations, correct 360-degree halo geometry and color, enemy simultaneity, RAM/stack and beam deadlines. Never call R3 SOURCE_ONLY an independent verification or approved ROM.

GRAPHICS II STOP after delivery, MAIN V to decide.
'''
(ROOT/'02_HANDOFF_TO_ROM_DEVELOPMENT.md').write_text(HANDOFF,encoding='utf-8')
(ROOT/'00_START_HAR.md').write_text(f'''# THE SKRAUN — FINAL WORLD GRAPHICS REVISION 3

**SOURCE_ONLY, not Stella or a ROM.** Three changed motifs from frozen R2 only; 13 masks bit-identical. All eight arena preview images and 16 motif images are included.

- 01_GRAPHICS_REPORT.md: source-only graphics report and byte proof.
- 02_HANDOFF_TO_ROM_DEVELOPMENT.md: integration instructions **not an order**.
- 03_PLAYFIELD_DATA.asm: new 768-byte PlayPF1 table, SHA256 `{HASH}`.
- 04_WORLD_GRAPHICS.json: all 16 exact bitrows and stage hex.
- 05_COLLISION_RECOMMENDATIONS.json + ASM: still R2 identical AABB, not applied.
- 06_PREVIEWS: eight arenas, native and same-scaled TV aspect, L3, gold, collision.
- 07_INDIVIDUAL_MOTIFS: all 16 8-bit original masks and enlarged grids.
- 08_BEFORE_AFTER: 3 changed motifs R2/R3 enlarged plus approved/R2/R3 for all eight stages.
- 09_GENERATOR: rebuild.py and exact frozen R2 source + U1 sprite source.
- 11_APPROVED_VISUAL_REFERENCE: user-approved direction and exact R2 overview.
- SHA256SUMS.txt: all files except the manifest itself.

MAIN V/user choose design before any implementation. **STOP.**
''',encoding='utf-8')
(ROOT/'10_SOURCE_REGISTER.md').write_text(f'''# THE SKRAUN Revision 3: source registry

- User-approved graphical reference, included unchanged: `11_APPROVED_VISUAL_REFERENCE/USER_APPROVED_GRAPHIC_REFERENCE_UNMODIFIED.png`.
- Frozen R2 GitHub HEAD: `299de38d6e8fbefbc1057d70682b56b76dd177f2`, exact R2 PF1 SHA256 `{R2_EXPECT}`. The entire frozen R2 world JSON and asm are included in `09_GENERATOR`.
- Exact user-supplied Revision 2 preview included unchanged: `11_APPROVED_VISUAL_REFERENCE/REVISION2_EIGHT_WORLDS_UNMODIFIED.png`.
- PR60 source commit `2af9855fbe8d3edbe6d01609d3e539547b744aef` and bank3 Git blob `62e88de692df80024db8342e0990640a5310f620` (source-only hardware model).
- New R3 PF1 SHA256 `{HASH}`; only 3 motifs changed, {COUNT} bytes changed in 768-byte table. 5 unaffected stage tables byte-identical; 13 frozen motifs byte-identical.
- All visual output and collisions generated from exact table bytes, not edited pixels.
- Historical PR60 ROM SHA256 `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647` is NOT an R3 test.
- All 8 world colors, halos, U1/knight/Ranger sprites, mapper, core kernel and gameplay untouched; this branch contains an isolated R3 file package only.
- SOURCE_ONLY test = source assertions, geometry BFS, image pixel equality for unaffected stages, checksum & deterministic rebuild. No independent Verification, Stella, DASM or hardware measurement of R3.
''',encoding='utf-8')

# SHA manifest must be generated LAST; package remains fully deterministic on rerun.
sha=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS.txt':
  sha.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}')
(ROOT/'SHA256SUMS.txt').write_text('\n'.join(sha)+'\n',encoding='utf-8')
for entry in sha:
 h,path=entry.split('  ',1)
 assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==h
assert len(list(MOT.glob('*_PF1_NATIVE_REV3_SOURCE_ONLY.png')))==16
assert len(list(PREV.glob('*_NATIVE_160x186_REV3_SOURCE_ONLY.png')))==8
assert len(list(COMP.glob('*_APPROVED_REV2_REV3_COMPARISON.png')))==8
print(json.dumps({'status':'SOURCE_ONLY_R3_PASS','R2_PF1_sha256':R2_EXPECT,'R3_PF1_sha256':HASH,
 'changed_bytes':COUNT,'changed_by_stage':CHANGES,'all_colliders_identical':True,
 'other_13_motifs_unchanged':True,'all_8_nav_models_connected':True,
 'manifest_files':len(sha),'total_files':len(sha)+1},indent=2,ensure_ascii=False))
