# THE SKRAUN — GRAPHICS II / MAIN V — FINAL WORLD GRAPHICS REVISION 3

**2026-11-25 | SOURCE_ONLY, awaiting MAIN V and user's aesthetic choice.** Exactly three of 16 approved-direction base motifs were revised from frozen R2. No other bitmap masks, ROM source, sprites, halo, mapper or game mechanics were touched.

## Visual changes: precisely three motifs

1. **Stage 1, bottom, `01_round_A`**: canopy now 14 PF1 entries (28 physical scanlines) and stem 8 entries (16 scanlines), instead of R2 canopy 17 (34) and stem 5 (10). Crown keeps 8-bit full width and round stepped transitions.
2. **Stage 2, bottom, `02_round_B`**: canopy 14 PF1 entries and stem 8 entries, versus R2 canopy 18 and stem 4. Seven-bit asymmetrical round crown (bit7 forced off on REPEAT world), distinct from stage 1.
3. **Stage 4, top, `04_peak_B`**: 17 two-scanline rows; peak begins near x4 then opens on BOTH sides to an asymmetric 7-cell broad base. The rounded lower mountain remains untouched.

All 13 other motifs are **literal bit-for-bit matches** to the frozen R2 JSON, including all firs, both stage 3 mountains, stage 4 rounded mountain, spirals, portals, walls, ruins. Three modified motifs retain the same width/height envelope and precise y-positions. Eight arenas retain identical mirror/REPEAT behavior, 96 PF1 bytes each, no extra TIA writes or RAM.

## Exact reproducible source-only checks

- R2 frozen source SHA256 `253bd7180259cf699a4315379b900ca47801ae6259f0955a002bc601f5ef98f8`; 768 bytes.
- R3 PlayPF1 source SHA256 `c879daa4b5bcc1bb19aa71ee632c48996b0885963bd102dd8e76bd50761354d4`; 768 bytes.
- R3 vs R2 changed individual byte positions: **32**, only stages 1, 2, 4 and only the specified top/bottom motif ranges.
- The **other five stages' full 96-byte tables are unchanged**; stage 1/2 top fir data and stage 4 bottom hill unchanged; every other 13 frozen motif rows unchanged.
- All 32 original conservative collision rectangles (8*4) are still exactly valid AABB envelopes, automatically recalculated and equal to R2. No collision data change requested.
- R2 and R3 unchanged-stage 160x186 scenes have **identical image pixel data**. All generated images from the exact R3 768-byte source; no AI illustration or interpolated source detail.
- Approximate TV presentation uses 4 display px per logical colour clock and 2 px per visible rasterline, same as R2. This is for comparison only, not a calibrated CRT. The user-approved original is a design mockup, not physical ROM screenshot.
- Source-only BFS for level 3 (half-width 16cc/half-height18 scanlines) found all free center positions connected and open x80 y63-119 in all eight stages. Real collision navigation, simultaneous enemies, halo, TIA timing, stack, and Stella remain **untested** by this graphics revision.

## Authentic TIA ownership

Original draft PR60 baseline commit `2af9855fbe8d3edbe6d01609d3e539547b744aef`, source bank3 blob `62e88de692df80024db8342e0990640a5310f620`; original developer ROM SHA256 `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647` is **historical**, not a new R3 ROM. `WorldPFIndex`, `WorldPFPtr`, `Visible`, `VisibleArrow`, `CTRLPF`, `WorldRects` and 6507/TIA kernel are untouched. R3 sends 8x96 PF1 data only. Fewer colored rectangles do not imply fewer TIA writes; the renderer continues writing PF1 every visible scanline.

## Approval gate

Recommend R3 for MAIN V and user aesthetic review. Do **not** merge, implement in ROM, assign ROM work automatically or label it independently verified. Further development requires a separate express MAIN authorization and actual DASM/Stella/joystick tests.
