# THE SKRAUN — MAIN V → ROM DEVELOPMENT | REVISION 3 handoff (advisory only)

**No implementation authorization.** R3 is a complete SOURCE_ONLY graphics candidate, based on frozen R2 commit `299de38d6e8fbefbc1057d70682b56b76dd177f2`, R2 data SHA256 `253bd7180259cf699a4315379b900ca47801ae6259f0955a002bc601f5ef98f8`.

After a **separate MAIN order**, replace only the 768 bytes inside `PlayPF1:` after `ORG $FA00` and up to `ORG $FD00` in the exact PR60 `experiments/fullgame1_arrow_halo_20261125/bank3.asm` with the `dc.b` tables from `03_PLAYFIELD_DATA.asm`. Do **not** change a single other bank/visible kernel register write. All data still uses `WorldPFIndex=(186-y)//2`, reversed table order; mirror on 1/3/5/7, repeat on 2/4/6/8.

R3 PF1 SHA256 `c879daa4b5bcc1bb19aa71ee632c48996b0885963bd102dd8e76bd50761354d4`, 8x96=768 bytes; exactly 32 changed bytes vs R2, restricted to bottom motifs of stages 1/2, top motif of stage 4. This is **not** a validated ROM binary. `04_WORLD_GRAPHICS.json` contains per-world data and all 16 source motifs. `09_GENERATOR/rebuild.py` creates exact previews, ASM, JSON, collision files and manifest.

The 4x8 existing R2 collision envelopes in `05_COLLISION_RECOMMENDATIONS.json` remain *numerically identical*, because each altered shape retains the same x/y outer extent. Their relation to real physical collision must be verified before integrating. Portal/spiral negative voids are still enveloped by solid AABBs in the existing design candidate. Nothing has changed in `WorldRects` code. No gameplay compromise.

Before MAIN go/no-go: actual native DASM build, Stella 6.7.1 262-line checks including visible PF byte order/pixel matching on all eight stages, real joystick & L3 corridors, orb transformations, correct 360-degree halo geometry and color, enemy simultaneity, RAM/stack and beam deadlines. Never call R3 SOURCE_ONLY an independent verification or approved ROM.

GRAPHICS II STOP after delivery, MAIN V to decide.
