# THE SKRAUN Revision 3: source registry

- User-approved graphical reference, included unchanged: `11_APPROVED_VISUAL_REFERENCE/USER_APPROVED_GRAPHIC_REFERENCE_UNMODIFIED.png`.
- Frozen R2 GitHub HEAD: `299de38d6e8fbefbc1057d70682b56b76dd177f2`, exact R2 PF1 SHA256 `253bd7180259cf699a4315379b900ca47801ae6259f0955a002bc601f5ef98f8`. The entire frozen R2 world JSON and asm are included in `09_GENERATOR`.
- Exact user-supplied Revision 2 preview included unchanged: `11_APPROVED_VISUAL_REFERENCE/REVISION2_EIGHT_WORLDS_UNMODIFIED.png`.
- PR60 source commit `2af9855fbe8d3edbe6d01609d3e539547b744aef` and bank3 Git blob `62e88de692df80024db8342e0990640a5310f620` (source-only hardware model).
- New R3 PF1 SHA256 `c879daa4b5bcc1bb19aa71ee632c48996b0885963bd102dd8e76bd50761354d4`; only 3 motifs changed, 32 bytes changed in 768-byte table. 5 unaffected stage tables byte-identical; 13 frozen motifs byte-identical.
- All visual output and collisions generated from exact table bytes, not edited pixels.
- Historical PR60 ROM SHA256 `3977c1e04e2cb5a43944e32477b8fa6f443bff270e3af8db4ae3d25e497b9647` is NOT an R3 test.
- All 8 world colors, halos, U1/knight/Ranger sprites, mapper, core kernel and gameplay untouched; this branch contains an isolated R3 file package only.
- SOURCE_ONLY test = source assertions, geometry BFS, image pixel equality for unaffected stages, checksum & deterministic rebuild. No independent Verification, Stella, DASM or hardware measurement of R3.
